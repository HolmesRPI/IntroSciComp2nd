function fig9_1

figure(1)
clf
% get(gcf)
set(gcf,'Position', [4 431 560 420])
co = [0 0 1;
    0 0.5 0;
    1 0 0;
    0 0.75 0.75;
    0.75 0 0.75;
    0.75 0.75 0;
    0.25 0.25 0.25];
set(groot,'defaultAxesColorOrder',co)

% compute and then plot contours
xa=-1; xb=1; ya=-1; yb=1;
n0=2000;
x=linspace(xa,xb,n0);
y=linspace(ya,yb,n0);
[A1,A2]=meshgrid(x,y);
for i=1:n0
    for j=1:n0
        F(i,j)=f(x(i), y(j));
    end
end
%contour(A1,A2,F,'k')
%contour(A1,A2,F,[ 0.1 0.3 0.5 0.8 1.4 1.9 2.5 6 20],'k','LineWidth',1.2)
contour(A1,A2,F,[ 0.04 0.3 0.5 0.8 1.5 1.95  4.3  8 12 16 22],'LineWidth',1.2)
xlabel('x-axis','FontSize',16,'FontWeight','bold')
ylabel('y-axis','FontSize',16,'FontWeight','bold')
set(gca,'FontSize',16,'FontWeight','bold')
set(gca,'ytick',[-1 -0.5 0 0.5 1])

%exportgraphics(gcf,'/Users/mark/Desktop/conti.eps')

figure(2)
clear *
clf
% get(gcf)
set(gcf,'Position', [2 925 560 420])
co = [0 0 1;
    0 0.5 0;
    1 0 0;
    0 0.75 0.75;
    0.75 0 0.75;
    0.75 0.75 0;
    0.25 0.25 0.25];
set(groot,'defaultAxesColorOrder',co)

xa=-0.7; xb=0.7; ya=-0.7; yb=0.7;
n0=60;
x=linspace(xa,xb,n0);
y=linspace(ya,yb,n0);
[A1,A2]=meshgrid(x,y);
for i=1:n0
    for j=1:n0
        F(i,j)=f(x(i), y(j));
    end
end
surfc(A1,A2,F)
view(-32, 16);
xlabel('x')
ylabel('y')
zlabel('F(x,y)')
set(gca,'FontSize',16,'FontWeight','bold')
box on
H=gca;
H.LineWidth=1;

%exportgraphics(gcf,'/Users/mark/Desktop/surfi.eps')

function z=f(x,y)
%z=-x^4+x^6/6-10*x*y+y+y^4;
%z=100*(x^2-y)^2+(x-1)^2;
z=(x^2+4*y^2-1)^2+(4*x^2+y^2-1)^2;






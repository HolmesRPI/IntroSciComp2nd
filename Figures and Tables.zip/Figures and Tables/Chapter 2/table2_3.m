function table2_3

%  Solve  f(x) = 0  using the bisection method

%  Input:
%	a = left endpoint of interval
%	b = right endpoint of interval
%	tol = tolerance for stopping bisection method
%	f(x) at end of file

a=-2;
b=0;
mid=0.5*(a+b);
tol=10^(-6);
err=10*tol;

%%% bisection procedure
it=0;
fprintf('\n RIE = relative iterative error \n\n')
fprintf(' k \t\t x_k   \t\t RIE \n')
while err>tol
    old=mid;
    fmid=f(mid);
    if f(a)*fmid<0
        b=mid;
    elseif f(b)*fmid<0
        a=mid;
    else
        break
    end
    mid=0.5*(a+b);
    it=it+1;
    err=abs((mid-old)/mid);
    fprintf(' %i \t %19.15f \t %5.1e \n',it,mid,err)
    %fprintf('\\, %i \\, & \\,\\, %19.15f \\,\\, & \\,\\, %5.1e  \\\\\\hline \n',it,mid,err)
end
fprintf('\n')

function g=f(x)
%g=x^3-3*x+1;
g=exp(-x)-(2+x);








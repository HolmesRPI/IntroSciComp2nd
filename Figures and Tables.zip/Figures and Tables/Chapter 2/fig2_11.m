function fig2_11

%  Solve  F(x,y) = 0  using Newton's method

%  Input:
%	xa = starting point
%	tol = tolerance for stopping
%	f(x) and df(x) are at end of file

a=0; b=8;
nx=20;
x=linspace(a,b,nx);

tol=10^(-8);

y(1)=0;
for ix=1:nx
    err=10*tol;
    while err>tol
        z=f(x(ix),y(ix))/df(x(ix),y(ix));
        y(ix)=y(ix)-z;
        err=abs(z/y(ix));
        %fprintf(' %i & %19.15f & %5.1e \\\\\\hline \n',it,x,err)
    end
    if ix<nx
        y(ix+1)=y(ix);
    end
end

clf
% get(gcf)
set(gcf,'Position', [25 1115 658 230])
subaxis(1,1,1,1,'MT',0.01,'MB',0.18,'MR',-0.02,'ML',0.03,'P',0.04)
co = [0 0 1;
    0 0.5 0;
    1 0 0;
    0 0.75 0.75;
    0.75 0 0.75;
    0.75 0.75 0;
    0.25 0.25 0.25];
set(groot,'defaultAxesColorOrder',co)

plot(x,y,'--b','lineWidth',1)
hold on
plot(x,y,'ob','MarkerSize',8,'lineWidth',1)
box on
grid on
axis([a b -3 0])
xlabel('x-axis')
ylabel('y-axis')
set(gca,'FontSize',16,'FontWeight','bold')

%exportgraphics(gcf,'/Users/mark/Desktop/implicit.eps')


function g=f(x,y)
g=y+x+2-exp(sin(x)-y);

function g=df(x,y)
g=1+exp(sin(x)-y);




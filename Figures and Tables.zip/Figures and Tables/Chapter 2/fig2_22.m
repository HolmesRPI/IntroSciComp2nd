function fig2_22

a=-2;
b=2;
nx=100;
x=linspace(a,b,nx);

for ix=1:nx
    y(ix)=f(x(ix));
end

clf
% get(gcf)
set(gcf,'Position', [25 1115 658 230])
subaxis(1,1,1,1,'MT',0.01,'MB',0.18,'MR',-0.02,'ML',0.045,'P',0.04)
co = [0 0 1;
      0 0.5 0;
      1 0 0;
      0 0.75 0.75;
      0.75 0 0.75;
      0.75 0.75 0;
      0.25 0.25 0.25];
set(groot,'defaultAxesColorOrder',co)

hold on
plot(x,y,'LineWidth',1.8);
plot([a b],[0 0],'k','LineWidth',1)
axis([a b -1.1 1.1])

xlabel('x-axis')
ylabel('y-axis')
grid on
box on
set(gca,'FontSize',16,'FontWeight','bold')

exportgraphics(gcf,'/Users/mark/Desktop/tanh.eps')

function g=f(x)
%g=x^3+2*x+2;
g=(1-exp(-10*x))/(1+exp(-10*x));
%g=1-4*x*exp(-2*x*x);






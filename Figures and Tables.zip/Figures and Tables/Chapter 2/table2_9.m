function table2_9

%  Solve  f(x) = 0  using Newton

%  Input:
%	x = starting point
%	tol = tolerance for stopping
%	f(x) and df(x) These are at end of file

% Solution of  exp(-x)-(2+x) = 0  to 20 digits
xe=-0.4428544010023885831;

x=0;
X=-2;
tol=10^(-10);

k=0;
err=10*tol;
fprintf('\n RIE = relative iterative error \n\n')
fprintf(' k  \t   x_k \t\t\t  RIE  \t\t  Rel Error\n')
while err>tol
    k=k+1;
    z=f(x)*(x-X)/(f(x)-f(X));
    X=x;
    x=x-z;
    err=abs(z/x);
    fprintf(' %i \t  %19.12e \t  %5.1e  \t  %5.1e \n',k,x,err,abs(1-x/xe))
    %fprintf('\\, %i \\, & \\,\\, %19.15f \\,\\, & \\,\\, %5.1e & \\,\\, %5.1e \\\\\\hline \n',k,x,err,abs(1-x/xe))
end
fprintf('\n\n')


function g=f(x)
%g=x^3+2*x+2;
g=exp(-x)-(2+x);


function table2_2

%  included figure 2.4

%  Input:
%	a = left endpoint of interval
%	b = right endpoint of interval
%	tol = tolerance for stopping bisection method
%	f(x) This is at end of file

a=-1.5; b=2.5;

mid=0.5*(a+b);
tol=10^(-6);
err=10*tol;
sol=2.1;

%%% bisection procedure
it=0;
fprintf('\n RIE = relative iterative error \n\n')
fprintf(' k \t\t x_k  \t \t Error \t\t RIE \n')
while err>tol
    old=mid;
    fmid=f(mid);
    if f(a)*fmid<0
        b=mid;
    elseif f(b)*fmid<0
        a=mid;
    else
        break
    end
    mid=0.5*(a+b);
    it=it+1;
    err=abs((mid-old)/mid);
    E(it)=abs(mid-sol);
    ER(it)=err;
    fprintf(' %i \t %19.15f \t %5.1e \t %5.1e \n',it,mid,E(it),err)
    %fprintf('\\, %i \\, & \\,\\, %19.15f \\,\\, & \\,\\, %5.1e \\,\\, & \\,\\, %5.1e \\\\\\hline \n',it,mid,E(it),err)

end
fprintf('\n')

clf
% get(gcf)
set(gcf,'Position', [25 1115 658 230])
subaxis(1,1,1,1,'MT',0.01,'MB',0.18,'MR',-0.02,'ML',0.06,'P',0.04)
co = [0 0 1;
    0 0.5 0;
    1 0 0;
    0 0.75 0.75;
    0.75 0 0.75;
    0.75 0.75 0;
    0.25 0.25 0.25];
set(groot,'defaultAxesColorOrder',co)

% plot error
semilogy(1:it,E,'--or','LineWidth',1.6,'MarkerSize',7)
hold on
semilogy(1:it,ER,'--ob','LineWidth',1.6,'MarkerSize',7)
legend({' Error',' Relative Iterative Error'},'AutoUpdate','off','Location','NorthEast','FontSize',16,'FontWeight','bold')
axis([0 20  1e-7 1])
set(gca,'ytick',[1e-6 1e-3 1])
xlabel('Iteration Step')
ylabel('Error')
grid on
box on
set(gca,'FontSize',16,'FontWeight','bold')

%exportgraphics(gcf,'/Users/mark/Desktop/exam21.eps')

function g=f(x)
g=(x-0.1)*(x-2.1)*(x+1.1);
%g=exp(-x)-(2+x);








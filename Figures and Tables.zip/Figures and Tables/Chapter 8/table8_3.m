function table8_3

% well-conditioned:  icase=1
% ill-conditioned: icase=2

icase=2;

fprintf('\n n     QR-QcRc     Q-Qc     R-Rc   (Qc^T)Qc-I    kappa \n')

for ins=1:5

    if ins==1
        n=100;
    elseif ins==2
        n=500;
    elseif ins==3
        n=1000;
    elseif ins==4
        n=2000;
    elseif ins==5
        n=4000;
    end

    % find random Q
    [Q1,R1]=qr(rand(n,n));

    % find random R
    Rp=rand(n,n);
    for j=1:n-1
        Rp(j+1:n,j)=0;
    end
    if icase==2
        % ill-condtioned matrix
        Rp=Rp+2*eye(n);
    elseif icase==1
        % well-conditioned matrix
        Rp=Rp+n*eye(n);
    end

    A=Q1*Rp;
    [Q,R]=qr(A);

    % given QR, find equivalent with positive diagonals in R
    itest=0;
    for i=1:n
        if R(i,i)<0
            R(i,i)=-R(i,i);
            Q(:,i)=-Q(:,i);
            itest=itest+1;
            if i<n
                R(i,i+1:n)=-R(i,i+1:n);
            end
        end
    end
    %R

    con=cond(A,inf);
    e1=norm(Q1*Rp-Q*R,inf)/norm(A,inf);
    e2=norm(Q1-Q,inf)/norm(Q1,inf);
    e3=norm(Rp-R,inf)/norm(Rp,inf);

    % format for book
    fprintf('%i & %5.1e  & %5.1e & %5.1e  & %5.1e  & %5.0e \n',n,e1,e2,e3,norm(Q'*Q-eye(n),inf),con)

    % format for lecture
    %fprintf('%i   %5.1e   %5.1e   %5.1e   %5.1e   %5.1e \n',n,e1,e2,e3,norm(Q'*Q-eye(n),inf),con)

end

fprintf('\n')


















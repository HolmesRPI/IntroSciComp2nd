function fig8_18

%  generate data for regression
% nd=80;
% xd=linspace(0,1,nd);
% yd=exp(-10*(xd-0.6).^2).*cos(6*pi*xd);
% dis=0.4*(rand(1,nd)-0.5);
% yd=yd+dis;
% 
% data=[xd; yd];
% save('/Users/mark/Desktop/data8_14C.txt','data','-ascii')

data=importdata('data8_14C.txt');
xd=data(1,:);
yd=data(2,:);
nd=length(xd);

% smoother
D=zeros(nd-2,nd);
for i=1:nd-2
    D(i,i)=1;  D(i,i+1)=-2; D(i,i+2)=1;
end
lambda=20;
A=eye(nd);
y=(inv(A'*A+lambda*D'*D)*A'*yd');

clf
% get(gcf)
set(gcf,'Position', [7 1115 658 230])
co = [0 0 1;
    0 0.5 0;
    1 0 0;
    0 0.75 0.75;
    0.75 0 0.75;
    0.75 0.75 0;
    0.25 0.25 0.25];
set(groot,'defaultAxesColorOrder',co)

plot(xd,yd,'-b','LineWidth',1)
hold on
axis([0 1 -1.1 1.1])
xlabel('x-axis')
ylabel('y-axis')
set(gca,'XTick',[0 0.2 0.4 0.6 0.8 1.0])
grid on
set(gca,'FontSize',14,'FontWeight','bold')

%plot(xd,y,'r','LineWidth',1)

%exportgraphics(gcf,'/Users/mark/Desktop/treg.eps')









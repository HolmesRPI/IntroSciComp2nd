function table3_7

%  Solve  f(x,y) = 0, g(x,y) = 0  using Newton's method

%  Input:
%	xa = starting point
%	tol = tolerance for stopping
%	f(x) and df(x) are at end of file

x=[1;1];
tol=10^(-12);
it=0;
fprintf('\n k \t\t x \t\t y \t\t RIE \n')
fprintf('\\, %i \\, & \\,\\, %14.10f \\,\\, & \\,\\, %14.10f \\,\\, & \\\\\\hline \n',it,x(1),x(2))
err=10*tol;
while err>tol
    z=-inv(J(x))*f(x);
    it=it+1;
    x=x+z;
    err=norm(z,inf)/norm(x,inf);

    fprintf('\\, %i \\, & \\,\\, %14.10f \\,\\, & \\,\\, %14.10f \\,\\, & \\,\\, %5.1e  \\\\\\hline \n',it,x(1),x(2),err)

end
fprintf('\n')


function z=f(x)
z=zeros(2,1);
z(1)=x(1)^2+4*x(2)^2-1;
z(2)=4*x(1)^2+x(2)^2-1;

function z=J(x)
z=zeros(2,2);
z(1,1)=2*x(1);  z(1,2)=8*x(2);
z(2,1)=8*x(1);  z(2,2)=2*x(2);





function fig1_9

nes=10000;
%%%%% y=(sqrt(1+x^2)-1)/x^2
exs=linspace(-10,-6,nes);

for i=1:nes
    xr(i)=10^exs(i);
    fr(i)=f(xr(i));
    xl(i)=-10^exs(i);
    fl(i)=f(xl(i));
end

clf
% get(gcf)
set(gcf,'Position', [25 1115 658 230])
subaxis(1,1,1,1,'MT',0.01,'MB',0.2,'MR',-0.01,'ML',0.03,'P',0.04)
co = [0 0 1;
    0 0.5 0;
    1 0 0;
    0 0.75 0.75;
    0.75 0 0.75;
    0.75 0.75 0;
    0.25 0.25 0.25];
set(groot,'defaultAxesColorOrder',co)

hold on
plot(xr,fr,'b','LineWidth',1.2)
plot(xl,fl,'b','LineWidth',1.2)
grid on
box on
axis([-3e-7 3e-7 -0.05 0.8])
xlabel('x-axis')
ylabel('y-axis')
set(gca,'FontSize',16,'FontWeight','bold')
hold off

%exportgraphics(gcf,'/Users/mark/Desktop/ex1.eps')

function y=f(x)
y=(sqrt(1+x^2)-1)/x^2;















function fig1_8

% compute the values of the ratio
n=8000;
exs=linspace(-18,-10,n);
J=1;
for i=1:n
    k(i)=10^exs(i);
    y(i)=(sqrt(16+k(i))-4)/k(i);
    if y(i)==0
        J=i;
    end
end
J
k(J)/eps

clf
% get(gcf)
set(gcf,'Position', [25 1115 658 230])
subaxis(1,1,1,1,'MT',0.01,'MB',0.2,'MR',-0.01,'ML',0.06,'P',0.04)
co = [0 0 1;
    0 0.5 0;
    1 0 0;
    0 0.75 0.75;
    0.75 0 0.75;
    0.75 0.75 0;
    0.25 0.25 0.25];
set(groot,'defaultAxesColorOrder',co)

semilogx(k(1:J),zeros(1,J),'b-','LineWidth',2)
hold on

% plot the results
for i=1:n
    for j=J+1:n
        if y(j)>y(j-1)
            JJ=j-1;
            break
        end
    end
    semilogx(k(J:JJ),y(J:JJ),'b-','LineWidth',1.8)
    J=JJ+1;
    semilogx(k(JJ:JJ+1),y(JJ:JJ+1),'b--','LineWidth',1)
    if k(JJ)>1e11
        break
    end
end
JJ

semilogx(k(JJ:n),y(JJ:n),'b-','LineWidth',1.8)
axis([1e-18 1e-10 -0.02 0.1875])
set(gca,'ytick',[0 0.0625 0.1250 0.1875])
set(gca,'yTickLabel',{'0 ';'1/16 ';'1/8 ';'3/16 '})
set(gca,'xtick',[1e-18 1e-14 1e-10 1e-6 1e-2])
grid on
xlabel('k-axis')
ylabel('y-axis')
set(gca,'FontSize',16,'FontWeight','bold')
hold off

%exportgraphics(gcf,'/Users/mark/Desktop/sqrtA.eps')











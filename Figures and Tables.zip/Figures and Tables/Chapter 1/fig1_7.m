function fig1_7

%  this file includes horner, estrin, and even/odd separation methods
%  it only plots results for horner

%  poly coeffs
a(9)=1;
a(8)=-8;
a(7)=+28;
a(6)=-56;
a(5)=+70;
a(4)=-56;
a(3)=+28;
a(2)=-8;
a(1)=+1;

d=0.02;
nx=1000;
x=linspace(1-d,1+d,nx);
for i=1:nx
    b=a(9);
    for ii=1:8
        b=a(9-ii)+x(i)*b;
    end
    horner(i)=b;
    e1 = a(1) + a(2)*x(i) + (a(3)+a(4)*x(i))*x(i)^2;
    e2 = ( a(5) + a(6)*x(i) + (a(7)+a(8)*x(i))*x(i)^2 )*x(i)^4 + a(9)*x(i)^8;
    estrin(i)=e1+e2;
    y(i)=x(i)^8-8*x(i)^7+28*x(i)^6-56*x(i)^5+70*x(i)^4-56*x(i)^3+28*x(i)^2-8*x(i)+1;
    yy(i)=(x(i)-1)^8;
    z=x(i)^2;
    separ(i)=a(1)+a(3)*z+a(5)*z^2+a(7)*z^3+a(9)*z^4+x(i)*(a(2)+a(4)*z+a(6)*z^2+a(8)*z^3);
end

clf
% get(gcf)
set(gcf,'Position', [25 1115 658 230])
subaxis(1,1,1,1,'MT',0.08,'MB',0.16,'MR',-0.01,'ML',0.02,'P',0.04)
co = [0 0 1;
    0 0.5 0;
    1 0 0;
    0 0.75 0.75;
    0.75 0 0.75;
    0.75 0.75 0;
    0.25 0.25 0.25];
set(groot,'defaultAxesColorOrder',co)

plot(x,horner, 'r','LineWidth',1)
hold on
plot(x,yy, '--b','LineWidth',2.5)
grid on
box on
legend({' Using Horner',' Using (1.3)'},'Location','North','FontSize',16,'FontWeight','bold')
axis([1-d 1+d -2e-14 4e-14])
set(gca,'xtick',[0.98 0.99 1 1.01 1.02])
xlabel('x-axis')
ylabel('y-axis')
set(gca,'FontSize',16,'FontWeight','bold')

%exportgraphics(gcf,'/Users/mark/Desktop/horn.eps')














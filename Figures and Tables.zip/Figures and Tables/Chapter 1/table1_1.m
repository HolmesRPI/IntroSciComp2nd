function table1_1

fprintf('\n n               S(n)-s(n) ')
% loop for increasing values of n
for ic=1:6
    n=10^ic;

    % sum series from large to small
    S=0;
    for jj=1:n
        S=S+1/jj;
    end

    % sum series from small to large
    s=0;
    for j=n:-1:1
        s=s+1/j;
    end


    % print out S(n)-s(n)
    fprintf('\n %i     \t %7.2e ',n,S-s)
    %fprintf('\n %i  &  %12.2e \\\\',n,S-s)  % used for format in text

end
fprintf('\n\n')

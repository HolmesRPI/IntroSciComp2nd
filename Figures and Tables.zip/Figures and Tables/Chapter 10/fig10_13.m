function fig10_13

%%%%  ICA solutions for various max theta values

%%% this requires the subaxis and parseArgs files

% generate data
m=6000;
t=linspace(0,10,m);
w1=pi;
w2=1.7*pi;
x=zeros(m,2);
% mixing coefficients
M11=1; M12=2;
M21=1; M22=-2;
for it=1:m
    %     S(it,1) = sin(w1*t(it));
    %     S(it,2) = sin(w2*t(it)-5);
    S(it,1) = sin(w1*t(it));
    S(it,2) = (1/5)*(2.5*sin(w2*t(it)-1)+0.3*t(it)*(10-t(it)));
end

%%%% center S
sM=sum(S)/m;
S=S-sM;

for it=1:m
    X(it,1)=M11*S(it,1) + M12*S(it,2);
    X(it,2)=M21*S(it,1) + M22*S(it,2);
end

xM=sum(X)/m;
X=X-xM;

XX=X'*X/m;
[UX,SX,VX]=svd(XX);
D5=[1/sqrt(SX(1,1)) 0; 0 1/sqrt(SX(2,2))];

y=zeros(m,2);
for it=1:m
    y(it,:)=D5*VX'*X(it,:)';
end

clf
%get(gcf);
set(gcf,'Position', [2 830 626 515])
co = [0 0 1;
    0 0.5 0;
    1 0 0;
    0 0.75 0.75;
    0.75 0 0.75;
    0.75 0.75 0;
    0.25 0.25 0.25];
set(groot,'defaultAxesColorOrder',co)

% compute and then plot for particular theta values
theta=[0.4344    0.9349    1.4354    1.9359]*pi;
for ia=1:4
    V=[[ cos(theta(ia)) -sin(theta(ia))];[ sin(theta(ia)) cos(theta(ia))]];
    for it=1:m
        s(it,1)=V(1,1)*y(it,1)+V(1,2)*y(it,2);
        s(it,2)=V(2,1)*y(it,1)+V(2,2)*y(it,2);
    end

    if ia==1

        subaxis(4,2,1,1,'MT',0.04,'MB',0.07,'MR',-0.005,'ML',0.02,'P',0.02)

        %plot(t,S(:,1),'--b','LineWidth',1.6)
        hold on
        axis([0 10 -2 2])
        plot(t,s(:,1),'r','LineWidth',1.6)
        say2=['s_1*'];
        text(4.5,3.0,say2,'FontSize',18,'FontWeight','bold')
        grid on
        box on
        set(gca,'FontSize',14,'FontWeight','bold')

        subaxis(4,2,2,1)
        %plot(t,S(:,2),'--b','LineWidth',1.6)
        hold on
        axis([0 10 -2 2])
        plot(t,s(:,2),'r','LineWidth',1.6)
        say2=['s_2*'];
        text(4.5,3.0,say2,'FontSize',18,'FontWeight','bold')
        grid on
        box on
        set(gca,'FontSize',14,'FontWeight','bold');

    elseif ia==2

        subaxis(4,2,1,2)
        %plot(t,S(:,1),'--b','LineWidth',1.6)
        hold on
        plot(t,s(:,1),'r','LineWidth',1.6)
        axis([0 10 -2 2])
        grid on
        box on
        set(gca,'FontSize',14,'FontWeight','bold')

        subaxis(4,2,2,2)
        %plot(t,S(:,2),'--b','LineWidth',1.6)
        hold on
        axis([0 10 -2 2])
        plot(t,s(:,2),'r','LineWidth',1.6)
        grid on
        box on
        set(gca,'FontSize',14,'FontWeight','bold')

    elseif ia==3

        subaxis(4,2,1,3)
        %plot(t,S(:,1),'--b','LineWidth',1.6)
        hold on
        axis([0 10 -2 2])
        plot(t,s(:,1),'r','LineWidth',1.6)
        grid on
        box on
        set(gca,'FontSize',14,'FontWeight','bold')

        subaxis(4,2,2,3)
        %plot(t,S(:,2),'--b','LineWidth',1.6)
        hold on
        axis([0 10 -2 2])
        plot(t,s(:,2),'r','LineWidth',1.6)
        grid on
        box on
        set(gca,'FontSize',14,'FontWeight','bold')

    elseif ia==4

        subaxis(4,2,1,4)
        %plot(t,S(:,1),'--b','LineWidth',1.6)
        hold on
        axis([0 10 -2 2])
        plot(t,s(:,1),'r','LineWidth',1.6)
        xlabel('t-axis')
        grid on
        box on
        set(gca,'FontSize',14,'FontWeight','bold')

        subaxis(4,2,2,4)
        %plot(t,S(:,2),'--b','LineWidth',1.6)
        hold on
        axis([0 10 -2 2])
        plot(t,s(:,2),'r','LineWidth',1.6)
        xlabel('t-axis')
        grid on
        box on
        set(gca,'FontSize',14,'FontWeight','bold')

    end
end

%exportgraphics(gcf,'/Users/mark/Desktop/ww.eps')





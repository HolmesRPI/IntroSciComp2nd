function fig10_1

%  this file also produces fig 10_2
% this needs file arrowhead.m

% A = [word length, lines]
n=20;
word{1}='bag';  words(1)=223; y1908(1)=0.00167;  y2008(1)=0.0029;
word{2}='across';  words(2)=117; y1908(2)=0.00167;  y2008(2)=0.0029;
word{3}='if';  words(3)=101; y1908(3)=0.176;  y2008(3)=0.173;
word{4}='insane';  words(4)=40; y1908(4)=0.00167;  y2008(4)=0.0029;
word{5}='by';  words(5)=217; y1908(5)=0.00167;  y2008(5)=0.0029;
word{6}='detective';  words(6)=41; y1908(6)=0.0004;  y2008(6)=0.001;
word{7}='relief';  words(7)=153; y1908(7)=0.00167;  y2008(7)=0.0029;
word{8}='slope';  words(8)=87; y1908(8)=0.00167;  y2008(8)=0.0029;
word{9}='scoundrel';  words(9)=4; y1908(9)=0.00167;  y2008(9)=0.0029;
word{10}='look';  words(10)=212; y1908(10)=0.019;  y2008(10)=0.028;
word{11}='neither';  words(11)=51; y1908(11)=0.00167;  y2008(11)=0.0029;
word{12}='pretentious';  words(12)=70; y1908(12)=0.00167;  y2008(12)=0.0029;
word{13}='solid';  words(13)=259; y1908(13)=0.00167;  y2008(13)=0.0029;
word{14}='gone';  words(14)=90; y1908(14)=0.011;  y2008(14)=0.01;
word{15}='fun';  words(15)=78; y1908(15)=0.001;  y2008(15)=0.003;
word{16}='therefore';  words(16)=13; y1908(16)=0.00167;  y2008(16)=0.0029;
word{17}='generality';  words(17)=22; y1908(17)=0.00167;  y2008(17)=0.0029;
word{18}='month';  words(18)=57; y1908(18)=0.0076;  y2008(18)=0.007;
word{19}='blot';  words(19)=185; y1908(19)=0.00167;  y2008(19)=0.0029;
word{20}='infectious';  words(20)=86; y1908(20)=0.00167;  y2008(20)=0.0029;

for i=1:n
    A(i,1)=length(word{i});
    A(i,2)=words(i);
end

[m n]=size(A)
means=mean(A)

for i=1:20
    D(i,1)=A(i,1)-means(1);
    D(i,2)=A(i,2)-means(2);
end
%D

Xc=max(abs(D(:,1))); Yc=max(abs(D(:,2)));
for i=1:20
    DD(i,1)=D(i,1)/Xc;
    DD(i,2)=D(i,2)/Yc;
end

%  DD=U*S*V'
[U,S,V] = svd(DD);
ss=size(S)

%S
S(1,1)
S(2,2)

% fig 9.1
figure(1)

lam=( dot(DD(:,1),DD(:,1))-dot(DD(:,2),DD(:,2)) )/dot(DD(:,1),DD(:,2))
if dot(DD(:,1),DD(:,2)) > 0
    alp=0.5*(-lam+sqrt(lam^2+4));
else
    alp=0.5*(-lam-sqrt(lam^2+4));
end
slope=alp*Yc/Xc

xL=0;
yL=means(2)-slope*means(1);

xR=max(A(:,1));
yR=means(2)+slope*(xR-means(1));

clf
% get(gcf)
set(gcf,'Position', [25 1115 658 230])
subaxis(1,1,1,1,'MT',0.01,'MB',0.18,'MR',-0.02,'ML',0.05,'P',0.04)
co = [0 0 1;
    0 0.5 0;
    1 0 0;
    0 0.75 0.75;
    0.75 0 0.75;
    0.75 0.75 0;
    0.25 0.25 0.25];
set(groot,'defaultAxesColorOrder',co)

plot([xL xR],[yL yR],'r','LineWidth',1.5)
hold on
plot(A(:,1),A(:,2),'ob','MarkerSize',8,'LineWidth',2)
axis([0 max(A(:,1)) 0 yL])
xlabel('Number of Letters')
ylabel('Number of Words')
set(gca,'Ytick',[0 50 100 150 200 250])
grid on
box on
set(gca,'FontSize',16,'FontWeight','bold')

%exportgraphics(gca,'/Users/mark/Desktop/word.eps')


% fig 9.2
figure(2)

alpha=V(1,1)/V(2,1);
xL=-max(DD(:,1));
yL=alpha*xL;

xR=max(DD(:,1));
yR=alpha*xR;

clf
% get(gcf)
set(gcf,'Position', [24 616 470 411])
co = [0 0 1;
    0 0.5 0;
    1 0 0;
    0 0.75 0.75;
    0.75 0 0.75;
    0.75 0.75 0;
    0.25 0.25 0.25];
set(groot,'defaultAxesColorOrder',co)

plot([xL xR],[yL yR],'r','LineWidth',1.5)
hold on
plot(DD(:,1),DD(:,2),'ob','MarkerSize',9,'LineWidth',2.2)
axis([-1 1 -1 1])
axis square

text(0.43,-0.8,'v_1','FontSize',20,'FontWeight','bold','Color','k')
text(0.5,0.7,'v_2','FontSize',20,'FontWeight','bold','Color','k')

x2=1/sqrt(1+alpha^2); y2=alpha*x2;
arrowhead([0 x2],[0 y2],'k',[1.3,1.3],3);
plot([0 x2],[0 y2],'k','LineWidth',1.8)

beta=V(1,2)/V(2,2);
x2=1/sqrt(1+beta^2); y2=beta*x2;
arrowhead([0 x2],[0 y2],'k',[1.3,1.3],3);
plot([0 x2],[0 y2],'k','LineWidth',1.8)

axis square
set(gca,'ytick',[-1 0 1])
set(gca,'xtick',[-1 0 1])

xlabel('x-axis')
ylabel('y-axis')
grid on
box on
set(gca,'FontSize',18,'FontWeight','bold')

%exportgraphics(gca,'/Users/mark/Desktop/wpca.eps')
















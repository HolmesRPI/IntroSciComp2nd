function fig10_3

%  the data is taken to be within the ellipsoid x^2+4y^2+8z^2=1

n=200;

% ellipsoidal data
for i=1:n
    x(i)=2*rand-1;
    y(i)=(2*rand-1)*0.5*sqrt(1-x(i)^2);
    z(i)=(2*rand-1)*0.5*sqrt(1-x(i)^2-4*y(i)^2)/3;
end

%  rotate data
theta=pi/3;  phi=-pi/5;
Ry=[[cos(theta) 0 sin(theta)];[0 1 0];[-sin(theta) 0 cos(theta)]]
Rz=[[cos(phi) -sin(phi) 0];[sin(phi) cos(phi) 0];[0 0 1]]
X=zeros(n,3);
Q=zeros(n,3);
for i=1:n
    %    [x(i) y(i) z(i)]'
    X(i,:)=Ry*Rz*[x(i) y(i) z(i)]';
    Q(i,:)=Ry*Rz*[0 y(i) z(i)]';
end
xx=1.2;
P1=Ry*Rz*[xx 0 0]';
P2=Ry*Rz*[-xx 0 0]';
yy=1.2;
Q1=Ry*Rz*[0 yy 0]';
Q2=Ry*Rz*[0 -yy 0]';


figure(1)
clf
% get(gcf)
set(gcf,'Position', [8 925 560 420])
co = [0 0 1;
    0 0.5 0;
    1 0 0;
    0 0.75 0.75;
    0.75 0 0.75;
    0.75 0.75 0;
    0.25 0.25 0.25];
set(groot,'defaultAxesColorOrder',co)

scatter3(X(:,1),X(:,2),X(:,3),'MarkerEdgeColor','k','MarkerFaceColor',[3/255 192/255 60/255],'LineWidth',1.2)

hold on
plot3([P1(1) P2(1)],[P1(2) P2(2)],[P1(3) P2(3)],'Color',[255/255 8/255 0/255],'LineWidth',2.4)
axis equal
axis([-1 1 -1 1 -1 1])
view(-46, 10)
set(gca,'xtick',[-1 0 1])
set(gca,'ytick',[-1 0 1])
set(gca,'ztick',[-1 0 1])
xlabel('p_1')
ylabel('p_2')
zlabel('p_3')
set(gca,'FontSize',18,'FontWeight','bold')
%ax.GridAlpha=1;
% H=gca;
% H.LineWidth=1;
set(gca,'LineWidth',0.5)
plot3([-1 -1],[-1 1],[-1 -1],'Color','k','LineWidth',1.5)
plot3([-1 1],[-1 -1],[-1 -1],'Color','k','LineWidth',1.5)
plot3([-1 -1],[1 1],[-1 1],'Color','k','LineWidth',1.5)
box on

%exportgraphics(gca,'/Users/mark/Desktop/dat1.eps')

figure(2)
clf
% get(gcf)
set(gcf,'Position', [11 416 560 420])
co = [0 0 1;
    0 0.5 0;
    1 0 0;
    0 0.75 0.75;
    0.75 0 0.75;
    0.75 0.75 0;
    0.25 0.25 0.25];
set(groot,'defaultAxesColorOrder',co)

plot(Q(:,2),Q(:,3),'o','MarkerSize',7,'MarkerEdgeColor','k','MarkerFaceColor',[3/255 192/255 60/255],'LineWidth',1.2)

hold on
plot([Q1(2) Q2(2)],[Q1(3) Q2(3)],'--k','LineWidth',2.4)
plot(0,0,'.r','MarkerSize',30)
axis equal
grid on
axis([-0.5 0.5 -0.5 0.5])
set(gca,'xtick',[-0.5 0 0.5])
set(gca,'ytick',[-0.5 0 0.5])
set(gca,'FontSize',18,'FontWeight','bold')
set(gca,'LineWidth',0.8)

%exportgraphics(gca,'/Users/mark/Desktop/dat2.eps')














function fig10_4

%  this requires the file arrow3.m

n=200;

% ellipsoidal data
for i=1:n
    x(i)=2*rand-1;
    y(i)=(2*rand-1)*0.5*sqrt(1-x(i)^2);
    z(i)=(2*rand-1)*0.5*sqrt(1-x(i)^2-4*y(i)^2)/3;
end

%  rotate data
theta=pi/3;  phi=-pi/5;
Ry=[[cos(theta) 0 sin(theta)];[0 1 0];[-sin(theta) 0 cos(theta)]]
Rz=[[cos(phi) -sin(phi) 0];[sin(phi) cos(phi) 0];[0 0 1]]

X=zeros(n,3);
Q=zeros(n,3);
for i=1:n
    %    [x(i) y(i) z(i)]'
    X(i,:)=Ry*Rz*[x(i) y(i) z(i)]';
    Q(i,:)=Ry*Rz*[0 y(i) z(i)]';
end
xx=1.2;
P1=Ry*Rz*[xx 0 0]';
P2=Ry*Rz*[-xx 0 0]';
yy=1.2;
Q1=Ry*Rz*[0 yy 0]';
Q2=Ry*Rz*[0 -yy 0]';

% calculate svd
[U,S,V] = svd(X);
V

clf
% get(gcf)
set(gcf,'Position', [8 925 560 420])
co = [0 0 1;
    0 0.5 0;
    1 0 0;
    0 0.75 0.75;
    0.75 0 0.75;
    0.75 0.75 0;
    0.25 0.25 0.25];
set(groot,'defaultAxesColorOrder',co)

%scatter3(X(:,1),X(:,2),X(:,3),'MarkerEdgeColor','k','MarkerFaceColor',[0 0.75 0.75])
acol=0/255; bcol=200/255; ccol=0;
scatter3(X(:,1),X(:,2),X(:,3),'MarkerEdgeColor','k','MarkerFaceColor',[acol bcol ccol],'LineWidth',1)

axis equal
axis([-1 1 -1 1 -1 1])
%view(110, 10)
view(35, 10)
%surf(A1,A2,F)
%axis([xa xb ya yb 0 Emax])
set(gca,'xtick',[-1 0 1])
set(gca,'ytick',[-1 0 1])
set(gca,'ztick',[-1 0 1])
xlabel('x')
ylabel('y')
zlabel('z')

p0=[0 0 0];
a1=1.4*sign(V(3,1));
p1=[a1*V(1,1) a1*V(2,1) a1*V(3,1)];
a2=0.9*sign(V(3,2));
p2=[a2*V(1,2) a2*V(2,2) a2*V(3,2)];
a3=-0.8*sign(V(3,3));
p3=[a3*V(1,3) a3*V(2,3) a3*V(3,3)];
hold on
arrow3(p0,p1,'3_v',[1.4 1.4 1.4])
arrow3(p0,p2,'3_v',[1.4 1.4 1.4])
arrow3(p0,p3,'3_v',[1.4 1.4 1.4])

H=gca;
H.LineWidth=1;
box on

set(gca,'FontSize',18,'FontWeight','bold')
hold off

%exportgraphics(gca,'/Users/mark/Desktop/dataA.eps')














function fig10_7

%%% this requires the subaxis and parseArgs files

s(1)=4.220; s(2)=1.2228; s(3)=0.9237; s(4)=0.8631;
s(5)=0.3446; s(6)=0.2308; s(7)=0.1186; s(8)=0.0413;

s(1)=18.8063; s(2)=5.4178; s(3)=4.2784; s(4)=3.1603; s(5)=1.6044; s(6)=1.2829; s(7)=0.6506; s(8)=0.1837;

for i=1:7
    j(i)=i;
    E(i)=norm(s(i+1:8),2)^2/norm(s,2)^2;
end
j(8)=8;
E(8)=0;

avg=norm(s,1)/8

E

clf
% get(gcf)
set(gcf,'Position', [25 930 660 420])
co = [0 0 1;
    0 0.5 0;
    1 0 0;
    0 0.75 0.75;
    0.75 0 0.75;
    0.75 0.75 0;
    0.25 0.25 0.25];
set(groot,'defaultAxesColorOrder',co)

subaxis(2,1,1,'MT',0.02,'MB',0.1,'MR',-0.03,'ML',0.04,'P',0.05)
plot(j,s,'o--','Linewidth',2,'MarkerSize',9)
hold on
ylabel('Sigma')
grid on
box on
set(gca,'FontSize',16,'FontWeight','bold')
hold off

subaxis(2,1,2)
plot(j,E,'o--','Linewidth',2,'MarkerSize',9)
hold on
xlabel('k-axis')
ylabel('Error')
grid on
box on
set(gca,'FontSize',16,'FontWeight','bold')
hold off

%exportgraphics(gcf,'/Users/holmes/Desktop/pcaE.eps')










function fig10_6

%  this needs data file crime_data_2009.txt

%  finds best 7D-planar fit, where variable from column IC is planar
%  function of the other 7 variables. After this, it compares test data
%  for column IC (using its 7 variables values) with the
%  plane prediction

% Columns: 1=Pop; 2=Murder; 3=Rape; 4=Robbery; 5=Assault; 6=Burglary;
%          7=Larceny; 8=Vehicle

% pick variable IC=2,8
IC=2

load crime_data_2009.txt
AA=crime_data_2009(:,:);
[m n]=size(AA)
means=mean(AA)

% interchange IC column with first column
for i=1:m
    z=AA(i,1);
    AA(i,1)=AA(i,IC);
    AA(i,IC)=z;
end

%  A=traing data   B = testing data
i=0;
for ii=1:2:m-1
    i=i+1;
    A(i,:)=AA(ii,:);
    B(i,:)=AA(ii+1,:);
end
[m n]=size(A)
means=mean(A)

% normalization of A
D=zeros(m,n);
for j=1:n
    D(:,j)=A(:,j)-means(j)*ones(m,1);
end
DD=zeros(m,n);
for j=1:n
    %    DM(j)=max(abs(D(:,j)));
    DM(j)=norm(D(:,j),2)/sqrt(m);
    DD(:,j)=D(:,j)/DM(j);
end

%  DD=U*S*V'
[U,S,V] = svd(DD);
ss=size(S)

for i=1:ss(2)
    id(i)=i;
    sigmas(i)=S(i,i);
    %    	fprintf(' %i   %19.14e \n',i,S(i,i));
end
sigmas

V(:,1)

Q=[V(2:8,1) V(2:8,2) V(2:8,3) V(2:8,4) V(2:8,5) V(2:8,6) V(2:8,7)];

%  normalize testing data (using same normalization as used for A)
[M N]=size(B)
DB=zeros(M,N);
for j=1:N
    DB(:,j)=B(:,j)-means(j)*ones(M,1);
end
DDB=zeros(M,N);
for j=1:N
    DDB(:,j)=DB(:,j)/DM(j);
end

DD(m,:)
DDB(m,:)

for i=1:M
    alpha=Q\DDB(i,2:N)';
    PP(i)=dot(alpha,V(1,1:7)');
    AP(i)=DDB(i,1);
end

clf
% get(gcf)
set(gcf,'Position', [1 1046 367 299])
co = [0 0 1;
    0 0.5 0;
    1 0 0;
    0 0.75 0.75;
    0.75 0 0.75;
    0.75 0.75 0;
    0.25 0.25 0.25];
set(groot,'defaultAxesColorOrder',co)

plot(AP,PP,'ob','MarkerSize',8,'LineWidth',2)
hold on

if IC==8
    text(1.5,-0.5,'Vehicle','FontSize',16,'FontWeight','bold')
    LX=-1; RX=3; LY=-1; RY=3;
elseif IC==2
    text(1.5,-7,'Murder','FontSize',16,'FontWeight','bold')
    LX=-1; RX=3; LY=-15; RY=54;
end

axis([LX RX LY RY])

plot([LX RX],[LX RX],'r','LineWidth',1.6)

axis square
xlabel('Training')
ylabel('Testing')
grid on
box on
set(gca,'FontSize',16,'FontWeight','bold')


% if IC==8
%     exportgraphics(gca,'/Users/mark/Desktop/v.eps')
% elseif IC==2
%     exportgraphics(gca,'/Users/mark/Desktop/m.eps')
% end

















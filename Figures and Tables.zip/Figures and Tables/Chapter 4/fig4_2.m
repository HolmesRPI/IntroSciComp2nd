function fig4_2

k=1;
kc=10;
a=2+k/kc;
n=30;

for in=1:n
    ind(in)=in;
    y(in)=a+2*cos(in*pi/(n+1));
end

clf
% get(gcf)
set(gcf,'Position', [25 1115 658 230])
subaxis(1,1,1,1,'MT',0.01,'MB',0.18,'MR',-0.02,'ML',0.06,'P',0.04)
co = [0 0 1;
    0 0.5 0;
    1 0 0;
    0 0.75 0.75;
    0.75 0 0.75;
    0.75 0.75 0;
    0.25 0.25 0.25];
set(groot,'defaultAxesColorOrder',co)

hold on
plot(ind,y,'o','LineWidth',2,'MarkerSize',7)
%axis([a b -2 2]);

ylabel('Eigenvalue')
xlabel('i-axis')
grid on
box on
set(gca,'FontSize',14,'FontWeight','bold')

%exportgraphics(gcf,'/Users/holmes/Desktop/fpu.eps')


function table4_12

n=[200 400 600 800 1000 2000 4000];

% this is to let program use commands once before timing begins
A=rand(3,3);
[L,U] = lu(A);
[Q,R] = qr(A);
[UU,S,V] = svd(A);

tLU=Inf;
tQR=Inf;
tSVD=Inf;

fprintf('\n n  \t   LU (sec) \t  QR  \t SVD \n')

% iteration for matrix size
IR=length(n);
for i=1:IR
    tLU=Inf;
    tQR=Inf;
    tSVD=Inf;

    % NR = number of trials run for timing
    if n(i)<2000
        NR=50;
    else
        NR=15;
    end

    % timing iteration
    for r=1:NR
        A=rand(n(i),n(i));
        tic
        [L,U] = lu(A);
        %lut(i)=toc+lut(i);
        if toc<tLU
            tLU=toc;
        end
        tic
        [Q,R] = qr(A);
        %qrt(i)=toc+qrt(i);
        if toc<tQR
            tQR=toc;
        end
        tic
        [UU,S,V] = svd(A);
        %svdt(i)=toc+svdt(i);
        if toc<tSVD
            tSVD=toc;
        end
        clear A L U Q R UU S V
    end

    %     lut(i)=lut(i)/NR;
    %     qrt(i)=qrt(i)/(NR*lut(i));
    %     svdt(i)=svdt(i)/(NR*lut(i));
    tlu(i)=tLU;
    tqr(i)=tQR/tLU;
    tsvd(i)=tSVD/tLU;
    fprintf(' \\, %d  \\, & %5.4f  & %5.1f & %5.1f   \\\\ \\hline \n',n(i),tlu(i),tqr(i),tsvd(i))
end

fprintf('\n\n')
%fprintf('\n\n',n(i),lut(i),qrt(i),svdt(i))

% this is the data for Table 8.10
for ii=1:IR
    qrt(ii)=tlu(ii)*tqr(ii);
    svdt(ii)=tlu(ii)*tsvd(ii);
    fprintf(' \\, %d  \\,  & %5.4f  & %8.4f & %8.4f   \\\\ \\hline  \n',n(ii),tlu(ii),qrt(ii),svdt(ii))
end
fprintf('\n\n')



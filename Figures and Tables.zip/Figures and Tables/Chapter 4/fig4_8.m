function fig4_8

% export: expand axes

% read in image and calculate svd
x=imread('p17.jpg');
A = double(x);

A(1:5,1:5)

[U,S,V] = svd(A);
ss=size(S)

k=[10 25 50 100];

rs=min(ss(1),ss(2))
for i=1:rs
    sigma(i)=S(i,i);
end

% compressed versions
figure(1)
for ik=1:length(k)

    % zero out singular values bigger than k
    Sa=zeros(ss(1),ss(2));
    for ir=1:k(ik)
        Sa(ir,ir)=sigma(ir);
    end
    Aa=U*Sa*V';

    clf
    % get(gcf)
    set(gcf,'Position', [146 606 626 739])

    colormap(gray)
    imagesc(Aa)

    axis image
    axis off
    err=sigma(k(ik)+1)/sigma(1);
    errz=round(err,3);
    say=['k = ',num2str(k(ik)),'          Rel Error = ',num2str(errz)];
    text(5,-40,say,'Color','Black','FontSize',25,'FontWeight','bold')
    pause
    % if ik==1
    %     exportgraphics(gcf,'/Users/mark/Desktop/10.eps')
    % elseif ik==2
    %     exportgraphics(gcf,'/Users/mark/Desktop/25.eps')
    % elseif ik==3
    %     exportgraphics(gcf,'/Users/mark/Desktop/50.eps')
    % elseif ik==4
    %     exportgraphics(gcf,'/Users/mark/Desktop/100.eps')
    % end
end












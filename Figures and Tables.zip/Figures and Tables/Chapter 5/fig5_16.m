function fig5_16

%%% pick the number of points
%n=6
n=12
an=7

% semi-circle
r=1;
nt=100;
th=linspace(0,pi,nt);
for i=1:nt
    x(i)=r*cos(th(i));
    y(i)=r*sin(th(i));
end

% points on circle
for ii=1:2:2*n
    xx(ii)=r*cos(ii*pi/(2*n));
    yy(ii)=r*sin(ii*pi/(2*n));
end
xx(1)

clf
% get(gcf)
set(gcf,'Position', [27 1057 501 288])

subaxis(1,1,1,1,'MT',0.01,'MB',0.173,'MR',-0.01,'ML',0.02,'P',0.04)
co = [0 0 1;
    0 0.5 0;
    1 0 0;
    0 0.75 0.75;
    0.75 0 0.75;
    0.75 0.75 0;
    0.25 0.25 0.25];
set(groot,'defaultAxesColorOrder',co)

% arc shader
xc(1)=0.02*r*cos((an+1)*pi/(2*n)); yc(1)=0.02*r*sin((an+1)*pi/(2*n));
na=6;
ang=linspace(an*pi/(2*n)+0.008,(an+2)*pi/(2*n)-0.008,na);
for i=1:na
    xc(i+1)=0.995*r*cos(ang(i));
    yc(i+1)=0.995*r*sin(ang(i));
end
xc(na+2)=xc(1); yc(na+2)=yc(1);
fill(xc,yc,'k','FaceAlpha',.3)
text(0.5, 0.94, '\pi/n','FontSize',20)

hold on
plot(x,y,'LineWidth',1.2)
for i=1:2:2*n
    plot( [0,xx(i)], [0,yy(i)],'b','LineWidth',1)
    plot( [xx(i)], [yy(i)],'.b','MarkerSize',30)
    plot( [xx(i),xx(i)], [0,yy(i)],'--r','LineWidth',1.2)
    plot( [xx(i)], [0],'.r','MarkerSize',30)
end

set(gca,'xtick',[-1.02 0 1.02])
set(gca,'ytick',[2])
set(gca,'XTickLabel',{'a';'(a+b)/2';'b'})

axis equal
grid on
axis([-1.02 1.02 -0.008 1.02])
xlabel('x-axis')
ylabel('y-axis')
set(gca,'FontSize',18,'FontWeight','bold')

%exportgraphics(gcf,'/Users/mark/Desktop/t12.eps')





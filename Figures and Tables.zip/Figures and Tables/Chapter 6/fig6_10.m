function fig6_10

% this requires the file splineA.m

%%%%% pick your example
%%% y=exp(3x)
a=0; b=1;
exact=(exp(3)-1)/3;
%%% y=sin(x)
% a=0; b=pi;
% exact=2;
%%% f=x^4;
% a=0; b=10;
% exact=10^5/5;

nd=6;  % number of data points
for ic=1:10
    %  generate data
    xd=sort(a+(b-a)*rand(1,nd));
    xd(1)=a; xd(nd)=b;
    for i=1:nd
        yd(i)=f(xd(i));
    end

    for i=1:nd-1
        h(i)=xd(i+1)-xd(i);
        sm(i)=xd(i)+0.5*h(i);
    end

    % trap
    I_T=h(1)*yd(1);
    for i=2:nd-1
        I_T=I_T+(h(i)+h(i-1))*yd(i);
    end
    I_T=0.5*(I_T+h(nd-1)*yd(nd));

    % natural
    sdN=splineA(xd,yd,sm);
    I_S=I_T/3;
    for i=1:nd-1
        I_S=I_S+2*h(i)*sdN(i)/3;
    end

    % not-a-knot
    sdK=spline(xd,yd,sm);
    I_SK=I_T/3;
    for i=1:nd-1
        I_SK=I_SK+2*h(i)*sdK(i)/3;
    end

    errT(ic)=abs((exact-I_T)/exact);
    errS(ic)=abs((exact-I_S)/exact);
    errSK(ic)=abs((exact-I_SK)/exact);

end

clf
% get(gcf)
set(gcf,'Position', [25 1115 658 230])
subaxis(1,1,1,1,'MT',0.01,'MB',0.18,'MR',-0.02,'ML',0.06,'P',0.04)
co = [0 0 1;
    0 0.5 0;
    1 0 0;
    0 0.75 0.75;
    0.75 0 0.75;
    0.75 0.75 0;
    0.25 0.25 0.25];
set(groot,'defaultAxesColorOrder',co)

semilogy(1:10,errT,'ob','MarkerSize',9,'lineWidth',2)
hold on
%semilogy(1:10,errS,'dk','MarkerSize',9,'lineWidth',2)
semilogy(1:10,errSK,'+r','MarkerSize',9,'lineWidth',2)
box on
grid on
axis([1 10 1e-4 1])
set(gca,'ytick',[1e-4 1e-2 1])
xlabel('Experiment')
ylabel('Error')

legend({' Trap',' Spline'},'Location','eastoutside','FontSize',16,'FontWeight','bold')
%legend({' Trap',' Natural',' Not'},'Location','eastoutside')

set(gca,'FontSize',16,'FontWeight','bold')
hold off

%exportgraphics(gca,'/Users/mark/Desktop/discrete.eps')

function y=f(x)
y=exp(3*x);
%y=sin(x);
% y=x^4;














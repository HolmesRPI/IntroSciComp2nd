function fig6_14

%%% also also inclues fig6_15

%%% pick case:  ic=1 => fig6_14   ic=2 => fig6_15
ic=1;

% evaluate integrand for plotting
a=0; b=4;
nx=200;
x=linspace(a-0.1,b+0.1,nx);
for ix=1:nx
    y(ix)=f(x(ix));
end

clf
% get(gcf)
set(gcf,'Position', [25 1115 658 230])
subaxis(1,1,1,1,'MT',0.01,'MB',0.18,'MR',-0.02,'ML',0.02,'P',0.04)
co = [0 0 1;
    0 0.5 0;
    1 0 0;
    0 0.75 0.75;
    0.75 0 0.75;
    0.75 0.75 0;
    0.25 0.25 0.25];
set(groot,'defaultAxesColorOrder',co)

plot(x,y,'r','LineWidth',2)
hold on
axis([x(1) x(nx) 0 3]);
xlabel('x-axis')
ylabel('y-axis')
set(gca,'FontSize',16,'FontWeight','bold')
if ic==1
    xx=0; plot([xx xx],[0 f(xx)],'b','LineWidth',1.6)
    xx=b/2; plot([xx xx],[0 f(xx)],'b','LineWidth',1.6)
    xx=b; plot([xx xx],[0 f(xx)],'b','LineWidth',1.6)
    xx=b/4; plot([xx xx],[0 f(xx)],'--b','LineWidth',1.6)
    xx=3*b/4; plot([xx xx],[0 f(xx)],'--b','LineWidth',1.6)
    %exportgraphics(gca,'/Users/mark/Desktop/aq0.eps')
else
    xx=0; plot([xx xx],[0 f(xx)],'b','LineWidth',1.6)
    xx=b/4; plot([xx xx],[0 f(xx)],'b','LineWidth',1.6)
    xx=b/2; plot([xx xx],[0 0.98*f(xx)],'b','LineWidth',4)
    xx=3*b/4; plot([xx xx],[0 f(xx)],'b','LineWidth',1.6)
    xx=b; plot([xx xx],[0 f(xx)],'b','LineWidth',1.6)
    xx=b/4; plot([xx xx],[0 f(xx)],'--b','LineWidth',1.6)
    xx=3*b/4; plot([xx xx],[0 f(xx)],'--b','LineWidth',1.6)
    xx=b/8; plot([xx xx],[0 f(xx)],'--b','LineWidth',1.6)
    xx=3*b/8; plot([xx xx],[0 f(xx)],'--b','LineWidth',1.6)
    xx=5*b/8; plot([xx xx],[0 f(xx)],'--b','LineWidth',1.6)
    xx=7*b/8; plot([xx xx],[0 f(xx)],'--b','LineWidth',1.6)
    %exportgraphics(gca,'/Users/mark/Desktop/aq2.eps')
end


function y=f(x)
% 1 + Lorentzian Function
g=0.5*2/pi;  x0=3; gg=g/2;
y=1+(gg/pi)/((x-x0)^2+gg^2);







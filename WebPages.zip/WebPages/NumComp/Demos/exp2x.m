function exp2x

% evaluate and plot (exp(2x)-1)/x for x close to zero

% use interval 10^a < x < 10^b
a=-18;  b=-8;
nx=1000;
powers=linspace(a,b,nx);

% evaluate function
for i=1:nx
    x(i)=10^powers(i);
    g(i)=f(x(i));
end

% basic plot commands
clf
% get(gcf)
set(gcf,'Position', [7 1092 676 253])
semilogx(x,g,'r','LineWidth',1.2)
xlabel('x-axis')
ylabel('y-axis')
grid on
box on

% make plot look nice
axis([10^a 10^b -0.5 4])
set(gca,'FontSize',16,'FontWeight','bold')
hold off


function y=f(x)
y=(exp(2*x)-1)/x;















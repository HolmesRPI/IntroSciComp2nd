function dataL

% example data set: global poly interpolation
% requires subaxis.m and parseArgs.m files (for plotting)

a=-1; b=1;
nx=12;
xd=linspace(a,b,nx);

% 5th degree poly
for iy=1:nx
    yd4(iy)=(xd(iy)+0.9)*(xd(iy)+0.1)^2*(xd(iy)-0.2)*(xd(iy)-0.8);
end

% jump function
for iy=1:nx
    yd1(iy)=(-1)^iy*0.02;
end
yd1(5)=1; yd1(6)=1; yd1(7)=1; yd1(8)=1;


% oscillatory function
for iy=1:nx
    yd2(iy)=(-1)^iy;
end

% circle function
for iy=1:nx
    yd3(iy)=sqrt(1-xd(iy)^2);
end

n=400;
xp=linspace(a,b,n);

clf
% get(gcf)
set(gcf,'Position', [3 978 666 367])

subaxis(2,2,1,1,'MT',0.003,'MB',0.1,'MR',0.01,'ML',0.06,'P',0.01)
% global poly
aa=inv(vander(xd))*yd4';
for ii=1:n
    yl4(ii)=aa(nx);
    for ip=2:nx
        yl4(ii)=yl4(ii)+aa(nx-ip+1)*xp(ii)^(ip-1);
    end
end
hold on
box on
plot(xd,yd4,'or','MarkerSize',7,'LineWidth',2)
axis([-1.1 1.1 -0.2 0.4])
grid on
ylabel('y-axis')
set(gca,'FontSize',14,'FontWeight','bold')

pause
plot(xp,yl4,'b','LineWidth',1.2)
pause


subaxis(2,2,2,1)
% global poly
aa=inv(vander(xd))*yd3';
for ii=1:n
    yl3(ii)=aa(nx);
    for ip=2:nx
        yl3(ii)=yl3(ii)+aa(nx-ip+1)*xp(ii)^(ip-1);
    end
end
hold on
box on
plot(xd,yd3,'or','MarkerSize',7,'LineWidth',2)
axis([-1.1 1.1 -0.1 1.1])
grid on
set(gca,'ytick',[0 0.5 1])
%xlabel('x-axis')
%ylabel('y-axis')
set(gca,'FontSize',14,'FontWeight','bold')

pause
plot(xp,yl3,'b','LineWidth',1.2)
pause

subaxis(2,2,1,2)
% global poly
aa=inv(vander(xd))*yd2';
for ii=1:n
    yl2(ii)=aa(nx);
    for ip=2:nx
        yl2(ii)=yl2(ii)+aa(nx-ip+1)*xp(ii)^(ip-1);
    end
end
hold on
box on
plot(xd,yd2,'or','MarkerSize',7,'LineWidth',2)
axis([-1.1 1.1 -3 3])
grid on
xlabel('x-axis')
ylabel('y-axis')
set(gca,'FontSize',14,'FontWeight','bold')

pause
plot(xp,yl2,'b','LineWidth',1.2)
pause

subaxis(2,2,2,2)
% global poly
aa=inv(vander(xd))*yd1';
for ii=1:n
    yl1(ii)=aa(nx);
    for ip=2:nx
        yl1(ii)=yl1(ii)+aa(nx-ip+1)*xp(ii)^(ip-1);
    end
end
hold on
box on
plot(xd,yd1,'or','MarkerSize',7,'LineWidth',2)
axis([-1.1 1.1 -0.5 1.5])
grid on
xlabel('x-axis')
%ylabel('y-axis')
set(gca,'FontSize',14,'FontWeight','bold')

pause
plot(xp,yl1,'b','LineWidth',1.2)












function newton0

%  Solve  f(x) = 0  using Newton's method
%  uses exact solution to find error

%  Input:
%	xa = starting point
%	tol = tolerance for stopping
%	f(x) and df(x) These are at end of file

xa=-2;
tol=10^(-8);

% exact solution
xe=1;

err=1;
it=0;
while err>tol
    xb=xa-f(xa)/df(xa);
    err=abs(xb-xa);
    xa=xb;
    it=it+1; iteration(it)=it; error(it)=abs(xe-xb);
    fprintf('\n %d  Computed Solution = %13.8e    Error = %5.1e',it,xb,error(it))
    pause
end
fprintf('\n\n')

% plot error curve
clf
% get(gcf)
set(gcf,'Position', [1 925 560 420])
semilogy(iteration,error,'--or','LineWidth',1.5,'MarkerSize',8)
xlabel('Iteration Step (n)')
ylabel('Error')
grid on
box on
set(gca,'FontSize',16,'FontWeight','bold')


function g=f(x)
%g=x*(x-2)*(x-4);
g=exp(1-x)-x;

function g=df(x)
%g=(x-2)*(x-4)+x*(x-4)+x*(x-2);
g=-exp(1-x)-1;








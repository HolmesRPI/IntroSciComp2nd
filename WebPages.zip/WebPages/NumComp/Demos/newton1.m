function newton1

%  Solve  f(x) = 0  using Newton's method
%  check on order of convergence (gamma)

%  Input:
%	xa = starting point
%	tol = tolerance for stopping
%	f(x) and df(x) These are at end of file

xa=-2;
tol=10^(-8);

% exact solution
xe=1;

err=3*tol;
it=0;
fprintf('\n                Error   Iterative Error')
while err>tol
    xb=xa-f(xa)/df(xa);
    err=abs(xb-xa);
    xa=xb;
    it=it+1;
    error(it)=abs(xe-xb);
    error1(it)=err;
    if it>1
        gamma=log(error(it))/log(error(it-1));
        gamma1=log(error1(it))/log(error1(it-1));
        fprintf('\n %d  gamma =    %5.1f    %5.1f',it,gamma,gamma1)
        pause
    end
end
fprintf('\n\n')


function g=f(x)
%g=x*(x-2)*(x-4);
g=exp(1-x)-x;

function g=df(x)
%g=(x-2)*(x-4)+x*(x-4)+x*(x-2);
g=-exp(1-x)-1;


























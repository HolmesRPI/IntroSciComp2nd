function surf3d

% plot surface and contours

global ifun

ifun=2

if ifun==1
    xa=-1; xb=1; ya=-1; yb=1;
else
    xa=-1; xb=1; ya=-1; yb=1;
end

figure(1)
clf
% get(gcf)
set(gcf,'Position', [4 431 560 420])
co = [0 0 1;
    0 0.5 0;
    1 0 0;
    0 0.75 0.75;
    0.75 0 0.75;
    0.75 0.75 0;
    0.25 0.25 0.25];
set(groot,'defaultAxesColorOrder',co)

n0=50;
x=linspace(xa,xb,n0);
y=linspace(ya,yb,n0);
[A1,A2]=meshgrid(x,y);
for i=1:n0
    for j=1:n0
        F(i,j)=f(x(i), y(j));
    end
end
contour(A1,A2,F,40,'b','LineWidth',1.2)
xlabel('x-axis')
ylabel('y-axis')
set(gca,'FontSize',16,'FontWeight','bold')

figure(2)
clf
% get(gcf)
set(gcf,'Position', [2 925 560 420])
co = [0 0 1;
    0 0.5 0;
    1 0 0;
    0 0.75 0.75;
    0.75 0 0.75;
    0.75 0.75 0;
    0.25 0.25 0.25];
set(groot,'defaultAxesColorOrder',co)
x=linspace(xa,xb,n0);
y=linspace(ya,yb,n0);
[A1,A2]=meshgrid(x,y);
for i=1:n0
    for j=1:n0
        F(i,j)=f(x(i), y(j));
    end
end
colormap(cool)
surfc(A1,A2,F)
view(-32, 16);
xlabel('x')
ylabel('y')
zlabel('F(x,y)')
set(gca,'FontSize',16,'FontWeight','bold')



function z=f(x,y)
global ifun

if ifun==1
    z=(x-y)^4+8*x*y-x+y+3;
else
    z=100*(x^2-y)^2+(x-1)^2;
end




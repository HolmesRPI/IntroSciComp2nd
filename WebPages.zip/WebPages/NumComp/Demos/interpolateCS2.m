function interpolateCS2

% error for piecewise linear interpolation of f(x) for a<x<b

a=0; b=1;

ii=0;
nd=2;
for iz=1:40
    nd=2*nd;
    if nd>1000
        nd=1000;
    end
    ii=ii+1;
    points(ii)=nd;
    
    % data points
    xd=linspace(a,b,nd);
    for iy=1:nd
        yd(iy)=f(xd(iy));
    end
    h=xd(2)-xd(1);
    
    % determine error
    n=5*nd;
    xp=linspace(a,b,n);
    ys = nspline(xd,yd,xp);
    %ysN = spline(xd,yd,xp);
    err(ii)=0;
    for i=1:n
        y=f(xp(i));
        er=abs(y-ys(i));
        %er=abs(y-ysN(i));
        if er>err(ii)
            err(ii)=er;
        end
    end
    if nd==1000
        break
    end
end

% plot error curve
clf
% get(gcf)
set(gcf,'Position', [25 1115 658 230])
co = [0 0 1;
    0 0.5 0;
    1 0 0;
    0 0.75 0.75;
    0.75 0 0.75;
    0.75 0.75 0;
    0.25 0.25 0.25];
set(groot,'defaultAxesColorOrder',co)


loglog(points,err,'--r','LineWidth',1.8)
hold on
box on
grid on
xlabel('Number of Data Points')
ylabel('Error')
%legend({' Exact',' PL Interpolation'},'Location','North','FontSize',16,'FontWeight','bold')
set(gca,'FontSize',16,'FontWeight','bold')

function g=f(x)
g=cos(2*pi*x);










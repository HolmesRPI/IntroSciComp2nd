function newton2

%  Solve  Colebrook  using Newton's method

%  Input:
%	xa = starting point
%	tol = tolerance for stopping (iterative error)
%	f(x) and df(x) are at end of file

%  Output:
%	xb = computed solution

xa=2;
tol=10^(-6);

err=3*tol;
it=0;
while err>tol
    xb=xa-f(xa)/df(xa);
    err=abs(xb-xa);
    it=it+1;
    fprintf('\n %d  Computed Solution = %13.8e     Error = %5.1e \n',it,xb,err)
    xa=xb;
    if it>20
        error('Newton is not converging')
    end
end
fprintf('\n')

function g=f(x)
a=1e-2; b=1e-4;
g=x+2*log10(a+b*x);

function g=df(x)
a=1e-2; b=1e-4;
g=1+2*b/((a+b*x)*log(10));







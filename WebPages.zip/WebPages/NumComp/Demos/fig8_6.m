function fig8_6

% plot error functions E_{infty} and E_2

tic

%  generate data
n=50;
xd=rand(1,n);
a1=3; a2=1;
for i=1:n
    yd(i)=a1*xd(i)+a2+(rand(1)-0.5)*(a1*xd(i)+a2);
end

figure(1)
clf
% get(gcf)
set(gcf,'Position', [5 925 560 420]);
co = [0 0 1;
      0 0.5 0;
      1 0 0;
      0 0.75 0.75;
      0.75 0 0.75;
      0.75 0.75 0;
      0.25 0.25 0.25];
set(groot,'defaultAxesColorOrder',co)

% E_infty surface
v2a=-2; v2b=8; v1a=-4; v1b=6;
n0=1000;
v2=linspace(v2a,v2b,n0);
v1=linspace(v1a,v1b,n0);
[A1,A2]=meshgrid(v1,v2);
for i=1:n0
	for j=1:n0
		for l=1:n
			EE(l)=abs( v2(i)*xd(l)+v1(j)-yd(l) );
        end
		E(i,j)=max(EE);
    end
end
surfc(A1,A2,E)
shading interp
colormap copper
view(-42, 16)
xlabel('v_1')
ylabel('v_2')
zlabel('E_\infty')
set(gca,'FontSize',20,'FontWeight','bold')

% E_infty contours
figure(2)
clf
% get(gcf)
set(gcf,'Position', [7 429 560 420])
co = [0 0 1;
      0 0.5 0;
      1 0 0;
      0 0.75 0.75;
      0.75 0 0.75;
      0.75 0.75 0;
      0.25 0.25 0.25];
set(groot,'defaultAxesColorOrder',co)

contour(A1,A2,E,15,'b','LineWidth',1.6)
xlabel('v_1-axis')
ylabel('v_2-axis')
set(gca,'ytick',[-4 -2 0 2 4 6 8])
set(gca,'FontSize',20,'FontWeight','bold')

% E_2 surface
figure(3)
clf
% get(gcf)
set(gcf,'Position', [569 925 560 420]);
co = [0 0 1;
      0 0.5 0;
      1 0 0;
      0 0.75 0.75;
      0.75 0 0.75;
      0.75 0.75 0;
      0.25 0.25 0.25];
set(groot,'defaultAxesColorOrder',co)

v2a=-2; v2b=8; v1a=-4; v1b=6;
n0=400;
v2=linspace(v2a,v2b,n0);
v1=linspace(v1a,v1b,n0);
[A1,A2]=meshgrid(v1,v2);
for i=1:n0
	for j=1:n0
        EE2(i,j)=0;
		for l=1:n
			EE2(i,j) = EE2(i,j)+ ( v2(i)*xd(l)+v1(j)-yd(l) )^2;
        end
    end
end
surfc(A1,A2,EE2)
shading interp
colormap copper
view(-42, 16)
xlabel('v_1')
ylabel('v_2')
zlabel('E_2')
set(gca,'FontSize',20,'FontWeight','bold')

% E_2 contours
figure(4)
clf
% get(gcf)
set(gcf,'Position', [568 429 560 420])
co = [0 0 1;
      0 0.5 0;
      1 0 0;
      0 0.75 0.75;
      0.75 0 0.75;
      0.75 0.75 0;
      0.25 0.25 0.25];
set(groot,'defaultAxesColorOrder',co)

contour(A1,A2,EE2,[30 50 100 200 300 500 700 900 1200 1500 1800 2100],'b','LineWidth',1.6)
xlabel('v_1-axis')
ylabel('v_2-axis')
set(gca,'ytick',[-4 -2 0 2 4 6 8])
set(gca,'FontSize',20,'FontWeight','bold')


toc
























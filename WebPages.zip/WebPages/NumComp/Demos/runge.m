function runge

% lagrange interpolation for runge function
% uses nx data points (try nx = 5, 10, 20, 40, 80)

nx=80

clf
% get(gcf)
set(gcf,'Position', [1 925 560 420])

a=-1; b=1;
n=1000;
x=linspace(a,b,n);

% compute lagrange interpolation function
xd=linspace(a,b,nx);
for ix=1:nx
    yd(ix)=1/(1+25*xd(ix)^2);
end
for ii=1:n
    p(ii)=0;
    for k=1:nx
        p(ii)=p(ii)+yd(k)*ell(k,x(ii),xd);
    end
end

max_value=max(p)

% compute runge function
for ie=1:n
    ye(ie)=1/(1+25*x(ie)^2);
end

% plot results
hold on
box on
plot(x,ye,'r','LineWidth',1.5)
plot(x,p,'--b','LineWidth',1.5)

if nx>20
    axis([-1 1 -20 20])
end

say=['Number of Data Points = ',num2str(nx)];
title(say,'FontSize',20,'FontWeight','bold')
grid on
xlabel('x-axis')
ylabel('y-axis')
legend({' Exact',' Lagrange'},'Location','South','FontSize',14,'FontWeight','bold')
set(gca,'FontSize',14,'FontWeight','bold')
hold off

% lagrange basis function
function p=ell(i,x,xd)
[n1 n2]=size(xd);
p=1;
for j=1:n2
    if j ~= i
        p=p*(x-xd(j))/(xd(i)-xd(j));
    end
end







function r

% compare yy = (x -1)^8 with y = x^8 - 8*x^7 + ...
% for 1-d < x < 1+d

d=0.02;
nx=500;

% evaluate functions
x=linspace(1-d,1+d,nx);
for i=1:nx
    y(i)=x(i)^8-8*x(i)^7+28*x(i)^6-56*x(i)^5+70*x(i)^4-56*x(i)^3+28*x(i)^2-8*x(i)+1;
    yy(i)=(x(i)-1)^8;
end

% basic plot commands
clf
% get(gcf)
set(gcf,'Position', [1 925 560 420])
plot(x,yy, '--b','LineWidth',1.5)
hold on
xlabel('x-axis')
ylabel('y-axis')
grid on
legend({' (x - 1)^8'},'Location','North','FontSize',16)

% make plot look nice
axis([1-d 1+d -3e-14 4e-14])
set(gca,'XTick',[1-d 1 1+d])
set(gca,'FontSize',16,'FontWeight','bold')

% now plot second curve
pause
plot(x,y,'-r','LineWidth',1)
legend({' (x - 1)^8',' x^8 - 8x^7 + ...'},'Location','North','FontSize',16)


























function s

% compute partial sum of harmonic series (n terms)

format ShortE

for ic=1:8
    n=10^ic
    
    %%%% from small to large
    s=0;
    for j=1:n
        s=s+1/(n-j+1);
    end
    
    %%%% from large to small
    S=0;
    for jj=1:n
        S=S+1/jj;
    end
    
    difference=S-s
    pause
end


function interpolateCS

% cubic spline interpolation of f(x) for a<x<b
% plots both natural and not-a-knot

a=0; b=1;

% data points
nd=13
xd=linspace(a,b,nd);
for iy=1:nd
	yd(iy)=f(xd(iy));
end

% exact values
n=400;
xp=linspace(a,b,n);
for i=1:n
	y(i)=f(xp(i));
end

ys = nspline(xd,yd,xp);
yf = fspline(xd,yd,[0 0],xp);
%ysN = spline(xd,yd,xp);

% plot curves
clf
% get(gcf)
set(gcf,'Position', [25 1115 658 230])
co = [0 0 1;
      0 0.5 0;
      1 0 0;
      0 0.75 0.75;
      0.75 0 0.75;
      0.75 0.75 0;
      0.25 0.25 0.25];
set(groot,'defaultAxesColorOrder',co)

hold on
box on
plot(xp,y,'k','LineWidth',1.8)
plot(xp,ys,'-r','LineWidth',1.6)
plot(xp,yf,'--b','MarkerSize',7,'LineWidth',2)
grid on
xlabel('x-axis')
ylabel('y-axis')
legend({' Exact',' Natural Spline',' Clamped Spline'},'Location','North','FontSize',16,'FontWeight','bold')
set(gca,'FontSize',16,'FontWeight','bold')


function g=f(x)
g=cos(2*pi*x);










function forwardcentered

%  comparison of forward and centered difference approximations for f'(x)
%  this requires the subaxis and parseArgs files

x0=1;
exact=0.5

for k=1:20
    h(k)=1/10^(k-1);
    F(k)=(f(x0+h(k)) - f(x0))/h(k);
    C(k)=(f(x0+h(k)) - f(x0-h(k)) )/(2*h(k));
    errF(k)=abs(exact-F(k));
    errC(k)=abs(exact-C(k));
end

clf
% get(gcf)
set(gcf,'Position', [28 998 584 347])
co = [0 0 1;
    0 0.5 0;
    1 0 0;
    0 0.75 0.75;
    0.75 0 0.75;
    0.75 0.75 0;
    0.25 0.25 0.25];
set(groot,'defaultAxesColorOrder',co)

for i=1:20
    subaxis(2,1,1,1,'MT',0.0001,'MB',0.08,'MR',0.001,'ML',0.05,'P',0.05)
    semilogx(h(1:i),F(1:i),'bo-','MarkerSize',7,'LineWidth',1.2)
    hold on
    semilogx(h(1:i),C(1:i),'r*-','MarkerSize',7,'LineWidth',1.2)
    axis([1e-20 1 0 0.75])
    set(gca,'ytick',[0 0.25 0.5 0.75])
    legend({' Forward',' Centered'},'Location','SouthEast')
    grid on
    ylabel('Derivative')
    set(gca,'FontSize',14,'FontWeight','bold')
    hold off
    
    subaxis(2,1,1,2)
    loglog(h(1:i),errF(1:i),'bo-','MarkerSize',7,'LineWidth',1.2)
    hold on
    loglog(h(1:i),errC(1:i),'r*-','MarkerSize',7,'LineWidth',1.2)
    legend({' Forward',' Centered'},'Location','SouthWest')    
    grid on
    xlabel('Stepsize (k)')
    axis([1e-20 1 1e-12 1])
    ylabel('Error')
    set(gca,'ytick',[1e-12 1e-8 1e-4 1])
    set(gca,'FontSize',14,'FontWeight','bold')
    hold off
    pause
end


function y=f(x)
y=sqrt(x);













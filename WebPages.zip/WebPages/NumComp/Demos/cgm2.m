function cgm2

%  compare CGM with A\b for solving Ax=b and

% Example 1: matrix A from solving Laplace's equation
fprintf('\n Example 1: matrix A from solving Laplaces equation \n')
N=70;
M=N;
n=N*M

pause

lambda2=1;
D=2*(1+lambda2)*eye(n,n);
SD1=diag(-lambda2*ones(n-1,1),-1);
SDM=diag(-ones(n-M,1),-M);
A=D+SD1+SD1'+SDM+SDM';
sol=2*(1-0.5*rand(n,1));
b=A*sol;

tic
x=cgm(A,b);
cgm_time=toc

tic
xm=A\b;
LU_time=toc

cgm_error=norm(x-sol,inf)/norm(sol,inf)
LU_error=norm(xm-sol,inf)/norm(sol,inf)

pause


% Example 2: random sparse SPD matrix
fprintf('\n Example 2: random sparse SPD matrix \n')
n=5000

pause

A1=rand(n,n);             
A=A1'+A1+diag(2*n*ones(n,1));
sol=2*(1-0.5*rand(n,1));
b=A*sol;

tic
x=cgm(A,b);
cgm_time=toc

tic
xm=A\b;
LU_time=toc

cgm_error=norm(x-sol,inf)/norm(sol,inf)
LU_error=norm(xm-sol,inf)/norm(sol,inf)











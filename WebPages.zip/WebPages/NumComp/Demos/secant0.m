function secant0

%  Solves  f(x) = 0  using the secant method

%  Input:
%	xa = first starting point
%	xb = second starting point
%	tol = tolerance for stopping
%	f(x) This is at end of code

xa=-2;
xb=-1.5;
tol=10^(-8);

% exact solution
xe=0;

fa=f(xa);
fb=f(xb);
err=3*tol;
it=0;
while err>tol
    xc=xb-fb*(xb-xa)/(fb-fa);
    err=abs(xc-xb);
    xa=xb;  fa=fb;
    xb=xc;  fb=f(xb);
    it=it+1; iteration(it)=it; error(it)=abs(xe-xc);
    fprintf('\n %d  Computed Solution = %13.8e    Error = %5.2e',it,xb,error(it))
    %pause
end
fprintf('\n\n')


function g=f(x)
%g=x-exp(-6*x);
g=x*(x-2)*(x-4);









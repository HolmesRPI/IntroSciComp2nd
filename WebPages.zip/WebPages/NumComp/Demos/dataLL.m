function dataLL

% global poly interpolation using direct approach
% example used is the 5th degree poly from data set
% demos problems arising from vandermonde matrix
% try nx = 5, 10, 40, 80

a=-1; b=1;
nx=5
xd=linspace(a,b,nx);

% 5th degree poly
for iy=1:nx
    yd4(iy)=(xd(iy)+0.9)*(xd(iy)+0.1)^2*(xd(iy)-0.2)*(xd(iy)-0.8);
end

n=400;
xp=linspace(a,b,n);
% global poly
aa=inv(vander(xd))*yd4';
for ii=1:n
    yl4(ii)=aa(nx);
    for ip=2:nx
        yl4(ii)=yl4(ii)+aa(nx-ip+1)*xp(ii)^(ip-1);
    end
end

clf
% get(gcf)
set(gcf,'Position', [4 1052 651 293])
hold on
box on
plot(xd,yd4,'or','MarkerSize',7,'LineWidth',2)
plot(xp,yl4,'b','LineWidth',1.5)
axis([-1.1 1.1 -0.2 0.4])
grid on
xlabel('x-axis')
ylabel('y-axis')
set(gca,'FontSize',14,'FontWeight','bold')






function newton

%  Solve  f(x) = 0  using Newton's method

%  Input:
%	xa = starting point
%	tol = tolerance for stopping (iterative error)
%	f(x) and df(x) are at end of file

%  Output:
%	xb = computed solution

xa=0;
tol=10^(-6);

err=3*tol;
it=0;
while err>tol
    xb=xa-f(xa)/df(xa);
    err=abs(xb-xa);
    it=it+1;
    fprintf('\n %d  Computed Solution = %13.8e     Error = %5.1e \n',it,xb,err)
    xa=xb;
    if it>20
        error('Newton is not converging')
    end
end
fprintf('\n')

function g=f(x)
%g=x-exp(-6*x);
%g=x*(x-2)*(x-4);
g=sin(x)-1+x^2;

function g=df(x)
%g=1+6*exp(-6*x);
%g=(x-2)*(x-4)+x*(x-4)+x*(x-2);
g=cos(x)+2*x;







function fig9_12

%%%%% find area error as function of theta:  using 1-norm and/or 2-norm

% generate data
m=6000;
t=linspace(0,10,m);
w1=pi;
w2=1.7*pi;
x=zeros(m,2);
% mixing coefficients
M11=2; M12=1;
M21=3; M22=-2;
for it=1:m
    s1(it) = sin(w1*t(it));  
    s2(it) = sin(w2*t(it)-5);
    x(it,1)=  M11*s1(it) + M12*s2(it);
    x(it,2) = M21*s1(it) + M22*s2(it);
end

xM=sum(x)/m;
for it=1:m
    X(it,:)=x(it,:)-xM;
end

XX=zeros(2,2);
for it=1:m
    %XX=XX+X(it,:)'*X(it,:);
    XX=XX+[ [X(it,1)*X(it,1) X(it,1)*X(it,2)];[X(it,1)*X(it,2) X(it,2)*X(it,2) ]];
end
XX=XX/m;

[M1,D1]=eig(XX);

if D1(1,1) >= D1(2,2)
        d1=D1(1,1); d2=D1(2,2);
        Q1=M1(:,1)/norm(M1(:,1),2);
        Q2=M1(:,2)/norm(M1(:,2),2);
    else
        d2=D1(1,1); d1=D1(2,2);
        Q2=M1(:,1)/norm(M1(:,1),2);
        Q1=M1(:,2)/norm(M1(:,2),2);
    end
    
Q=[Q1 Q2];

D5=zeros(2,2); D5(1,1)=1/sqrt(d1); D5(2,2)=1/sqrt(d2);

y=zeros(m,2);
for it=1:m
    y(it,:)=D5*Q'*X(it,:)';
     y(it,:)=D5*Q'*[ X(it,1);  X(it,2)] ;
end

ntheta=2000;
theta=linspace(0,2*pi,ntheta);
for ia=1:ntheta
    V=[[ cos(theta(ia)) -sin(theta(ia))];[ sin(theta(ia)) cos(theta(ia))]];
    for it=1:m
        s(it,1)=V(1,1)*y(it,1)+V(1,2)*y(it,2);
        s(it,2)=V(2,1)*y(it,1)+V(2,2)*y(it,2);
    end

%%% 1-norm
    err1(ia)=trap(t,abs(s(:,1)-s1'))+trap(t,abs(s(:,2)-s2'));
    err2(ia)=trap(t,abs(s(:,1)-s2'))+trap(t,abs(s(:,2)-s1'));
    
%%% 2-norm
%     err1(ia)=trap(t,(s(:,1)-s1').^2)+trap(t,(s(:,2)-s2').^2);
%     err2(ia)=trap(t,(s(:,1)-s2').^2)+trap(t,(s(:,2)-s1').^2);
    
end

for ia=2:ntheta-1
    if (err2(ia)<err2(ia-1)) & (err2(ia)<err2(ia+1))
        IMin=ia;
    end
        if (err2(ia)>err2(ia-1)) & (err2(ia)>err2(ia+1))
        IMax=ia;
    end
end
    
        
min_error_angle=theta(IMin)/pi

max_error_angle=theta(IMax)/pi

% can't distinguish between s1 and s2 data, so need two plots
% to determine which is which
figure(1)
clf
% get(gcf)
set(gcf,'Position', [25 1115 658 230])

co = [0 0 1;
      0 0.5 0;
      1 0 0;
      0 0.75 0.75;
      0.75 0 0.75;
      0.75 0.75 0;
      0.25 0.25 0.25];
set(groot,'defaultAxesColorOrder',co)

%plot(theta,err1,'b','LineWidth',1.4)
hold on
plot(theta,err2,'r','LineWidth',1.6)
axis([0 2*pi 5 35])
set(gca,'xtick',[0 pi/2 pi 3*pi/2 2*pi])
set(gca,'XTickLabel',{'0';'\pi/2';'\pi';'3\pi/2';'2\pi'})
xlabel('Theta')
ylabel('Area')
grid on
box on
set(gca,'FontSize',16,'FontWeight','bold')


figure(2)
clf
% get(gcf)
set(gcf,'Position', [25 810 658 230])
co = [0 0 1;
      0 0.5 0;
      1 0 0;
      0 0.75 0.75;
      0.75 0 0.75;
      0.75 0.75 0;
      0.25 0.25 0.25];
set(groot,'defaultAxesColorOrder',co)

plot(theta,err1,'b','LineWidth',1.4)
hold on
%plot(theta,err2,'r','LineWidth',1.4)
%axis([0 2*pi 0 10])
set(gca,'xtick',[0 pi/2 pi 3*pi/2 2*pi])
set(gca,'XTickLabel',{'0';'\pi/2';'\pi';'3\pi/2';'2\pi'})
xlabel('Theta')
ylabel('Area')
grid on
box on
set(gca,'FontSize',16,'FontWeight','bold')


function g=trap(t,f)
n=length(t);
h=t(2)-t(1);
sum=0.5*f(1);
for j=2:n-1
    sum=sum+f(j);
end;
g=h*(sum+0.5*f(n));
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    






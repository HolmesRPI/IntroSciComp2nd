function split

%  generate testing (A) and training (B) sets
%  uses 3/4 to 1/4 split

AA=importdata('crime_data_2009.txt');
[nA mA]=size(AA);

% randomize rows
rows=randperm(nA);

% split data set
n=round(3*nA/4)
A=AA(rows(1:n),:);
B=AA(rows(n+1:nA),:);

save('Adata.txt','A','-ascii');
save('Bdata.txt','B','-ascii');



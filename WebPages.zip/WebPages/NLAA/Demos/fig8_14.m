function fig8_13

% plot quadratic form

%  matrix elements
A(1,1)=2; A(1,2)=1;
A(2,1)=1; A(2,2)=2;
alp=1;  bet=-1;

a=A(1,1)^2+A(2,1)^2; b=2*(A(1,1)*A(1,2)+A(2,1)*A(2,2));
c=A(1,2)^2+A(2,2)^2; d=-2*(A(1,1)*alp+A(2,1)*bet);
e=-2*(A(1,2)*alp+A(2,2)*bet); f=alp^2+bet^2;

figure(2)
clf
% get(gcf)
set(gcf,'Position', [2 925 560 420])
co = [0 0 1;
      0 0.5 0;
      1 0 0;
      0 0.75 0.75;
      0.75 0 0.75;
      0.75 0.75 0;
      0.25 0.25 0.25];
set(groot,'defaultAxesColorOrder',co)

theta=0.5*abs(atan(b/(a-c)));
theta/pi
if b>=0 & a>=c
    ct=cos(theta);
    st=sin(theta);
elseif b>=0 & a < c
    ct=-cos(theta);
    st=sin(theta);
elseif b < 0 & a>=c
    ct=cos(theta);
    st=-sin(theta);
elseif b < 0 & a < c
    ct=-cos(theta);
    st=-sin(theta);
end
      
%%% transform to E=A*xp^2+B*yp^2+fb
%%% where x=x0+xp*ct-yp*ct, y=y0+xp*ct+yp*st
x0=(2*c*d-b*e)/(b^2-4*a*c);
y0=(2*a*e-b*d)/(b^2-4*a*c);
A=a*ct^2+b*ct*st+c*st^2;
B=a*st^2-b*ct*st+c*ct^2;
fb=f+a*x0^2+b*x0*y0+c*y0^2+d*x0+e*y0;
n0=30;
rM=1/3;
r=linspace(0.0001,rM,n0);
ang=linspace(0,2*pi,n0);
for ir=1:n0
    for it=1:n0
        xp=sqrt(B)*r(ir)*cos(ang(it)); 
        yp=sqrt(A)*r(ir)*sin(ang(it));
        A1(ir,it)=x0+xp*ct-yp*ct;
        A2(ir,it)=y0+xp*ct+yp*st;
%        E(ir,it)=a*A1(ir,it)^2+b*A1(ir,it)*A2(ir,it)+c*A2(ir,it)^2+d*A1(ir,it)+e*A2(ir,it)+f;
        E(ir,it)=A*xp^2+B*yp^2+fb;
    end
end

Emax=fb+A*B*rM^2
Emin=fb

surfc(A1,A2,E)
view(20,5)

xlabel('x')
ylabel('y')
zlabel('F')
set(gca,'FontSize',16,'FontWeight','bold')


figure(1)
clf
% get(gcf)
set(gcf,'Position', [2 431 560 420])
co = [0 0 1;
      0 0.5 0;
      1 0 0;
      0 0.75 0.75;
      0.75 0 0.75;
      0.75 0.75 0;
      0.25 0.25 0.25];
set(groot,'defaultAxesColorOrder',co)

contour(A1,A2,E,'LineWidth',1.3)
grid on
xlabel('x-axis','FontSize',16,'FontWeight','bold')
ylabel('y-axis','FontSize',16,'FontWeight','bold')
set(gca,'ytick',[1 2 3 4 5])
set(gca,'xtick',[-1 0 1 2 3])
set(gca,'FontSize',16,'FontWeight','bold')
















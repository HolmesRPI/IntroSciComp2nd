function wineF

%  wine data matrix (by column)
%  fixed_acidity  volatile_acidity  citric_acid  residual_sugar
%  chlorides  free_sulfur_dioxide  total_sulfur_dioxide  density
%  pH  sulphate  alcohol  quality

% code fits centered data
% data matrix X(n,m)
% n = number of data points;  m =  number of variables
% x_m = v_1x_1 + v_2x_2 + ... + v_(m-1)x_(m-1)
% where x_j = X_j -  mean(X_j)


% training set (2/3 of original)
A=importdata('AdataW.txt');
[n m]=size(A);
means=mean(A);

% testing set
B=importdata('BdataW.txt');
[nn mm]=size(B);

% center data
for j=1:m
    AC(:,j)=A(:,j)-means(j)*ones(n,1);
    BC(:,j)=B(:,j)-means(j)*ones(nn,1);
end

% least squares: normal equations
tic
AA=AC(:,1:m-1)'*AC(:,1:m-1);
Ay=AC(:,1:m-1)'*AC(:,m);
v_NE=AA\Ay
NE_time=toc

pause

% least squares: QR
tic
[Q,R]=qr(AC(:,1:m-1));
Rm=R(1:m-1,1:m-1);
Qb=Q'*AC(:,m);
v_QR=Rm\Qb(1:m-1)
QR_time=toc

diff_in_vs=norm(v_NE-v_QR,inf)
pause

% compare with testing data
actual=BC(:,m);
pred_NE=BC(:,1:m-1)*v_NE;
pred_QR=BC(:,1:m-1)*v_QR;

% plot comparisons
clf
% get(gcf)
set(gcf,'Position', [1 995 588 350])
co = [0 0 1;
    0 0.5 0;
    1 0 0;
    0 0.75 0.75;
    0.75 0 0.75;
    0.75 0.75 0;
    0.25 0.25 0.25];
set(groot,'defaultAxesColorOrder',co)
plot(actual,pred_NE,'ob','MarkerSize',9,'LineWidth',2)
hold on
plot(actual,pred_QR,'*r','MarkerSize',9,'LineWidth',2)
legend(' Normal Eq',' QR','Location','NorthWest','AutoUpDate','off')
plot([-3 3],[-3 3],'--k','LineWidth',1.6)
xlabel('Actual')
ylabel('Predicted')
grid on
box on
set(gca,'FontSize',18,'FontWeight','bold')

pause

% mean absolute deviation
MAD_NE=norm(pred_NE-actual,1)/nn
MAD_QR=norm(pred_QR-actual,1)/nn

% mean squared prediction error
MSPE_NE=norm(pred_NE-actual,2)/nn
MSPE_QR=norm(pred_QR-actual,2)/nn


















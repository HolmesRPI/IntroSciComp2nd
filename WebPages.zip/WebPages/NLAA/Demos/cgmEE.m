function cgmEE

%  check CGM for solving Ax=b and
%  for poor converging matrix

% special 
n=100
[Q,R]=qr(randn(n,n)); D=diag(logspace(0,6,n));
A=Q'*D*Q;

cond(A,inf)

% specify solution (xe)
xe=ones(n,1);
b=A*xe;

fprintf('\n n = %i \n\n',n)

% use CGM to solve matrix equation
v=cgm(A,b,xe);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% CGM 
function x=cgm(A,b,sol)

% set CGM parameters
tol=1000*eps;

n=length(b);
x=zeros(n,1);
tic
% start iteration
r=b-A*x;
d=r;
rr=r'*r;
err=10*tol;
counter=0;
while err>tol && counter<1e3
    counter=counter+1;
    q=A*d;
    alpha=rr/(d'*q);
    x=x+alpha*d;
    r=r-alpha*q;
    rr0=rr;
    rr=r'*r; 
    beta=rr/rr0;
    d=r+beta*d;
    iter(counter)=counter;
	error2(counter)=norm(alpha*d,inf);
	error3(counter)=norm(r,inf);
	error(counter)=norm(x-sol,inf); 
    err=error2(counter);
end
cgm_time=toc;

fprintf('\n  Number of CGM Iterations = %i     Error =  %e    Time = %e \n\n',counter,error(counter),cgm_time)

clf
% get(gcf)
set(gcf,'Position', [25 1115 658 230])
co = [0 0 1;
      0 0.5 0;
      1 0 0;
      0 0.75 0.75;
      0.75 0 0.75;
      0.75 0.75 0;
      0.25 0.25 0.25];
set(groot,'defaultAxesColorOrder',co)

loglog(iter,error,'-.k','LineWidth',1.6)
hold on
loglog(iter,error2,'-r','LineWidth',1.6)
%loglog(iter,error3,'--b','LineWidth',1.6)

grid on
set(gca,'MinorGridLineStyle','none')
axis([ 1 1000 1e-12 10])
set(gca,'YTick',[1e-12 1e-8 1e-4 1 ])
ylabel('Error')
xlabel('Iteration Steps')
%legend(' Error',' Iteration Error',' Residual','Location','NorthEast')
legend(' Error',' Iteration Error','Location','SouthWest');
set(gca,'FontSize',16,'FontWeight','bold')
set(findobj(gcf,'tag','legend'),'FontSize',16,'FontWeight','bold')
hold off



















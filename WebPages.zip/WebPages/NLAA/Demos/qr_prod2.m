function qr_prod2

for ins=1:5
    if ins==1
        n=10;
    elseif ins==2
        n=40;
    elseif ins==3
        n=400;
    elseif ins==4
        n=1000;
    elseif ins==5
        n=4000;
    elseif ins==6
        n=2000;
    end
    
    A=rand(n,n);
    [QQ,RR]=qr(A);
    
    % random R
    Rp=rand(n,n);
    for j=1:n-1
        for i=j+1:n
            Rp(i,j)=0;
        end
    end
    
    % ill-condtioned matrix
    Rp=Rp+1.5*eye(n);
    if ins==1 fprintf('\n Ill Conditioned Matrix \n\n'); end
    
    % well-conditioned matrix
%         Rp=Rp+n*eye(n);
%         if ins==1 fprintf('\n Well Conditioned Matrix \n\n'); end
    
    Ap=QQ*Rp;
    con=cond(Ap,inf);
    
    [Q,R]=qr(Ap);
    
    % given QR, find equivalent with positive diagonals in R
    itest=0;
    for i=1:n
        if R(i,i)<0
            R(i,i)=-R(i,i);
            Q(:,i)=-Q(:,i);
            itest=itest+1;
            if i<n
                R(i,i+1:n)=-R(i,i+1:n);
            end
        end
    end
    
    e1=norm(QQ*Rp-Q*R,inf)/norm(A,inf);
    e2=norm(QQ-Q,inf)/norm(QQ,inf);
    e3=norm(Rp-R,inf)/norm(Rp,inf);
    
    fprintf('n = %i  E_1 = %5.1e  E_2 = %5.1e  E_3 = %5.1e  kappa = %5.1e \n',n,e1,e2,e3,con)
    pause
    
end
fprintf('\n')


















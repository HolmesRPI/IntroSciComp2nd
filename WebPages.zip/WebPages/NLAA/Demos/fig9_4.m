function fig9_4

%  finds best line fit
%  pick column corresponding to independent variable:  IX
%  then plots test vs training data for other variables

% pick indendepent variable
I=2

% labels (for plotting)
lab{1}='Population'; lab{2}='Murder';
lab{3}='Rape'; lab{4}='Robbery';
lab{5}='Assault'; lab{6}='Burglary';
lab{7}='Larceny'; lab{8}='Car Theft';

% load training (A) and testing (B) data sets
A=importdata('AdataC.txt');
[m n]=size(A);
B=importdata('BdataC.txt');

% normalization of A
means=mean(A);
D=zeros(m,n);
for j=1:n
    D(:,j)=A(:,j)-means(j)*ones(m,1);
end
DD=zeros(m,n);
for j=1:n
    DM(j)=max(abs(D(:,j)));
    %DM(j)=norm(D(:,j),2)/sqrt(m);
    DD(:,j)=D(:,j)/DM(j);
end

% SVD
[U,S,V] = svd(DD);
ss=size(S);
for i=1:ss(2)
    id(i)=i;
    sigmas(i)=S(i,i);
end
sigmas

%  normalize testing data (using same normalization used for A)
[M N]=size(B);
DB=zeros(M,N);
for j=1:n
    DB(:,j)=B(:,j)-means(j)*ones(M,1);
end
DDB=zeros(M,N);
for j=1:n
    DDB(:,j)=DB(:,j)/DM(j);
end


% plot training vs testing
for ic=1:n
    if ic ~= I
        
        clf
        % get(gcf)
        set(gcf,'Position', [4 918 563 427]);
        co = [0 0 1;
            0 0.5 0;
            1 0 0;
            0 0.75 0.75;
            0.75 0 0.75;
            0.75 0.75 0;
            0.25 0.25 0.25];
        set(groot,'defaultAxesColorOrder',co)
        
        % calculate and then plot linear fit line
        slope=V(ic,1)/V(I,1);
        xL=-max(DD(:,I));
        yL=slope*xL;
        xR=max(DD(:,I));
        yR=slope*xR;
        plot([xL xR],[yL yR],'r','LineWidth',1.6)
        hold on
        
        % plot testing data
        plot(DDB(:,I),DDB(:,ic),'ob','MarkerSize',8,'LineWidth',2)
        
        LX=min(DDB(:,I)); RX=max(DDB(:,I)); LY=min(DDB(:,ic)); RY=max(DDB(:,ic));
        axis([LX RX LY RY])
        axis square
        
        xlabel(lab{I})
        ylabel(lab{ic})
        grid on
        box on
        set(gca,'FontSize',18,'FontWeight','bold')
        pause
    end
end























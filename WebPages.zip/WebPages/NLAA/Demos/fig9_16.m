function fig9_16

%  image separation using columns (but expresed using matrices)

tic

% read in original images
x1=imread('fig1.jpg');
I1 = double(x1);
size1=size(I1)

x2=imread('fig3.jpg');
I2 = double(x2);
size2=size(I2)

% display original images

figure(1)
colormap(gray)
axis image
imshow(I1,[])
%imagesc(I1)
axis off

figure(2)
colormap(gray)
axis image
imshow(I2,[])
%imagesc(I2)
axis off

pause

MM=size1(1); NN=size1(2);
n=MM*NN

% mixing matrix M_{11}+M_{12}=1 etc
M11=0.8; M12=0.2;
M21=0.7; M22=0.3;
M=[[M11 M12];[M21 M22]]

%%% calculate and show the mixed images
III1=M11*I1+M12*I2;
III2=M21*I1+M22*I2;

figure(3)
colormap(gray)
axis image
imshow(III1,[])
%imagesc(III1)
axis off

figure(4)
colormap(gray)
axis image
imshow(III2,[])
%imagesc(III2)
axis off

pause




%%% center image data
xM1=sum(sum(III1),2)/n;
xM2=sum(sum(III2),2)/n;

X1=III1-xM1*ones(MM,NN);
X2=III2-xM2*ones(MM,NN);

%%% compute inner product matrix
X11=sum(dot(X1,X1),2)/n;
X12=sum(dot(X1,X2),2)/n;
X22=sum(dot(X2,X2),2)/n;

XX=[ [X11 X12];[X12 X22]]

%%% find factorization of inner product matrix
[M1,D1]=eig(XX);

if D1(1,1) >= D1(2,2)
    d1=D1(1,1); d2=D1(2,2);
    Q1=M1(:,1)/norm(M1(:,1),2);
    Q2=M1(:,2)/norm(M1(:,2),2);
else
    d2=D1(1,1); d1=D1(2,2);
    Q2=M1(:,1)/norm(M1(:,1),2);
    Q1=M1(:,2)/norm(M1(:,2),2);
end

Q=[Q1 Q2];
D5=zeros(2,2); D5(1,1)=1/sqrt(d1); D5(2,2)=1/sqrt(d2);
QD=D5*Q';

%%% find y_i's
Y1=QD(1,1)*X1+QD(1,2)*X2;
Y2=QD(2,1)*X1+QD(2,2)*X2;

%%% compute kurtosis as function of angle
ntheta=3000
theta=linspace(0,2*pi,ntheta);
for ia=1:ntheta
    V=[[ cos(theta(ia)) -sin(theta(ia))];[ sin(theta(ia)) cos(theta(ia))]];
    K1=V(1,1)*Y1+V(1,2)*Y2;
    K2=V(2,1)*Y1+V(2,2)*Y2;
    KKs1=sum(sum(K1.^4),2)/n;
    KKs2=sum(sum(K2.^4),2)/n;
    K(ia)=abs(KKs1-3)+abs(KKs2-3);
end

% locate max points and then pick one for separation
iz=0;
for ia=2:ntheta-1
    if K(ia-1) < K(ia) && K(ia+1) < K(ia)
        iz=iz+1;
        thetaMM(iz)=theta(ia);
    end
end
thetaMM
% pick second solution
theta0=thetaMM(2)

% plot kurtosis as function of theta
figure(5)
clf
%get(gcf);
set(gcf,'Position', [25 1115 658 230])

co = [0 0 1;
    0 0.5 0;
    1 0 0;
    0 0.75 0.75;
    0.75 0 0.75;
    0.75 0.75 0;
    0.25 0.25 0.25];
set(groot,'defaultAxesColorOrder',co)

plot(theta,K,'LineWidth',1.4)

%axis([0 2*pi 1.5 3])
xlabel('\theta-axis')
ylabel('K -axis')
set(gca,'xtick',[0 pi/2 pi 3*pi/2 2*pi])
set(gca,'XTickLabel',{'0';'\pi/2';'\pi';'3\pi/2';'2\pi'})
grid on
box on
set(gca,'FontSize',16,'FontWeight','bold')

%%% find mixing matrix and then separate images
V=[[ cos(theta0) -sin(theta0)];[ sin(theta0) cos(theta0)]];
DD=zeros(2,2); DD(1,1)=sqrt(d1); DD(2,2)=sqrt(d2);
A=Q*DD*V'

II1=V(1,1)*Y1+V(1,2)*Y2;
II2=V(2,1)*Y1+V(2,2)*Y2;

% display separed images
figure(6)
clf
colormap(gray)
axis image
imshow(II1,[])
%imagesc(II1)
axis off

figure(7)
clf
colormap(gray)
axis image
imshow(II2,[])
%imagesc(II2)
axis off

toc






















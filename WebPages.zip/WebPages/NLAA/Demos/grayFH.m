function grayFH

% watermarking a grayscale image 

% read in original image
x=imread('ffG.jpg');
I = double(x);
size_of_image=size(I)
clf
% get(gcf)
set(gcf,'Position', [1 925 560 420])
imagesc(I)
colormap(gray)
set(gca,'DataAspectRatio',[1 1 1])
axis image
axis off
say=['Original Image'];
text(5,-30,say,'Color','Black','FontSize',20,'FontWeight','bold')
pause

% compute the svd of original image
m=length(I(:,1));
n=length(I(1,:));
[U,S,V] = svd(I);

% read in watermark
xx=imread('bbG.jpg');
II = double(xx);
size_of_waterman=size(II)
clf
% get(gcf)
set(gcf,'Position', [1 925 560 420])
imagesc(II)
colormap(gray)
set(gca,'DataAspectRatio',[1 1 1])
axis image
axis off
say=['Watermark'];
text(5,-30,say,'Color','Black','FontSize',20,'FontWeight','bold')
pause

% fill-out watermark
mm=length(II(:,1));
nn=length(II(1,:));
% set rest of watermark to white
AA = 255*ones(m,n);
AA(1:mm,1:nn) = II;
clf
% get(gcf)
set(gcf,'Position', [1 925 560 420])
imagesc(AA)
colormap(gray)
set(gca,'DataAspectRatio',[1 1 1])
axis image
axis off
say=['Watermark Reset'];
text(5,-30,say,'Color','Black','FontSize',20,'FontWeight','bold')
pause

% embed image
scale=0.1;
[UU,SS,VV]=svd(S+scale*AA);
Aw=U*SS*V';
AUint8w=uint8(Aw);
clf
% get(gcf)
set(gcf,'Position', [1 925 560 420])
imagesc(AUint8w)
colormap(gray)
set(gca,'DataAspectRatio',[1 1 1])
colormap(gray)
axis image
axis off
say=['Original + Watermark'];
text(5,-30,say,'Color','Black','FontSize',20,'FontWeight','bold')
pause

% extract image
[Uw,Sw,Vw] = svd(Aw);
D=UU*Sw*VV';
W=(D-S)/scale;
AUint8ww=uint8(W);
clf
% get(gcf)
set(gcf,'Position', [1 925 560 420])
imagesc(AUint8ww)
colormap(gray)
set(gca,'DataAspectRatio',[1 1 1])
axis image
axis off
say=['Recovered Watermark'];
text(5,-30,say,'Color','Black','FontSize',20,'FontWeight','bold')
















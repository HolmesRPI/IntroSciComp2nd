function fig9_14

%%%%  ICA solutions for various max theta values

%%% this requires the subaxis and parseArgs files

% generate data
m=6000;
t=linspace(0,10,m);
w1=pi;
w2=1.7*pi;
x=zeros(m,2);
% mixing coefficients
M11=2; M12=1;
M21=3; M22=-2;
for it=1:m
    s1(it) = sin(w1*t(it));  
    s2(it) = sin(w2*t(it)-5);
    x(it,1)=  M11*s1(it) + M12*s2(it);
    x(it,2) = M21*s1(it) + M22*s2(it);
end

xM=sum(x)/m;
for it=1:m
    X(it,:)=x(it,:)-xM;
end

XX=zeros(2,2);
for it=1:m
    XX=XX+[ [X(it,1)*X(it,1) X(it,1)*X(it,2)];[X(it,1)*X(it,2) X(it,2)*X(it,2) ]];
end
XX=XX/m;

[M1,D1]=eig(XX);

if D1(1,1) >= D1(2,2)
        d1=D1(1,1); d2=D1(2,2);
        Q1=M1(:,1)/norm(M1(:,1),2);
        Q2=M1(:,2)/norm(M1(:,2),2);
    else
        d2=D1(1,1); d1=D1(2,2);
        Q2=M1(:,1)/norm(M1(:,1),2);
        Q1=M1(:,2)/norm(M1(:,2),2);
    end
    
Q=[Q1 Q2];

D5=zeros(2,2); D5(1,1)=1/sqrt(d1); D5(2,2)=1/sqrt(d2);

y=zeros(m,2);
for it=1:m
    y(it,:)=D5*Q'*X(it,:)';
     y(it,:)=D5*Q'*[ X(it,1);  X(it,2)] ;
end


clf
%get(gcf);
set(gcf,'Position', [2 830 626 515])
co = [0 0 1;
      0 0.5 0;
      1 0 0;
      0 0.75 0.75;
      0.75 0 0.75;
      0.75 0.75 0;
      0.25 0.25 0.25];
set(groot,'defaultAxesColorOrder',co)

% compute and then plot for particular theta values
theta(1)=0.4340;  theta(2)=2.0063;  theta(3)=3.5787;  theta(4)=5.1511;
for ia=1:4
    V=[[ cos(theta(ia)) -sin(theta(ia))];[ sin(theta(ia)) cos(theta(ia))]];
    for it=1:m
        s(it,1)=V(1,1)*y(it,1)+V(1,2)*y(it,2);
        s(it,2)=V(2,1)*y(it,1)+V(2,2)*y(it,2);
    end

if ia==1
    
    %subplot(4,2,1)
    subaxis(4,2,1,1,'MT',0.04,'MB',0.07,'MR',0.01,'ML',0.03,'P',0.02)

    plot(t,s1,'--b','LineWidth',1.6)
    hold on
    plot(t,s(:,1),'r','LineWidth',1.6)
    say2=['s_1'];
    text(4.5,2.8,say2,'FontSize',18,'FontWeight','bold')
    grid on
    box on
    set(gca,'FontSize',16,'FontWeight','bold')

    %subplot(4,2,2); 
    subaxis(4,2,2,1)
    plot(t,s2,'--b','LineWidth',1.6)
    hold on
    plot(t,s(:,2),'r','LineWidth',1.6)
    say2=['s_2'];
    text(4.5,2.8,say2,'FontSize',18,'FontWeight','bold')
    grid on
    box on
    set(gca,'FontSize',16,'FontWeight','bold');
    
elseif ia==2

    %subplot(4,2,3)
    subaxis(4,2,1,2)
    plot(t,s1,'--b','LineWidth',1.6)
    hold on
    plot(t,s(:,2),'r','LineWidth',1.6)
    hold on
    grid on
    box on
    set(gca,'FontSize',16,'FontWeight','bold')
    
    %subplot(4,2,4)
    subaxis(4,2,2,2)
    plot(t,s2,'--b','LineWidth',1.6)
    hold on
    plot(t,s(:,1),'r','LineWidth',1.6)
    grid on
    box on
    set(gca,'FontSize',16,'FontWeight','bold')
    
elseif ia==3

    %subplot(4,2,5)
    subaxis(4,2,1,3)
    plot(t,s1,'--b','LineWidth',1.6)
    hold on
    plot(t,s(:,1),'r','LineWidth',1.6)
    grid on
    box on
    set(gca,'FontSize',16,'FontWeight','bold')
    
    %subplot(4,2,6)
    subaxis(4,2,2,3)
    plot(t,s2,'--b','LineWidth',1.6)
    hold on
    plot(t,s(:,2),'r','LineWidth',1.6)
    grid on
    box on
    set(gca,'FontSize',16,'FontWeight','bold')
    
else
    
    %subplot(4,2,7)
    subaxis(4,2,2,4)
    plot(t,s1,'--b','LineWidth',1.6)
    hold on
    plot(t,s(:,2),'r','LineWidth',1.6)
    xlabel('t-axis')
    grid on
    box on
    set(gca,'FontSize',16,'FontWeight','bold')
    
    %subplot(4,2,8)
    subaxis(4,2,1,4)
    plot(t,s2,'--b','LineWidth',1.6) 
    hold on
    plot(t,s(:,1),'r','LineWidth',1.6)
    xlabel('t-axis')
    grid on
    box on
    set(gca,'FontSize',16,'FontWeight','bold')
    
end



end







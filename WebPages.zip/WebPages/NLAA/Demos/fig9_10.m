function fig9_10

%%%%  data plots in s and y planes

%%% this requires the subaxis and parseArgs files

% generate data
m=200;
t=linspace(0,10,m);
w1=pi;
w2=1.7*pi;
x=zeros(m,2);
% mixing coefficients
M11=2; M12=1;
M21=3; M22=-2;
for it=1:m
    s1(it) = sin(w1*t(it));  
    s2(it) = sin(w2*t(it)-5);
    x(it,1)=  M11*s1(it) + M12*s2(it);
    x(it,2) = M21*s1(it) + M22*s2(it);
end

%%%% whiten data
s1M=sum(s1)/m;
S1=s1-s1M;
s2M=sum(s2)/m;
S2=s2-s2M;
S11=0; S12=0; S22=0;
for it=1:m
    S11=S11+S1(it)^2/m;
    S12=S12+S1(it)*S2(it)/m;
    S22=S22+S2(it)^2/m;
end
b=sqrt(S11/2);
a=sqrt(S11-b^2);
q=a/b;  r=S12/b;
c=(r*q+sqrt( (1+q^2)*S22-r^2))/(1+q^2);
d=r-q*c;
Z=[[a b];[c d]];
Z*Z'-[[S11 S12];[S12 S22]];
Zi=inv(Z);
for it=1:m
    W1(it)=Zi(1,1)*S1(it)+Zi(1,2)*S2(it);
    W2(it)=Zi(2,1)*S1(it)+Zi(2,2)*S2(it);
end

xM=sum(x)/m;
for it=1:m
%    X(it,:)=x(it,:)-xM;
X(it,1)=M11*W1(it) + M12*W2(it);
X(it,2)=M21*W1(it) + M22*W2(it);
end

XX=zeros(2,2);
for it=1:m
    %XX=XX+X(it,:)'*X(it,:);
    XX=XX+[ [X(it,1)*X(it,1) X(it,1)*X(it,2)];[X(it,1)*X(it,2) X(it,2)*X(it,2) ]];
end
XX=XX/m;

[M1,D1]=eig(XX);

if D1(1,1) >= D1(2,2)
        d1=D1(1,1); d2=D1(2,2);
        Q1=M1(:,1)/norm(M1(:,1),2);
        Q2=M1(:,2)/norm(M1(:,2),2);
    else
        d2=D1(1,1); d1=D1(2,2);
        Q2=M1(:,1)/norm(M1(:,1),2);
        Q1=M1(:,2)/norm(M1(:,2),2);
    end
    
Q=[Q1 Q2];

D5=zeros(2,2); D5(1,1)=1/sqrt(d1); D5(2,2)=1/sqrt(d2);

% check
%Q*D5*D5*Q'-inv(XX)

y=zeros(m,2);
for it=1:m
%    y(it,:)=D5*Q'*X(it,:)';
     y(it,:)=D5*Q'*[ X(it,1);  X(it,2)] ;
end

clf
%get(gcf);
set(gcf,'Position', [5 1009 667 336])

co = [0 0 1;
      0 0.5 0;
      1 0 0;
      0 0.75 0.75;
      0.75 0 0.75;
      0.75 0.75 0;
      0.25 0.25 0.25];
set(groot,'defaultAxesColorOrder',co)

%subplot(1,2,1)
subaxis(1,2,1,'MT',0.04,'MB',0.22,'MR',0.001,'ML',0.01,'P',0.03)

plot(W1,W2,'.b','MarkerSize',10)
hold on
axis([-2 2 -2 2])
axis square
xlabel('s_1 -axis')
ylabel('s_2 -axis')
grid on
box on
set(gca,'FontSize',14,'FontWeight','bold')

%subplot(1,2,2); 
subaxis(1,2,2)
plot(y(:,1),y(:,2),'.b','MarkerSize',10)
hold on
axis square
axis([-2 2 -2 2]);
xlabel('y_1 -axis')
ylabel('y_2 -axis')
grid on
box on
set(gca,'FontSize',14,'FontWeight','bold')

























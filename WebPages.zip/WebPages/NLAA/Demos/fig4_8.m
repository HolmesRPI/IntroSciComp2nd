 function fig4_8

% low rank approximations using SVD

k=[5 10 20 40 80 160];

% read in grayscale image
x=imread('p17.jpg');
A = double(x);
size(A)

[U,S,V] = svd(A);
ss=size(S);
rs=min(ss(1),ss(2))
for i=1:rs
    sigma(i)=S(i,i);
end

% compute and then plot relative error
figure(1)
for i=1:ss(2)-2
    id(i)=i;
    err(i)=sigma(i+1)/sigma(1);
end
clf
% get(gcf)
set(gcf,'Position', [4 1115 658 230])
semilogy(id,err,'r','Linewidth',2)
hold on
set(gca,'ytick',[1e-5 1e-4 1e-3 1e-2 1e-1 1])
xlabel('k-axis')
ylabel(' Relative Error')
grid on
set(gca,'YMinorGrid','off')
box on
set(gca,'FontSize',16,'FontWeight','bold')


% compressed versions
figure(2)
for ik=1:6
    
    % zero out singular values bigger than k
    Sa=zeros(ss(1),ss(2));
    for ir=1:k(ik)
        Sa(ir,ir)=sigma(ir);
    end
    Aa=U*Sa*V';
    
    clf
    % get(gcf)
    set(gcf,'Position', [4 548 560 493])
    
    colormap(gray)
    imagesc(Aa)
    set(gca,'DataAspectRatio',[1 1 1])
    axis image
    axis off
    say=['k = ',num2str(k(ik)),'        Rel Error = ',num2str(err(k(ik)))];
    text(5,-35,say,'Color','Black','FontSize',20,'FontWeight','bold')
    pause
end




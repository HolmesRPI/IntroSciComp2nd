function fig9_13

%%%%  ICA using s^4 on linear waves: K and the optimal solution

% generate data
m=6000;
t=linspace(0,10,m);
w1=pi;
w2=1.7*pi;
x=zeros(m,2);
% mixing coefficients
M11=2; M12=1;
M21=3; M22=-2;
for it=1:m
    s1(it) = sin(w1*t(it));  
    s2(it) = sin(w2*t(it)-5);
    x(it,1)=  M11*s1(it) + M12*s2(it);
    x(it,2) = M21*s1(it) + M22*s2(it);
end

xM=sum(x)/m;
xM1=xM(1)*ones(m,1);
xM2=xM(2)*ones(m,1);
X=x-[xM1 xM2];

XX=(m-1)*cov(X)/m

[M1,D1]=eig(XX);

if D1(1,1) >= D1(2,2)
        d1=D1(1,1); d2=D1(2,2);
        Q1=M1(:,1)/norm(M1(:,1),2);
        Q2=M1(:,2)/norm(M1(:,2),2);
    else
        d2=D1(1,1); d1=D1(2,2);
        Q2=M1(:,1)/norm(M1(:,1),2);
        Q1=M1(:,2)/norm(M1(:,2),2);
    end
    
Q=[Q1 Q2];

D5=zeros(2,2); D5(1,1)=1/sqrt(d1); D5(2,2)=1/sqrt(d2);

y=D5*Q'*X';
y=y';

% compute (and then plot) K as function of theta
ntheta=1000;
theta=linspace(0,2*pi,ntheta);
for ia=1:ntheta
    V=[[ cos(theta(ia)) -sin(theta(ia))];[ sin(theta(ia)) cos(theta(ia))]];
    ssk=y*V';
    kks=ssk.^4/m ;
    suk=sum(kks);
    K(ia)=abs(suk(1)-3)+abs(suk(2)-3);
end


% find min's
iz=0;
for ia=2:ntheta-1
    if K(ia-1)>K(ia) && K(ia+1)>K(ia)
        iz=iz+1;
        thetaM(iz)=theta(ia);
    end
end
thetaM/pi
theta0=thetaM(4)


% find max's
iz=0;
for ia=2:ntheta-1
    if K(ia-1) < K(ia) && K(ia+1) < K(ia)
        iz=iz+1;
        thetaMM(iz)=theta(ia);
    end
end
thetaMM
theta0=thetaMM(2)


clf
%get(gcf);
set(gcf,'Position', [25 1115 658 230])
co = [0 0 1;
      0 0.5 0;
      1 0 0;
      0 0.75 0.75;
      0.75 0 0.75;
      0.75 0.75 0;
      0.25 0.25 0.25];
set(groot,'defaultAxesColorOrder',co)

plot(theta,K,'LineWidth',1.6)
axis([0 2*pi 1.5 3]);
xlabel('\theta-axis')
ylabel('K -axis')

set(gca,'xtick',[0 pi/2 pi 3*pi/2 2*pi])
%set(gca,'ytick',[0 1 2 3]);
set(gca,'XTickLabel',{'0';'\pi/2';'\pi';'3\pi/2';'2\pi'})
%set(gca,'YTickLabel',{'0';' ';' ';' '})

grid on
box on
set(gca,'FontSize',16,'FontWeight','bold')










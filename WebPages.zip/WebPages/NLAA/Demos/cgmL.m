function cgmL

%  sparse vs non-sparse CGM for solving Ax=b

for isize=1:5
    % A from Laplace's equation
    N=20*isize;
    M=N;
    n=N*M;
    lambda2=1;
    D=2*(1+lambda2)*eye(n,n);
    SD1=diag(-lambda2*ones(n-1,1),-1);
    for i=N+1:N:n-1
        SD1(i,i-1)=0;
    end
    SDM=diag(-ones(n-M,1),-M);
    AA=D+SD1+SD1'+SDM+SDM';
    
    %%% full version
    %A=AA;
    
    %%% sparse version
    A=sparse(AA);
    
    time(isize)=0;
    xe=2*(1-0.5*rand(n,1));
    b=A*xe;
    
    tic
    for ic=1:6
        v=cgm(A,b,xe);
    end
    time(isize)=time(isize)+toc;   
    dim(isize)=n;
end

dim
time=time/5

sizeNS = [400  1600  3600  6400  10000]
time
timesNS = [0.0062    0.2003    1.3698    5.7010   17.6187]

tic
AA\b;
A_non=toc
tic
A\b;
A_sp=toc

clf
% get(gcf)
set(gcf,'Position', [25 1115 658 230])
co = [0 0 1;
    0 0.5 0;
    1 0 0;
    0 0.75 0.75;
    0.75 0 0.75;
    0.75 0.75 0;
    0.25 0.25 0.25];
set(groot,'defaultAxesColorOrder',co)

semilogy(dim,time,'--or','LineWidth',1.6,'MarkerSize',9)
hold on
semilogy(dim,timesNS,'-.ob','LineWidth',1.6,'MarkerSize',9)

grid on
axis([ 0 10000 0.001 100])
ylabel('Computing Times (sec)')
xlabel('n-axis')
legend(' Sparse CGM',' Non-sparse CGM','Location','NorthWest');
set(gca,'FontSize',16,'FontWeight','bold')
set(findobj(gcf,'tag','legend'),'FontSize',16,'FontWeight','bold')
hold off



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% CGM
function x=cgm(A,b,sol)

% set CGM parameters
tol=1000*eps;

n=length(b);
x=zeros(n,1);
% start iteration
r=b-A*x;
d=r;
rr=r'*r;
err=10*tol;
counter=0;
while err>tol
    counter=counter+1;
    q=A*d;
    alpha=rr/(d'*q);
    x=x+alpha*d;
    r=r-alpha*q;
    rr0=rr;
    rr=r'*r;
    beta=rr/rr0;
    d=r+beta*d;
    err=norm(alpha*d,inf);
end


















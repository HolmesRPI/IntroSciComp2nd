function fig9_8
 
% two frequencies

nt=1000;
t=linspace(0,10,nt);
w1=pi;
w2=1.7*pi;
for it=1:nt
    S1(it) = sin(w1*t(it));  
    S2(it) = sin(w2*t(it)-5); 
end

M11=2; M12=1;
M21=3; M22=-2;

figure(1)
clf
co = [0 0 1;
      0 0.5 0;
      1 0 0;
      0 0.75 0.75;
      0.75 0 0.75;
      0.75 0.75 0;
      0.25 0.25 0.25];
set(groot,'defaultAxesColorOrder',co)

% get(gcf)
set(gcf,'Position', [7 1028 599 317])
subplot(2,1,1)
plot(t,S1,'LineWidth',1.4)       
ylabel('s_1 -axis','FontSize',16,'FontWeight','bold')
grid on
box on
set(gca,'FontSize',16,'FontWeight','bold')

subplot(2,1,2)
plot(t,S2,'r','LineWidth',1.6)
xlabel('t-axis')
ylabel('s_2 -axis')
grid on
box on
set(gca,'FontSize',16,'FontWeight','bold')


figure(2)
   
M1 = M11*S1 + M12*S2;                  % mixing 1
M2 = M21*S1 + M22*S2;            % mixing 2

clf
% get(gcf)
set(gcf,'Position', [610 1029 598 316])
subplot(2,1,1); 
plot(t,M1,'LineWidth',1.4)      % plot mixing 1
ylabel('x_1 -axis')
grid on
box on
set(gca,'FontSize',16,'FontWeight','bold')

subplot(2,1,2) 
plot(t,M2, 'r','LineWidth',1.6)   % plot mixing 2
xlabel('t-axis')
ylabel('x_2 -axis')
grid on
box on
set(gca,'FontSize',16,'FontWeight','bold')





























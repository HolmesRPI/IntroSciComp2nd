function fig9_5

%  finds best hyperplane fit
%  IV is variable being fitted 

% pick variable
IV=8

% labels (for plotting)
lab{1}='Population'; lab{2}='Murder';
lab{3}='Rape'; lab{4}='Robbery';
lab{5}='Assault'; lab{6}='Burglary';
lab{7}='Larceny'; lab{8}='Car Theft';

% load training (A) and testing (B) data sets
A=importdata('AdataC.txt');
B=importdata('BdataC.txt');



% interchange IV column with first column 
z=A(:,1); A(:,1)=A(:,IV); A(:,IV)=z;
zz=B(:,1); B(:,1)=B(:,IV); B(:,IV)=zz;

% normalization of A
means=mean(A);
[m n]=size(A);
D=zeros(m,n);
for j=1:n
    D(:,j)=A(:,j)-means(j)*ones(m,1);
end
DD=zeros(m,n);
for j=1:n
%    DM(j)=max(abs(D(:,j)));
    DM(j)=norm(D(:,j),2)/sqrt(m);
    DD(:,j)=D(:,j)/DM(j);
end

% SVD
[U,S,V] = svd(DD);
ss=size(S);
for i=1:ss(2)
    id(i)=i;
    sigmas(i)=S(i,i);
end
Q=V(2:n,1:n-1);

%  normalize testing data (using same normalization used for A)
[M N]=size(B);
DB=zeros(M,N);
for j=1:N
    DB(:,j)=B(:,j)-means(j)*ones(M,1);
end
DDB=zeros(M,N);
for j=1:N
    DDB(:,j)=DB(:,j)/DM(j);
end

% find hyperplane coefficients (alpha's) 
% along with predicted values (PP) and testing set values (AP)
for i=1:M
    alpha=Q\DDB(i,2:N)';
    PP(i)=dot(alpha,V(1,1:n-1)');
    AP(i)=DDB(i,1);
end

% plot data
clf
% get(gcf)
set(gcf,'Position', [4 918 563 427])
co = [0 0 1;
      0 0.5 0;
      1 0 0;
      0 0.75 0.75;
      0.75 0 0.75;
      0.75 0.75 0;
      0.25 0.25 0.25];
set(groot,'defaultAxesColorOrder',co)

% plot predicted vesrus testing values
plot(AP,PP,'ob','MarkerSize',8,'LineWidth',2)
hold on

% snazzy label
text(1.5,0,lab{IV},'FontSize',18,'FontWeight','bold')

LX=min(AP(:)); RX=max(AP(:)); LY=min(PP(:)); RY=max(PP(:));
axis([LX RX LY RY])
plot([LX RX],[LX RX],'r','LineWidth',1.6)
axis square
xlabel('Training')
ylabel('Testing')
grid on
box on
set(gca,'FontSize',18,'FontWeight','bold')






















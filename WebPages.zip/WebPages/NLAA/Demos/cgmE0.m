function cgmE

%  check CGM for solving Ax=b and
%  try different matrices

n=1000;
fprintf('\n n = %i \n\n',n)

% matrix with exactly 3 eigenvalues a, a-1, a+1
a=3;
A2=a*eye(n);
A2(1,n)=1; A2(n,1)=1;
cond_A2=cond(A2,2)

% HW1 matrix
A1=diag(1:n);
cond_A1=cond(A1,2)

% tri-diagonal
D=2*eye(n,n);
SD1=diag(-ones(n-1,1),-1);
A3=D+SD1+SD1';
cond_A3=cond(A3,2)

% specify solution (xe)
xe=2*(1-0.5*rand(n,1));
b1=A1*xe;
b2=A2*xe;
b3=A3*xe;

% use CGM and return error values
A1_err=cgm(A1,b1,xe);
A2_err=cgm(A2,b2,xe);
A3_err=cgm(A3,b3,xe);

iter1=1:length(A1_err);
iter2=1:length(A2_err);
iter3=1:length(A3_err);
clf
% get(gcf)
set(gcf,'Position', [25 1115 658 230])
co = [0 0 1;
      0 0.5 0;
      1 0 0;
      0 0.75 0.75;
      0.75 0 0.75;
      0.75 0.75 0;
      0.25 0.25 0.25];
set(groot,'defaultAxesColorOrder',co)

loglog(iter1,A1_err,'--b','LineWidth',2)
hold on
loglog(iter2,A2_err,'--or','LineWidth',1.6,'MarkerSize',9)
loglog(iter3,A3_err,'-.k','LineWidth',2.4)

grid on
set(gca,'MinorGridLineStyle','none')
axis([ 1 1200 1e-12 10])
set(gca,'YTick',[1e-12 1e-8 1e-4 1 ])
hold on
ylabel('Error')
xlabel('Iteration Steps')
legend(' A_1',' A_2',' A_3','Location','South');
set(gca,'FontSize',16,'FontWeight','bold')
set(findobj(gcf,'tag','legend'),'FontSize',16,'FontWeight','bold')
hold off

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% CGM 
function error=cgm(A,b,sol)

% set CGM parameters
tol=1000*eps;

n=length(b);
x=zeros(n,1);
% start iteration
r=b-A*x;
d=r;
rr=r'*r;
err=10*tol;
counter=0;
while err>tol
    counter=counter+1;
    q=A*d;
    alpha=rr/(d'*q);
    x=x+alpha*d;
    r=r-alpha*q;
    rr0=rr;
    rr=r'*r; 
    beta=rr/rr0;
    d=r+beta*d;
	error(counter)=norm(x-sol,inf); 
    err=error(counter);
    if error(counter)==0
        error(counter)=1e-1000;
    end
end


















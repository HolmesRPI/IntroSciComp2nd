function qr1

% QR usimg Householder for m x n with m>=n

% Exanple 1: ramdon natrix
% n=8; m=n;
% 
% D=2*eye(n,n);
% SD1=diag(-ones(n-1,1),-1);
% A=D+SD1+SD1';

n=3; m=n;
A=[[0 0 0];[-1 3 0];[0 -2 1]]

R=zeros(m,n);
Z=A;
for j=1:n
    v=Z(:,1);
    beta=1;
    if v(1)>0
        beta=-1;
    end
    v(1)=v(1)+beta*norm(v,2);
    %vv=v'*v;
    vv=norm(v,2)^2;
    S=Z;
    if vv ~= 0
        v=v*sqrt(2/vv);
        S=S-v*(v'*Z);
    end
    if j==1
        Q=eye(m)-v*v';
    elseif vv ~= 0
%         Q(:,j:m)=Q(:,j:m)-(Q(:,j:m)*v)*v';
        v=[zeros(j-1,1); v];
        Q=Q-(Q*v)*v';
    end
    if j==n-1 && m==n
        R(n-1,n-1:n)=S(1,:);
        R(n,n)=S(2,2);
        break
    elseif j==n
        R(n,n)=S(1,1);
        break
    end
    
    Z=S(2:m-j+1,2:n-j+1);
    R(j,j:n)=S(1,:);
    
end


R
Q
A-Q*R
A-R'*Q'

A=[[1 0];[0 -1];[0 1]]
b=[3;0;2]
pinv(A)*b












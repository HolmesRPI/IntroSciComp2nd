function qrST

% speed test for QR using Householder

my_time=0;
mat_time=0;

% run the trial 20 times
for ic=1:20
    
    % Example: random matrix
    m=100; n=1000;
    A=rand(n,m);
    
    % table 10.1 code
    tic
    R=zeros(n,m);
    Z=A;
    for j=1:m
        v=Z(:,1);
        beta=1;
        if v(1)>0
            beta=-1;
        end
        v(1)=v(1)+beta*norm(v,2);
        %vv=v'*v;
        vv=norm(v,2)^2;
        S=Z;
        if vv ~= 0
            v=v*sqrt(2/vv);
            S=S-v*(v'*Z);
        end
        if j==1
            Q=eye(n)-v*v';
        elseif vv ~= 0
            %Q(:,j:n)=Q(:,j:n)-(Q(:,j:n)*v)*v';
            v=[zeros(j-1,1); v];
            Q=Q-(Q*v)*v';
        end
        if j==m-1 && n==m
            R(m-1,m-1:m)=S(1,:);
            R(m,m)=S(2,2);
            break
        elseif j==m
            R(m,m)=S(1,1);
            break
        end
        
        Z=S(2:n-j+1,2:m-j+1);
        R(j,j:m)=S(1,:);
        
    end
    my_time=toc+my_time;
    
    tic
    [QQ,RR]=qr(A);
    mat_time=mat_time+toc;
end

ratio=my_time/mat_time


















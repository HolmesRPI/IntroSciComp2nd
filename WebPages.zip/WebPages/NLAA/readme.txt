
113_senators.txt file:  it is a tab separated text file

row 1: column titles and they are:  name  party  state  bill_1  bill_2 . . . 
row 2: senator 1 information
row 3: senator 2 information
etc

note the bills are identified as X_113_1_1, etc

voting scores for each senator:  0=no  1=yes  2 or 3 = did not vote

you will need to change these numbers to the following:    -1=no  1=yes  0=did not vote

WARNING:  this data table is the transpose of our typical data matrix



helpful MATLAB commands:

T = readtable('113_senators.txt');   % this reads in data table

B = table2array(T(:,4:175));         % this constructs (transpose of) voting matrix  



Reference: the data is from

https://github.com/VikParuchuri/political-positions/blob/master/113_frame.csv



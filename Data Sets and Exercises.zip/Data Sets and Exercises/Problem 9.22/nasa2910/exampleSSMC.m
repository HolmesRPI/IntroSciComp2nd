function exampleSSMC

% example of using a matrix from the SuiteSparse Matrix Collection 

[A, rows, cols, entries] = mmread('bcsstk09.mtx');
%issparse(A)
spy(A)
[n nn]=size(A)
b=ones(n,1);
x=A*b;
norm(x,inf)



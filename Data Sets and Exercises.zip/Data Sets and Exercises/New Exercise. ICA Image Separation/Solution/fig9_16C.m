function fig9_16C

% this requires fig1.jpg and fig2.jpg

%  creates mixed images

tic

% read in original images
x1=imread('w.jpg');
I11 = double(x1);
I1 = I11(1:597,:);
size1=size(I1)

x2=imread('q.jpg');
I2 = double(x2);
size2=size(I2)


% display images
figure(1)
colormap(gray)
axis image
imshow(I1,[])
%imagesc(I1)
axis off

figure(2)
colormap(gray)
axis image
imshow(I2,[])
%imagesc(I2)
axis off

pause
MM=size1(1); NN=size1(2);
n=MM*NN

% mixing matrix M_{11}+M_{12}=1 etc
M11=0.7; M12=0.3;
M21=0.95; M22=0.05;
M=[[M11 M12];[M21 M22]]

%%% calculate and show the mixed images
III1=M11*I1+M12*I2;
III2=M21*I1+M22*I2;

figure(3)
colormap(gray)
axis image
imshow(III1,[])
AU1=uint8(III1);
imwrite(AU1,'p1O.jpg')
axis off

figure(4)
colormap(gray)
axis image
imshow(III2,[])
AU2=uint8(III2);
imwrite(AU2,'p2O.jpg')
axis off




















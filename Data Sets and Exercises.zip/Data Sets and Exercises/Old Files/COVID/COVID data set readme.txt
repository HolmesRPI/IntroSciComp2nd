
Data: daily cumulative number of confirmed COVID cases in each county in the USA starting on 1/22/2020 

columns: county name and identifying information and the dates for each measurement
rows: the values for each county

Source: https://usafacts.org/visualizations/coronavirus-covid-19-spread-map/ 
Date of Download: 6/10/2021
function split

% partition data set D into testing set A and training set B

AA=importdata('red_wine.txt');
[nA mA]=size(AA)

% randomize rows
rows=randperm(nA);
n=round(2*nA/3)
A=AA(rows(1:n),:);
B=AA(rows(n+1:nA),:);

save('AdataW.txt','A','-ascii');
save('BdataW.txt','B','-ascii');


















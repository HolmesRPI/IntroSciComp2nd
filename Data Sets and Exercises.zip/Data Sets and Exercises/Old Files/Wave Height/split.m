function split

%  generate testing (A) and training (B) sets
%  uses 3/4 to 1/4 split

AA=importdata('reduced station 2006 data.txt');
[nA mA]=size(AA);

% randomize rows
rows=randperm(nA);

% split data set
n=round(3*nA/4)
A=AA(rows(1:n),:);
B=AA(rows(n+1:nA),:);

save('AdataW.txt','A','-ascii');
save('BdataW.txt','B','-ascii');



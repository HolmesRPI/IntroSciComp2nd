function pca

% use k-dimensonal approximation
% p = a_1*v_2 + ... + a_k*v_k

%  Columns: WD	WSPD	GST	WVHT	DPD	APD	BAR	WTMP

% pick which column is used for the "prediction vs actual" plot
col=4;

% pick k
k=7
% R^2(k) values:  0.0091978 0.00011986 0.25002  0.24769  0.90254 0.96478  0.9941

% % load data
% X=importdata('wave_data.txt');
% [nX mX]=size(X)
% 
% % swap: put "col" so it's last column
% NJ=X(:,col); NM=X(:,mX);
% X(:,col)=NM; X(:,mX)=NJ;
% 
% % randomize rows then split data matrix into
% % training (A) and testing (B) data sets
% rows=randperm(nX);
% nn=round(2*nX/3);
% A=X(rows(1:nn),:);
% B=X(rows(nn+1:nX),:);

% load training (A) and testing (B) data sets
A=importdata('AdataH.txt');
B=importdata('BdataH.txt');

% interchange: put column "col" so it's last column
n=length(A(1,:));
z=A(:,col);
A(:,col)=A(:,n);
A(:,n)=z;
zz=B(:,col);
B(:,col)=B(:,n);
B(:,n)=zz;

% normalization of A
means=mean(A);
[m n]=size(A);
D=zeros(m,n);
for j=1:n
    D(:,j)=A(:,j)-means(j)*ones(m,1);
end
P=zeros(m,n);
for j=1:n
    %    DM(j)=max(abs(D(:,j)));
    DM(j)=norm(D(:,j),2)/sqrt(m);
    P(:,j)=D(:,j)/DM(j);
end

%  normalize testing data (using same normalization used for A)
[M N]=size(B);
DB=zeros(M,N);
for j=1:N
    DB(:,j)=B(:,j)-means(j)*ones(M,1);
end
Q=zeros(M,N);
for j=1:N
    Q(:,j)=DB(:,j)/DM(j);
end

% SVD
[U,S,V] = svd(P);
ss=size(S);

figure(1)
s2(1)=S(1,1)^2;
for ir=2:ss(2)
    s2(ir)=s2(ir-1)+S(ir,ir)^2;
end
for ir=1:ss(2)-1
    R(ir)=(s2(ss(2))-s2(ir+1))/s2(ss(2));
end

clf
% get(gcf)
set(gcf,'Position', [4 1115 658 230])
plot(1:ss(2)-1,R,'o--r','Linewidth',2)
hold on
%set(gca,'ytick',[1e-5 1e-4 1e-3 1e-2 1e-1 1])
xlabel('k-axis')
ylabel(' Relative Error')
grid on
set(gca,'YMinorGrid','off')
box on
set(gca,'FontSize',16,'FontWeight','bold')

% Pred = predicted values
% alpha's determined using first k values
Pred=zeros(M,N);
for i=1:M
    alpha=V(1:k,1:k)\Q(i,1:k)';
    Pred(i,:)=(V(:,1:k)*alpha)';
end

% prediction and actual for last column
pred=Pred(:,N);
actual=Q(:,N);

format shortG
% mean squared prediction error
MSPE=norm(pred-actual,2)^2/length(pred)
% mean absolute deviation
MAD=norm(pred-actual,1)/length(pred)
% coefficient of determination R^2
R2=(dot(pred,actual)/(norm(pred,2)*norm(actual,2)))^2

figure(2)
% plot data
clf
% get(gcf)
set(gcf,'Position', [4 918 563 427])
co = [0 0 1;
    0 0.5 0;
    1 0 0;
    0 0.75 0.75;
    0.75 0 0.75;
    0.75 0.75 0;
    0.25 0.25 0.25];
set(groot,'defaultAxesColorOrder',co)

% plot predicted versus testing values
plot(pred,actual,'ob','MarkerSize',8,'LineWidth',2)
hold on
LX=min(pred); RX=max(pred); LY=min(actual); RY=max(actual);
axis([LX RX LY RY])
plot([LX RX],[LX RX],'r','LineWidth',1.6)
axis square
xlabel('Training')
ylabel('Testing')
grid on
box on
    say=['k = ',num2str(k),'            MSPE = ',num2str(MSPE)];
    text(LX,11,say,'Color','Black','FontSize',16,'FontWeight','bold')
set(gca,'FontSize',16,'FontWeight','bold')


R2=[0.0091978 0.00011986 0.25002  0.24769  0.90254 0.96478  0.9941];
figure(3)
clf
% get(gcf)
set(gcf,'Position', [4 1115 658 230])
%plot(1:7,R2,'o--r','Linewidth',2)
semilogy(1:7,R2,'o--r','Linewidth',2)
hold on
%set(gca,'ytick',[1e-5 1e-4 1e-3 1e-2 1e-1 1])
xlabel('k-axis')
ylabel(' R^2')
grid on
set(gca,'YMinorGrid','off')
box on
set(gca,'FontSize',16,'FontWeight','bold')


















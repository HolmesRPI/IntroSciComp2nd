function cong

%  compare normalized and unnormalized

A=readtable('113_senators.txt');
size(A)
A(1:4,1:4)

X=table2array(A(:,4:175));
[m n]=size(X)
for i=1:m
    for j=1:n
        if X(i,j)==0
            X(i,j)==-1;
        elseif X(i,j)==2 || X(i,j)==3
            X(i,j)==0;
        end
    end
end

X(1:4,1:4)
X(1:4,170:172)

[U,S,V]=svd(X');

sigma=diag(S);

% S(1,1)
% S(2,2)
% S(3,3)
% S(4,4)

%V(:,1)
% for i=1:m
%     if V(i,1)<-0.2
%         i
%         V(i,1)
%     end
% end

% for i=1:m
%     if V(i,2)<-0.15
%         i
%         V(i,1)
%     end
% end

figure(1)
clf
plot(V(1:55,1),V(1:55,2),'ob','MarkerSize',8)
hold on
plot(V(56:57,1),V(56:57,2),'sg','MarkerSize',8)
plot(V(58:103,1),V(58:103,2),'*r','MarkerSize',8)
xlabel('v_1-axis')
ylabel(' v_2-axis')
set(gca,'FontSize',14,'FontWeight','bold')

figure(2)
clf
scatter3(V(1:55,1),V(1:55,2),V(1:55,3),'ob')
hold on
scatter3(V(56:57,1),V(56:57,2),V(56:57,3),'sg')
scatter3(V(58:103,1),V(58:103,2),V(58:103,3),'*r')
xlabel('v_1-axis')
ylabel(' v_2-axis')
zlabel(' v_3-axis')
set(gca,'FontSize',14,'FontWeight','bold')

figure(3)
clf
n=length(sigma);
plot(1:n-1,sigma(2:n)/sigma(1),'or')


%scatter3(V(:,1),V(:,2),V(:,3),'MarkerEdgeColor','k','MarkerFaceColor',[0 0.75 0.75])










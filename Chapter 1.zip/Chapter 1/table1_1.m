function table1_1

%%%% loop for increasing values of n
for ic=1:6
    n=10^ic;
    
    %%%% sum series from small to large
    s=0;
    for j=1:n
        s=s+1/(n-j+1);
    end
    
    %%%% sum series from large to small
    S=0;
    for jj=1:n
        S=S+1/jj;
    end
    %%%% print out S(n)-s(n)
    fprintf('\n %i &  %12.2e \\\\',n,S-s)
end
fprintf('\n')

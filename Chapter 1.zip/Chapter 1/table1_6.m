function table1_6

% calcualte exact value of sum
x=1/8;
s=x/(1-x);

%  a_err = abs iterative error
%  r_err = relative iterative error
for n=1:6
    y=1+s;
    for j=1:n
        y=y-x^j;
    end
    sum(n)=7*y;
    if n==1
        fprintf('\n %i &  %18.15f \\\\',n,sum(n))
    else
        a_err=abs(sum(n)-sum(n-1));
        r_err=a_err/abs(sum(n));
        fprintf('\n %i &  %18.15f &  %5.1e &  %5.1e \\\\',n,sum(n),a_err,r_err)
    end
end
fprintf('\n')
function fig1_3

%  loop to generate function values
nx=50;
for i=1:nx
	k(i)=i;
	n=2^k(i)+1;
	y(i)=sin(n*pi);
end

clf
% get(gcf)
set(gcf,'Position', [25 1115 658 230])
co = [0 0 1;
      0 0.5 0;
      1 0 0;
      0 0.75 0.75;
      0.75 0 0.75;
      0.75 0.75 0;
      0.25 0.25 0.25];
set(groot,'defaultAxesColorOrder',co)

semilogy(k,abs(y),'-sr','LineWidth',1.2,'MarkerSize',8)
hold on
grid on
box on
axis([0 50 1e-16 1])
set(gca,'ytick',[1e-16 1e-12 1e-8 1e-4 1])
xlabel('k-axis')
ylabel('|y|')
set(gca,'FontSize',16,'FontWeight','bold')


function fig1_2

% compute the values of the ratio
x0=16;
n=10000;
exs=linspace(-18,0,n);
for k=1:n
	h(k)=10^exs(k);
	F(k)=(f(x0+h(k)) - f(x0))/h(k);
end

clf
% get(gcf)
set(gcf,'Position', [25 1115 658 230])
co = [0 0 1;
      0 0.5 0;
      1 0 0;
      0 0.75 0.75;
      0.75 0 0.75;
      0.75 0.75 0;
      0.25 0.25 0.25];
set(groot,'defaultAxesColorOrder',co)

% plot the results
semilogx(h,F,'b-','LineWidth',1.2)
hold on
axis([1e-18 1e-2 -0.02 0.1875])
set(gca,'ytick',[0 0.0625 0.1250 0.1875])
set(gca,'yTickLabel',{'0 ';'1/16 ';'1/8 ';'3/16 '})
set(gca,'xtick',[1e-18 1e-14 1e-10 1e-6 1e-2])
grid on
xlabel('k-axis')
ylabel('y-axis')
set(gca,'FontSize',16,'FontWeight','bold')
hold off


function y=f(x)
y=sqrt(x);















function my_qr

% QR usimg Householder

m=1000; n=100;
A=rand(m,n);

tic
nm=min(n,m);
R=A;
for j=1:nm
    Z=R(j:m,j:n);
    v=Z(:,1);
    beta=1;
    if v(1)>0
        beta=-1;
    end
    v(1)=v(1)+beta*norm(v,2);
    vv=v'*v;
    if vv ~=0
        v=v*sqrt(2/vv);
        R(j:m,j:n)=Z-v*(v'*Z);
    end
    if j==1
        Q=eye(m)-v*v';
    elseif vv ~=0
        X=Q(1:m,j:m);
        Q(1:m,j:m)=X-(X*v)*v';
    end   
end
my_time=toc

tic
[QQ,RR]=qr(A);
mat_time=toc
ratio=my_time/mat_time

my_error=norm(Q*R-A,inf)
matlab_error=norm(QQ*RR-A,inf)


















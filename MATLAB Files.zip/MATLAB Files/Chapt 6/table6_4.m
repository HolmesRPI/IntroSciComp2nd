function table6_4

%  Integrate  f(x)  over  [a, b]  using hermite
%
%  Inputs:
%        a = left endpoint of interval
%        b = right endpoint of interval
%        f = function
%       df = derivative of function

a=0; b=1;
exact=(exp(3)-1)/3;

%  interv = number of subinternals
interv=[10 20 40 80 160];
nk=length(interv);
for k=1:nk
    n=interv(k);
    H(k) = herm(a,b,n);
    errH(k)=abs(exact-H(k));
end

fprintf('\n n  \t\t I_H \t \t Error \n')
for k=1:nk
    fprintf(' %i \t %19.15f \t %5.1e    \n',interv(k),H(k),errH(k))
    %fprintf('\\, %i  \\, & \\,\\, %19.15f \\,\\, & \\,\\, %5.1e  \\\\ \n',interv(k),H(k),errH(k))
end
fprintf('\n')


function y=f(x)
y=exp(3*x);

function y=df(x)
y=3*exp(3*x);

%%% Hermite: n = number of subintervals
function s=herm(a,b,n)
xd=linspace(a,b,n+1);
h=xd(2)-xd(1);
s=0.5*f(xd(1));
for j=2:n
    s=s+f(xd(j));
end
df0=df(a);  df1=df(b);
s=h*(s + 0.5*f(xd(n+1))) + h^2*(df0-df1)/12;







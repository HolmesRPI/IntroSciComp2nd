function fig6_13

a=0; b=3;

nxe=4000;
xe=linspace(a,b,nxe);
for ix=1:nxe
    ye(ix)=f(xe(ix));
end

clf
% get(gcf)
set(gcf,'Position', [25 1115 658 230])
subaxis(1,1,1,1,'MT',0.01,'MB',0.18,'MR',-0.02,'ML',0.036,'P',0.04)
co = [0 0 1;
    0 0.5 0;
    1 0 0;
    0 0.75 0.75;
    0.75 0 0.75;
    0.75 0.75 0;
    0.25 0.25 0.25];
set(groot,'defaultAxesColorOrder',co)

plot(xe,ye,'b','LineWidth',1.6)
hold on
axis([a b -0.04 1.04]);
grid on
xlabel('x-axis')
ylabel('y-axis')
set(gca,'FontSize',16,'FontWeight','bold')

%exportgraphics(gca,'/Users/mark/Desktop/sharp.eps')


function y=f(x)
y=cos(x^3)^200;









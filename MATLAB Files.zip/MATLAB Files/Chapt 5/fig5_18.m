function fig5_18

a=-1; b=1;

% interpolation data
nx=13;
xd=linspace(a,b,nx);
for iy=1:nx
    yd(iy)=1/(1+25*xd(iy)^2);
end

% exact values
n=400;
x=linspace(a,b,n);
for ie=1:n
    ye(ie)=1/(1+25*x(ie)^2);
end

%%%% evaluate and then plot spline function
%  ysM = MATLAB spline function
%  ys = natural spline (requires splineA.m file)

ys = splineA(xd,yd,x);
%ysM = spline(xd,yd1,x);

% p_n(x)
for ix=1:nx
    cc=(2*ix-1)*pi/(2*nx);
    xd(ix)=0.5*(a+b+(b-a)*cos(cc));
    yd(ix)=f(xd(ix));
end
for ii=1:n
    p(ii)=0;
    for k=1:nx
        p(ii)=p(ii)+yd(k)*ell(k,x(ii),xd);
    end
end

clf
% get(gcf)
set(gcf,'Position', [25 1115 658 230])
subaxis(1,1,1,1,'MT',0.01,'MB',0.17,'MR',-0.03,'ML',-0.005,'P',0.04)
co = [0 0 1;
    0 0.5 0;
    1 0 0;
    0 0.75 0.75;
    0.75 0 0.75;
    0.75 0.75 0;
    0.25 0.25 0.25];
set(groot,'defaultAxesColorOrder',co)

hold on
box on
plot(x,ys,'r','LineWidth',1.6)
plot(x,p,'b','LineWidth',1.6)
plot(x,ye,'--k','LineWidth',1.6)
set(gca,'YTick',[0 1])
set(gca,'XTick',[-1 -0.5 0 0.5 1])
axis([-1 1 -0.02 1.05])
grid on
xlabel('x-axis')
legend({' Spline',' Cheb',' Runge'},'Location','NorthEast','FontSize',16,'FontWeight','bold')
set(gca,'FontSize',16,'FontWeight','bold')

%exportgraphics(gcf,'/Users/mark/Desktop/splineR.eps')


function g=f(x)
g=1/(1+25*x^2);

% ell_i(x) function
function p=ell(i,x,xd)
[n1 n2]=size(xd);
p=1;
for j=1:n2
    if j ~= i
        p=p*(x-xd(j))/(xd(i)-xd(j));
    end
end












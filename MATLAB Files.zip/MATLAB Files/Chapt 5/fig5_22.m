function fig5_22

% fit cubic splines to the four data sets

%  ysM = MATLAB spline function
%  ys = natural spline (requires splineA.m file)

%%%%%  generate the data sets
a=-1; b=1;
nx=15;
xd=linspace(a,b,nx);

yd=zeros(nx,1);
yd(7)=1;

%%%% evaluate and then plot spline function
%  ysM = MATLAB spline function
%  ys = natural spline (requires splineA.m file)

n=800;
xp=linspace(a,b,n);
ys = splineA(xd,yd,xp);
ysM = spline(xd,yd,xp);
%ysf = splineA(xd,yd,xp, [1 1],[0 0]);

clf
% get(gcf)
set(gcf,'Position', [25 1115 658 230])
subaxis(1,1,1,1,'MT',0.01,'MB',0.173,'MR',-0.01,'ML',0.02,'P',0.04)
co = [0 0 1;
    0 0.5 0;
    1 0 0;
    0 0.75 0.75;
    0.75 0 0.75;
    0.75 0.75 0;
    0.25 0.25 0.25];
set(groot,'defaultAxesColorOrder',co)

hold on
box on
plot(xd,yd,'or','MarkerSize',8,'LineWidth',2)
plot(xp,ys,'b','LineWidth',1.6)
axis([-1 1 -0.2 1.05])
set(gca,'YTick',[0 1])
set(gca,'XTick',[-1 -0.5 0 0.5 1])
grid on
xlabel('x-axis')
ylabel('y-axis')
set(gca,'FontSize',16,'FontWeight','bold')

%exportgraphics(gcf,'/Users/mark/Desktop/fund.eps')








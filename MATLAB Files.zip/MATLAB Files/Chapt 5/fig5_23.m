function fig5_23

a=0; b=3;
nx=100;
x=linspace(a,b,nx);

for ix=1:nx
    f(ix)=exp(sin(x(ix)))/(5+x(ix));
    f2(ix)=d2f(x(ix));
    f4(ix)=d4f(x(ix));
end

m2=max(abs(f2));
m4=max(abs(f4));
f2=1.9*f2/m2;
f4=2.9*f4/m4;

clf
% get(gcf)
set(gcf,'Position', [25 1115 658 230])
subaxis(1,1,1,1,'MT',0.01,'MB',0.19,'MR',-0.01,'ML',0.01,'P',0.04)
co = [0 0 1;
    0 0.5 0;
    1 0 0;
    0 0.75 0.75;
    0.75 0 0.75;
    0.75 0.75 0;
    0.25 0.25 0.25];
set(groot,'defaultAxesColorOrder',co)

hold on
box on
plot(x,f2,'--b','LineWidth',1.5)
plot(x,f4,'r','LineWidth',1.5)
%set(gca,'YTick',[0 200 400 600])
%set(gca,'XTick',[0 0.1 0.2 0.3 0.4])
axis([0 3 -2 3])
grid on
xlabel('x-axis')
%ylabel('y-axis')
set(gca,'FontSize',16,'FontWeight','bold')
legend(' f^{\prime\prime}',' f^{\prime\prime\prime\prime}','Location','NorthEast','AutoUpdate','off','FontSize',16,'FontWeight','bold')
hold off

%exportgraphics(gcf,'/Users/mark/Desktop/hwex2.eps')

function z=d2f(x)
z=-4*sin(2*x)*exp(sin(2*x))/(4+x)+4*cos(2*x)^2*exp(sin(2*x))/(4+x)-4*cos(2*x)*exp(sin(2*x))/(4+x)^2+2*exp(sin(2*x))/(4+x)^3;

function z=d4f(x)
z=16*sin(2*x)*exp(sin(2*x))/(4+x)-64*cos(2*x)^2*exp(sin(2*x))/(4+x)+32*cos(2*x)*exp(sin(2*x))/(4+x)^2+48*sin(2*x)^2*exp(sin(2*x))/(4+x)-96*sin(2*x)*cos(2*x)^2*exp(sin(2*x))/(4+x)+96*sin(2*x)*cos(2*x)*exp(sin(2*x))/(4+x)^2-48*sin(2*x)*exp(sin(2*x))/(4+x)^3+16*cos(2*x)^4*exp(sin(2*x))/(4+x)-32*cos(2*x)^3*exp(sin(2*x))/(4+x)^2+48*cos(2*x)^2*exp(sin(2*x))/(4+x)^3-48*cos(2*x)*exp(sin(2*x))/(4+x)^4+24*exp(sin(2*x))/(4+x)^5;
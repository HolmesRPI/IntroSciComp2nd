function fig5_12

%  plots the B-spline function

x0 = -3.0;
x1 = 3.0;
nx=201;
x=linspace(x0,x1,nx);

for ix=1:nx
    exact(ix)=bspline(x(ix));
    exactA(ix)=bspline(x(ix)-1);
    exactB(ix)=bspline(x(ix)+1);
end

clf
% get(gcf)
set(gcf,'Position', [25 1115 658 230])
subaxis(1,1,1,1,'MT',0.01,'MB',0.135,'MR',-0.03,'ML',0.04,'P',0.04)
co = [0 0 1;
    0 0.5 0;
    1 0 0;
    0 0.75 0.75;
    0.75 0 0.75;
    0.75 0.75 0;
    0.25 0.25 0.25];
set(groot,'defaultAxesColorOrder',co)

plot(x,exactB,'--k','LineWidth',1)
hold on
plot(x,exact,'b','LineWidth',1.5)
plot(x,exactA,'--r','LineWidth',1.5)

xlabel(' ')
ylabel('B-Spline')
axis([x0 x1 0 0.71])
grid on
set(gca,'XTickLabel',{' ';' ';' ';' ';' ';' ';' '})
yH=-0.08;
text(-2.13,yH,'$x_{i-2}$','FontSize',22,'Interpreter', 'latex')
text(-1.15,yH,'$x_{i-1}$','FontSize',22,'Interpreter', 'latex')
text(-0.13,yH,'$x_{i}$','FontSize',22,'Interpreter', 'latex')
text(0.87,yH,'$x_{i+1}$','FontSize',22,'Interpreter', 'latex')
text(1.9,yH,'$x_{i+2}$','FontSize',22,'Interpreter', 'latex')

set(gca,'YTick',[0 1/6 2/3])
set(gca,'YTickLabel',{'0';'1/6';'2/3'})
set(gca,'TickLabelInterpreter','latex','FontSize',16)

legend({' B_{i-1}',' B_{i}',' B_{i+1}'},'Location','NorthWest','FontSize',16,'FontWeight','bold')

%exportgraphics(gcf,'/Users/mark/Desktop/bspline.eps')

function y=bspline(x)
% Calculate the value of a cubic B-spline at point x
x=abs(x) ;
if x>2,
    y=0 ;
else
    if x>1,
        y=(2-x)^3/6 ;
    else
        y=2/3-x^2*(1-x/2) ;
    end
end




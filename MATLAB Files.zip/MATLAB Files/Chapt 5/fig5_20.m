function fig5_20

a=0; b=1;
nx=25;

% exact
n=1000;
x=linspace(a,b,n);
for ie=1:n
    ye(ie)=f(x(ie));
end

% cheb
for ix=1:nx
    cc=(2*ix-1)*pi/(2*nx);
    xd(ix)=0.5*(a+b+(b-a)*cos(cc));
    yd(ix)=f(xd(ix));
end
for ii=1:n
    p(ii)=0;
    for k=1:nx
        p(ii)=p(ii)+yd(k)*ell(k,x(ii),xd);
    end
end

% spline
xds=linspace(a,b,nx);
for iy=1:nx
    yds(iy)=f(xds(iy));
end
n=400;
xs=linspace(a,b,n);
ys = splineA(xds,yds,xs);
%ys = nspline(xds,yds,xs);

clf
% get(gcf)
set(gcf,'Position', [25 1115 658 230])
subaxis(1,1,1,1,'MT',0.01,'MB',0.19,'MR',-0.01,'ML',0.03,'P',0.04)
co = [0 0 1;
    0 0.5 0;
    1 0 0;
    0 0.75 0.75;
    0.75 0 0.75;
    0.75 0.75 0;
    0.25 0.25 0.25];
set(groot,'defaultAxesColorOrder',co)

hold on
box on
plot(xs,ys,'r','LineWidth',1.6)
plot(x,p,'b','LineWidth',1.6)
plot(x,ye,'--k','LineWidth',1.8)
set(gca,'YTick',[-1 0 1])
set(gca,'XTick',[0 0.5 1])
axis([0 1 -1.4 1.3])
grid on
xlabel('x-axis')
ylabel('y-axis')
legend({' Spline',' Cheb',' Exact'},'Location','SouthEast','FontSize',16,'FontWeight','bold')
set(gca,'FontSize',16,'FontWeight','bold')
hold off

%exportgraphics(gcf,'/Users/mark/Desktop/tanh.eps')


function g=f(x)
g=tanh(100*(x-0.3));

function p=ell(i,x,xd)
[n1 n2]=size(xd);
p=1;
for j=1:n2
    if j ~= i
        p=p*(x-xd(j))/(xd(i)-xd(j));
    end
end







function fig5_15

%%% it also requires the splineA.m

% spline interpolation

% data
a=0; b=1;
nx=6;
xd=linspace(a,b,nx);
for iy=1:nx
    yd(iy)=cos(2*pi*xd(iy));
end

% exact
n=400;
xp=linspace(a,b,n);
for i=1:n
    y(i)=cos(2*pi*xp(i));
end

% find splines
ys=splineA(xd,yd,xp);
yf=splineA(xd,yd,xp,[1 1],[0 0]);

clf
% get(gcf)
set(gcf,'Position', [30 996 685 349])
co = [0 0 1;
    0 0.5 0;
    1 0 0;
    0 0.75 0.75;
    0.75 0 0.75;
    0.75 0.75 0;
    0.25 0.25 0.25];
set(groot,'defaultAxesColorOrder',co)

%subplot(2,1,1)
subaxis(2,1,1,'MT',0.01,'MB',0.1,'MR',0.001,'ML',0.05,'P',0.03)
hold on
box on
plot(xp,ys,'-b','LineWidth',2)
plot(xp,y,'--r','LineWidth',2)
plot(xd,yd,'or','MarkerSize',9,'LineWidth',2)
axis([a b -1 1])
grid on
ylabel('y-axis')
legend({' Natural',' Exact'},'Location','North','FontSize',14,'FontWeight','bold')
set(gca,'FontSize',14,'FontWeight','bold')


%subplot(2,1,2)
subaxis(2,1,2)
hold on
box on
plot(xp,yf,'-b','LineWidth',2)
plot(xp,y,'--r','LineWidth',2)
plot(xd,yd,'or','MarkerSize',9,'LineWidth',2)
axis([a b -1 1])
grid on
xlabel('x-axis')
ylabel('y-axis')

%  get(legend)
legend({' Clamped',' Exact'},'Location','North','FontSize',14,'FontWeight','bold')
set(gca,'FontSize',14,'FontWeight','bold')

%exportgraphics(gcf,'/Users/mark/Desktop/cs.eps')










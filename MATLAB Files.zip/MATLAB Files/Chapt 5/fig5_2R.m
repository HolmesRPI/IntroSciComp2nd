function fig5_2R

a=-1; b=1;
nx=10;
x=linspace(a,b,nx);

% sum series
p=4/3;
for ix=1:nx
    sum=0;
    for in=1:2000
        sum=sum+(-1)^in*cos(in*pi*x(ix)/b)/(in^p);
    end
    y(ix)=b^2/3+sum*4*b^2/pi^2;
end

clf
% get(gcf)
set(gcf,'Position', [23 925 560 420])
co = [0 0 1;
    0 0.5 0;
    1 0 0;
    0 0.75 0.75;
    0.75 0 0.75;
    0.75 0.75 0;
    0.25 0.25 0.25];
set(groot,'defaultAxesColorOrder',co)

hold on
box on
plot(x,y,'or','MarkerSize',12,'LineWidth',3)
axis([-1.1 1.1 -0.1 2])
grid on
xlabel('x-axis')
ylabel('y-axis')
set(gca,'FontSize',26,'FontWeight','bold')
hold off


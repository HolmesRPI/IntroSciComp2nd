function fig5_17

a=-1; b=1;

% exact
n=2000;
x=linspace(a,b,n);
for ie=1:n
    ye(ie)=1/(1+25*x(ie)^2);
end

% interpolation points
nx=17;
for ix=1:nx
    cc=(2*ix-1)*pi/(2*nx);
    xd(ix)=0.5*(a+b+(b-a)*cos(cc));
    yd(ix)=f(xd(ix));
end

% p_n(x)
for ii=1:n
    p(ii)=0;
    for k=1:nx
        p(ii)=p(ii)+yd(k)*ell(k,x(ii),xd);
    end
end

clf
% get(gcf)
set(gcf,'Position', [25 1115 658 230])
subaxis(1,1,1,1,'MT',0.01,'MB',0.17,'MR',-0.03,'ML',0.01,'P',0.04)
co = [0 0 1;
    0 0.5 0;
    1 0 0;
    0 0.75 0.75;
    0.75 0 0.75;
    0.75 0.75 0;
    0.25 0.25 0.25];
set(groot,'defaultAxesColorOrder',co)

hold on
box on
plot(x,ye,'--r','LineWidth',2)
plot(x,p,'b','LineWidth',1.6)
set(gca,'YTick',[0 1])
axis([-1 1 -0.15 1.05])
for i=1:nx
    plot([xd(i) xd(i)],[-0.05 0],'k','LineWidth',2.1)
end
grid on
xlabel('x-axis')
ylabel('y-axis')
legend({' Runge',' Cheb'},'Location','NorthEast','FontSize',16,'FontWeight','bold')
set(gca,'FontSize',16,'FontWeight','bold')
hold off

%exportgraphics(gcf,'/Users/mark/Desktop/cheb.eps')

function g=f(x)
g=1/(1+25*x^2);

% ell_i(x) function
function p=ell(i,x,xd)
[n1 n2]=size(xd);
p=1;
for j=1:n2
    if j ~= i
        p=p*(x-xd(j))/(xd(i)-xd(j));
    end
end







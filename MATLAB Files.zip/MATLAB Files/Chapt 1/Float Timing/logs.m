function g=logs(n)

% To use this program, enter the command: logs(1000000);
add=1.0713;

TOC=0;
y0=0;
miny=Inf;
for j=1:n
    x1=rand*1e280;
    tic
    y=log(x1);
    y=log(y);
    y=log(y);
    y=log(y);
    y=log(y);
    y=log(x1+y0*y);
    y=log(y);
    y=log(y);
    y=log(y);
    y=log(y);
    y=log(x1+y0*y);
    y=log(y);
    y=log(y);
    y=log(y);
    y=log(y);
    y=log(x1+y0*y);
    y=log(y);
    y=log(y);
    y=log(y);
    y=log(y);
    TOC=TOC+toc;
    if miny>y
        miny=y;
    end
end
logarithm=(1000/20)*TOC/add
miny
g=1;




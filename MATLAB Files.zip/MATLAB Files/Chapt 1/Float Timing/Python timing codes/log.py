#!/usr/bin/env python

import math 
import time
import random

def main():

    add=1.03946e+10
    y0=0 
    TOC=0
    iterations = 1000000
    for i in range(iterations):
      x1=random.random()*1e280 
      tic = time.perf_counter_ns() 
      y=math.log(x1) 
      y=math.log(y) 
      y=math.log(y) 
      y=math.log(y) 
      y=math.log(y) 
      y=math.log(x1+y0*y) 
      y=math.log(y) 
      y=math.log(y) 
      y=math.log(y) 
      y=math.log(y) 
      y=math.log(x1+y0*y) 
      y=math.log(y) 
      y=math.log(y) 
      y=math.log(y) 
      y=math.log(y) 
      y=math.log(x1+y0*y) 
      y=math.log(y) 
      y=math.log(y) 
      y=math.log(y) 
      y=math.log(y) 
      TOC = TOC+time.perf_counter_ns()-tic
    

    toc = time.perf_counter()
    print(f"\n log = {(1000/20)*TOC/add:0.4f} \n")

if __name__ == "__main__":
    main()


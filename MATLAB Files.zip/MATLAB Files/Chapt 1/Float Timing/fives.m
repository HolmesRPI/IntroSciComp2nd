function g=fives(n)

% To use this program, enter the command: fives(1000000);
pi*10+sqrt(7)+exp(2)+3*sin(5)/7+log(11)+pi^5;

add=1.0688;
TOC=0;
maxz=0;
for j=1:n
    x=1+randi(11)*eps;
    tic
    z=x^5;
    z=z^5;
    z=z^5;
    z=z^5;
    z=z^5;
    z=z^5;
    z=z^5;
    z=z^5;
    z=z^5;
    z=z^5;
    z=z^5;
    z=z^5;
    z=z^5;
    z=z^5;
    z=z^5;
    z=z^5;
    z=z^5;
    z=z^5;
    z=z^5;
    z=z^5;
    z=z^5;
    z=z^5;
    z=z^5;
    z=z^5;
    TOC=TOC+toc;
    if maxz<z
        maxz=z;
    end
end
five=(1000/24)*TOC/add
maxz
g=1;




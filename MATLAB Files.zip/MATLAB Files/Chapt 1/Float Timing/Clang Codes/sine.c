//  clang sine.c   ./a.out

#include <stdio.h>
#include <time.h>
#include <stdlib.h>
#include <math.h>

int main() {
    double add, z, rr, TOC;
    int n=1000000;
    int m, i, r;
    
    add=2.508858;
    TOC=0;

    clock_t start;

    for (i = 0; i < n; i++) {
        srand (time(NULL));
        r= rand() % 10 + 1;
        rr= rand();
        m=r-4;
        z=rr*pow(10,m);
        start = clock();
        z=sin(z);
        z=sin(z);
        z=sin(z);
        z=sin(z);
        z=sin(z);
        z=sin(z);
        z=sin(z);
        z=sin(z);
        z=sin(z);
        z=sin(z);
        z=sin(z);
        z=sin(z);
        z=sin(z);
        z=sin(z);
        z=sin(z);
        z=sin(z);
        z=sin(z);
        z=sin(z);
        z=sin(z);
        z=sin(z);
        z=sin(z);
        z=sin(z);
        z=sin(z);
        z=sin(z);
        z=sin(z);
        z=sin(z);
        z=sin(z);
        z=sin(z);
        z=sin(z);
        z=sin(z);
        z=sin(z);
        z=sin(z);
        z=sin(z);
        z=sin(z);
        z=sin(z);
        z=sin(z);
        z=sin(z);
        z=sin(z);
        z=sin(z);
        z=sin(z);
        z=sin(z);
        z=sin(z);
        z=sin(z);
        z=sin(z);
        z=sin(z);
        z=sin(z);
        z=sin(z);
        z=sin(z);
        z=sin(z);
        z=sin(z);
        z=sin(z);
        z=sin(z);
        z=sin(z);
        z=sin(z);
        z=sin(z);
        z=sin(z);
        z=sin(z);
        z=sin(z);
        z=sin(z);
        z=sin(z);
        TOC=TOC+clock()-start;
    }
    printf("\n Sine: %lf \n\n",  (1000/60)*TOC/(add*CLOCKS_PER_SEC));
    return 0;
}















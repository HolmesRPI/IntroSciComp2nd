
//  clang twenties.c   ./a.out

#include <stdio.h>
#include <time.h>
#include <stdlib.h>
#include <math.h>

int main() {
    double add, x, r, z, TOC, T;
    int n=1000000;
    int m=20;
    int i, ir;

    add=2.508858;
    TOC=0;
    clock_t start;
    
    for (i = 0; i < n; i++) {
        srand (time(NULL));
        ir= rand() % 12 + 1;
        r=ir+1.0;
        x=1.0+r*2e-16;
        start = clock();
        z=pow(x,m);
        z=pow(z,m);
        z=pow(z,m);
        z=pow(z,m);
        z=pow(z,m);
        z=pow(z,m);
        z=pow(z,m);
        z=pow(z,m);
        z=pow(z,m);
        z=pow(z,m);
        z=pow(z,m);
        z=pow(z,m);
        TOC=TOC+clock()-start;
        }
    T=(1000/12)*TOC/(add*CLOCKS_PER_SEC);
    printf("\n Twenties: %lf \n\n",  T);
    return 0;
}

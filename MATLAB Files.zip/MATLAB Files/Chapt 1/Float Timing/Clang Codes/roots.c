
//  clang roots.c   ./a.out

#include <stdio.h>
#include <time.h>
#include <stdlib.h>
#include <math.h>

int main() {
    double add, y, rr, TOC;
    int n=1000000;
    int i, ir;
    int ir1, ir2, ir3, ir4, ir5, ir6;
    
    add=2.508858;
    TOC=0;
    clock_t start;
   
    for (i = 0; i < n; i++) {
        srand (time(NULL));
        ir=rand()% 1 + 1;
        ir=2*ir-1;
        rr= rand();
        ir=ir*297;
        y=rr*pow(10,ir);
        start = clock();
        y=sqrt(y);
        y=sqrt(y);
        y=sqrt(y);
        y=sqrt(y);
        y=sqrt(y);
        y=sqrt(y);
        y=sqrt(y);
        y=sqrt(y);
        y=sqrt(y);
        y=sqrt(y);
        y=sqrt(y);
        y=sqrt(y);
        y=sqrt(y);
        y=sqrt(y);
        y=sqrt(y);
        y=sqrt(y);
        y=sqrt(y);
        y=sqrt(y);
        y=sqrt(y);
        y=sqrt(y);
        TOC=TOC+clock()-start;
    }
    printf("\n Sqrt: %lf \n\n",  (1000/20)*TOC/(add*CLOCKS_PER_SEC));

    return 0;
}

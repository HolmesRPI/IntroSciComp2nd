function g=twenties(n)

% To use this program, enter the command: twenties(1000000);

add=1.068;

TOC=0;
maxz=0;
for j=1:n
    x=1+randi(11)*eps;
    tic
    z=x^20;
    z=z^20;
    z=z^20;
    z=z^20;
    z=z^20;
    z=z^20;
    z=z^20;
    z=z^20;
    z=z^20;
    z=z^20;
    z=z^20;
    z=z^20;
    TOC=TOC+toc;
    if maxz<z
        maxz=z;
    end
end
twenty=(1000/12)*TOC/add
z
maxz
g=1;




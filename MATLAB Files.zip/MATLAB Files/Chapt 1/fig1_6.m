function fig1_6

% calculate the exponents for n
nn=1011;
ex=linspace(4,8,nn);

B=bernoulli(0);
gamma=-psi(1)
for ic=1:nn
    n(ic)=round(10^ex(ic));

    %%% use Euler–Maclaurin
    asy=gamma+log(n(ic))+0.5/n(ic);
    for ik=2:2:10
        asy=asy-B(ik)/(ik*n(ic)^ik);
    end

    % sum series from small to large
    y=0;
    for j=n(ic):-1:1
        y=y+1/j;
    end
    s(ic)=abs(y-asy);

    % sum series from large to small
    yy=0;
    for jj=1:n(ic)
        yy=yy+1/jj;
    end
    S(ic)=abs(yy-asy);
end

clf
% get(gcf)
set(gcf,'Position', [25 1115 658 230])
subaxis(1,1,1,1,'MT',0.01,'MB',0.18,'MR',-0.015,'ML',0.06,'P',0.04)
co = [0 0 1;
    0 0.5 0;
    1 0 0;
    0 0.75 0.75;
    0.75 0 0.75;
    0.75 0.75 0;
    0.25 0.25 0.25];
set(groot,'defaultAxesColorOrder',co)

loglog(n,S,'-r','MarkerSize',2,'LineWidth',1.1)
hold on
loglog(n,s,'-b','MarkerSize',2,'LineWidth',1)
axis([1e4 1e8 1e-15 1e-11])
set(gca,'ytick',[1e-15 1e-14 1e-13 1e-12 1e-11])
xlabel('Number of Terms')
ylabel('Error')
grid on
box on
legend({' S',' s'},'Location','NorthWest','FontSize',16,'FontWeight','bold')
set(gca,'FontSize',16,'FontWeight','bold')
hold off

%exportgraphics(gcf,'/Users/mark/Desktop/sums.eps')


function B=bernoulli(x)
B=zeros(20,1);
%B(0) = 1/1;
B(1) = -1/2;
B(2) = 1/6;
B(4) = -1/30;
B(6) = 1/42;
B(8) = -1/30;
B(10) = 5/66;
B(12) = -691/2730;
B(14) = 7/6;
B(16) = -3617/510;
B(18) = 43867/798;
B(20) = -174611/330;
B(22) = 854513/138;
B(24) = -236364091/2730;
B(26) = 8553103/6;
B(28) = -23749461029/870;
B(30) = 8615841276005/14322;
B(32) = -7709321041217/510;
B(34) = 2577687858367/6;
B(36) = -26315271553053477373/1919190;
B(38) = 2929993913841559/6;
B(40) = -261082718496449122051/13530;
% B(42) = 1520097643918070802691/1806;
% B(44) = -27833269579301024235023/690;
% B(46) = 596451111593912163277961/282;
% B(48) = -5609403368997817686249127547/46410;
% B(50) = 495057205241079648212477525/66;
% B(52) = -801165718135489957347924991853/1590;
% B(54) = 29149963634884862421418123812691/798;
% B(56) = -2479392929313226753685415739663229/870;
% B(58) = 84483613348880041862046775994036021/354;
% B(60) = -1215233140483755572040304994079820246041491/56786730;



















function fig1_3

%%% this requires the subaxis.m and parseArgs.m files

x0=pi/4;
dx=2*pi;

%  loop to generate function values
nx=1200;
ex=linspace(0,16,nx);
for i=1:nx
    n(i)=round(10^ex(i));
    x(i)=x0+n(i)*dx;
    y(i)=abs(1-sin(x(i))/sin(x0));
end

clf
% get(gcf)
set(gcf,'Position', [25 1115 658 230])
subaxis(1,1,1,1,'MT',0.01,'MB',0.18,'MR',-0.015,'ML',0.06,'P',0.04)
co = [0 0 1;
    0 0.5 0;
    1 0 0;
    0 0.75 0.75;
    0.75 0 0.75;
    0.75 0.75 0;
    0.25 0.25 0.25];
set(groot,'defaultAxesColorOrder',co)

loglog(n,y,'-r','LineWidth',0.9)
hold on
grid on
box on
axis([1 1e15 1e-16 1])
set(gca,'ytick',[1e-16 1e-12 1e-8 1e-4 1])
set(gca,'xtick',[1 1e5 1e10 1e15])
xlabel('n-axis')
ylabel('Relative Error')
set(gca,'FontSize',16,'FontWeight','bold')

%exportgraphics(gcf,'/Users/mark/Desktop/sink.eps')


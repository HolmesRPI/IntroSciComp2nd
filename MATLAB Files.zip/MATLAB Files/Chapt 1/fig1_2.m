function fig1_2

%%% this requires the subaxis.m and parseArgs.m files

% compute the values of the ratio
n=10000;
exs=linspace(-18,-2,n);
j=1;
for i=1:n
    k(i)=10^exs(i);
    y(i)=(sqrt(16+k(i))-4)/k(i);
    % determine when y=0
    if y(i)==0
        j=i;
    end
end

% k value where y=0 starts
k(j)

clf
% get(gcf)
set(gcf,'Position', [25 1115 658 230])
subaxis(1,1,1,1,'MT',0.01,'MB',0.18,'MR',-0.015,'ML',0.06,'P',0.04)
co = [0 0 1;
    0 0.5 0;
    1 0 0;
    0 0.75 0.75;
    0.75 0 0.75;
    0.75 0.75 0;
    0.25 0.25 0.25];
set(groot,'defaultAxesColorOrder',co)

% plot the results
semilogx(k,y,'b-','LineWidth',1.2)
hold on
axis([1e-18 1e-2 -0.02 0.1875])
set(gca,'ytick',[0 0.0625 0.1250 0.1875])
set(gca,'yTickLabel',{'0 ';'1/16 ';'1/8 ';'3/16 '})
set(gca,'xtick',[1e-18 1e-14 1e-10 1e-6 1e-2])
grid on
xlabel('k-axis')
ylabel('y-axis')
set(gca,'FontSize',16,'FontWeight','bold')
hold off

%exportgraphics(gcf,'/Users/mark/Desktop/sqrt3.eps')











function nde

% solve, and then plot, the solution of the nonlinear diffusion equation
%        u_t = Du_xx + f(x,t,u,u_x)  for xL < x < xR, 0 < t < T
% where
% BCs:  a0*u(xL,t) + b0*u_x(xL,t) = c0
%       a1*u(xR,t) + b1*u_x(xR,t) = c1
% IC:   u(x,0) = g(x)

% what's computed: u(ix,it), for ix=1..nx, it=1..nt
% more information about the code is given at the end of this file

% set boundary conditions
xL=0; a0=1; b0=0; c0=0;
xR=1; a1=1; b1=0; c1=0;

% parameters for calculation
D = 0.001;
nx = 100;
T = 6;
nt = 100;
error = 1e-8;

% the code follows
x=linspace(xL,xR,nx);
t=linspace(0,T,nt);
dx=x(2)-x(1);
dxx = dx*dx;
dt=t(2)-t(1);
kD=2/(dt*D);

u=zeros(nx,nt);
for ix=1:nx
    u(ix,1)=g(x(ix));
end

for it=2:nt
    if b0~=0
        zz=(c0-a0*u(1,it-1))/b0;
        vv=2*(u(2,it-1)-u(1,it-1)-dx*zz)/dxx;
        G(1)=-u(1,it-1)-vv/kD-0.5*dt*f(x(1),t(it-1),u(1,it-1),zz);
    end
    for j = 2:nx-1
        zz = (u(j+1,it-1) - u(j-1,it-1))/(2*dx);
        vv=(u(j+1,it-1)-2*u(j,it-1)+u(j-1,it-1))/dxx;
        G(j) = -u(j,it-1)-vv/kD- 0.5*dt*f(x(j),t(it-1),u(j,it-1),zz);
    end
    if b1~=0
        zz=(c1-a1*u(nx,it-1))/b1;
        vv=2*(u(nx-1,it-1)-u(nx,it-1)+dx*zz)/dxx;
        G(nx)=-u(nx,it-1)-vv/kD- 0.5*dt*f(x(nx),t(it-1),u(nx,it-1),zz);
    end
    % Newton iteration
    counter=0;
    err=1;
    y=u(:,it-1);
    while err > error
        % calculate Jacobian
        a=zeros(1,nx); b=zeros(1,nx); c=zeros(1,nx); v=zeros(1,nx);
        if b0==0
            a(1)=1;
            v(1)=y(1)-c0/a0;
        else
            zz=(c0-a0*y(1))/b0;
            fy=kD*(1-0.5*dt*fu(x(1),t(it),y(1),zz));
            f3=-fz(x(1),t(it),y(1),zz)/D;
            a(1)=2*(-1+dx*a0/b0)-dxx*fu+dxx*(a0/b0)*f3;
            c(1)=2;
            vv=y(1)-0.5*dt*f(x(1),t(it),y(1),zz)+G(1);
            v(1)=2*y(2)+2*(-1+dx*a0/b0)*y(1)-2*dx*c0/b0-dxx*kD*vv;
        end
        for j = 2:nx-1
            zz = (y(j+1) - y(j-1))/(2*dx);
            fy=kD*(1-0.5*dt*fu(x(j),t(it),y(j),zz));
            f3=-fz(x(j),t(it),y(j),zz)/D;
            a(j) = -2 - dxx*fy;
            c(j) = 1 - 0.5*dx*f3;
            b(j) = 1 + 0.5*dx*f3;
            vv=y(j)-0.5*dt*f(x(j),t(it),y(j),zz)+G(j);
            v(j) = - 2*y(j) + y(j+1) + y(j-1) - dxx*kD*vv;
        end
        if b1==0
            a(nx)=1;
            v(nx)=y(nx)-c1/a1;
        else
            zz=(c1-a1*y(nx))/b1;
            fy=kD*(1-0.5*dt*fu(x(nx),t(it),y(nx),zz));
            f3=-fz(x(nx),t(it),y(nx),zz)/D;
            a(nx)=-2*(1+dx*a1/b1)-dxx*fy+dxx*(a1/b1)*f3;
            b(nx)=2;
            vv=y(nx)-0.5*dt*f(x(nx),t(it),y(nx),zz)+G(nx);
            v(nx)=2*y(nx-1)-2*(1+dx*a1/b1)*y(nx)+2*dx*c1/b1-dxx*kD*vv;
        end
        % solve Jz=-F
        z = tridiag( a, b, c, -v );
        err = norm(z,inf);
        y=y+z;
        %counter=counter+1;
    end
    u(:,it)=y;
    %newton_iterations=counter
end

% surface plot
figure(1)
clf
set(gcf,'Position', [25 1115 658 230])
surf(x,t,u')
box on
xlabel('x-axis')
ylabel('t-axis')
zlabel('Solution')
set(gca,'FontSize',14,'FontWeight','bold')
hold off

% curve plots
figure(2)
clf
set(gcf,'Position', [22 811 658 230])
t1=1; t2=round(nt/4); t3=nt;
plot(x,u(:,t1),'k','LineWidth',1.5)
hold on
box on
plot(x,u(:,t2),'r','LineWidth',1.5)
plot(x,u(:,t3),'b','LineWidth',1.5)
xlabel('x-axis')
ylabel('u-axis')
legend(' t = 0',strcat(' t = ',num2str(t(t2),2)),strcat(' t = ',num2str(t(t3),2)),'Location','eastoutside')
set(gca,'FontSize',14,'FontWeight','bold')
hold off

function y = tridiag( a, b, c, f )
n = length(f);
v = zeros(n,1);
y = v;
w = a(1);
y(1) = f(1)/w;
for i=2:n
    v(i-1) = c(i-1)/w;
    w = a(i) - b(i)*v(i-1);
    y(i) = ( f(i) - b(i)*y(i-1) )/w;
end
for j=n-1:-1:1
    y(j) = y(j) - v(j)*y(j+1);
end


% function in PDE
function p=f(x,t,u,z)
p = u*(1-u);

% fu = diff(f,u)
function p=fu(x,t,u,z)
p = 1-2*u;

% fz = diff(f,z)
function p=fz(x,t,u,z)
p = 0;

% initial condition (IC)
function p=g(x)
p=sin(4*pi*x)^4;


%  This code is run by simply entering the command  nde  in MATLAB (making
%  sure that this file is in the path for MATLAB).  The user needs to first
%  enter certain information about the problem into this file before running it.

%  Needed Input From User

%  Boundary conditions (BCs): xL, a0, b0, c0, xR, a1, b1, c1 (see lines 14-15)
%  Value for diffusion coefficient:  D (line 18)
%  Time interval to be used:  T (line 20)
%  Number of grid points:  nx and nt (lines 19 and 21)
%  Error used to stop Newton's method:  error (line 22)
%  f(x,t,u,z):   note that z acts as the place holder for u_x (line 150)
%  fu(x,t,u,z):  this is the derivative of f with respect to u (line 154)
%  fz(x,t,u,z):  this is the derivative of f with respect to z (line 158)
%  g(x):  this is the initial condition (line 162)

%  Example (Fischer's equation):   u_t = D*u_xx + u*(1-u)
%  with u(0,t) = 0, u(1,t) = 0, and u(x,0) = sin(4*pi*x)^4
%    D = 0.001; nx = 100; T=5; nt=100;
%    xL = 0; a0 = 1; b0 = 0; c0 = 0;
%    xR = 1; a1 = 1; b1 = 0; c1 = 0;
%    f(x,t,u,z) = u*(1-u)
%    fu(x,t,u,z) = 1-2*u
%    fz(x,t,u,z) = 0
%    g = sin(4*pi*x)^4

%  Plotting commands: These are lines 104-130, and they illustrate various
%  ways to use the computed solution.

%  Warning: Nonlinear diffusion problems can easily be unstable, and so
%  some care is needed in picking f and the associated BCs and IC. Also,
%  small values of D can lead to boundary layers (large values of nx will
%  be needed in such cases). Finally, make sure that:
%       i) a0 and b0 are not both zero (and the same goes for a1 and b1)
%       ii) D is positive

%  Background
%  The algorithm uses the Crank-Nicolson method with a uniform grid. With
%  this, Newton's method is used to solve the resulting nonlinear system.
%  Overall it is relatively fast.  For example, for the Fischer's equation
%  example, it solves the problem in about 0.004 sec on an iMac (and it
%  takes about 0.25 sec when nx=nt=1000).

%  It has been tested on MATLAB, version R2018a(beta)
%  release date: December 21, 2017
%  Version 1.05: fixed some minor typos (the PDE solver was unchanged)
















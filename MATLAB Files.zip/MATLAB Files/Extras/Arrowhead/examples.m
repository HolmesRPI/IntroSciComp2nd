	 clf
     axis([-3 3 0 4])
	 arrowhead([-1 0],[1 1]);
	 arrowhead([1 2],[1 2],'r');
	 arrowhead([-1 0],[3.5 3],'k',[1 2],2);
	 arrowhead([2.5 2],[3.5 3],[],[],4);

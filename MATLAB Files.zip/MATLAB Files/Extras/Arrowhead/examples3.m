function examples3

clf
[t,y] = ode45(@(t,y) [y(2); (1-y(1)^2)*y(2)-y(1)],[0 1],[0; 1]);
%hold on
plot(y(:,1),y(:,2))
i=20; ii=i+2; arrowhead([y(i,1) y(ii,1)],[y(i,2) y(ii,2)]);
i=50; ii=i+2; arrowhead([y(i,1) y(ii,1)],[y(i,2) y(ii,2)],'m',[],3);
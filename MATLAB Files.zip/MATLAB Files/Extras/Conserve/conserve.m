function [yp,vp] = conserve(F,P,t,init)

%  Using an energy conserving method, this code solves:
%     y"=F(y), with y(0)=y0, y'(0)=v0, for 0<t<tmax

% Usage (example at end of file)
%     [y,v]=conserve(@(y)F(y),@(y)P(y),t,init)

% Output: y = solution vector at given t values
%         v = velocity vector y'(t) at given t values

% Required arguments
%   F(y): forcing function (see example at the end of file)
%   P(y): potential function where P'(y)=-F(y) with P(0)=0
%   t: time points to be used 
%   init = [y0, v0]: initial conditions


%%% the code begins
n=length(t);
yp=init(1);
vp=init(2);
y=init(1);
v=init(2);
Py=P(y);
tol=10^(-12);
for i=2:n
    k=t(i)-t(i-1);
    Yq=y+k*v+0.5*k^2*F(y);
    dV=0.5*k*F(y)+0.5*k*F(Yq);
    V=v+0.3*dV;
    Y=y+0.5*k*(V+v);
    err=1; icount=0;
    while err>tol
        icount=icount+1;
        dy=0.5*k*(V+v);
        PY=P(y+dy);
        f=V-v+2*(PY-Py)/(V+v);
        df=(2*V-f-k*F(y+dy))/(V+v);
        diff=f/df;
        V=V-diff;
        Y=y+0.5*k*(V+v);
        err=abs(diff);
        if icount>20
            error('Newton is not converging; try using smaller time steps')
        end
    end
    dy=0.5*k*(V+v);
    PY=P(y+dy);
    f=V-v+2*(PY-Py)/(V+v);
    df=(2*V-f-k*F(y+dy))/(V+v);
    diff=f/df;
    V=V-diff;
    y=y+0.5*k*(V+v);
    v=V;
    Py=P(y);
    yp=[yp, y];
    vp=[vp, v];
end

% Pendulum Example: F(y) = -sin(y) => P(y) = -cos(y)+1
%  
% init = [2.75 0]; t = linspace(0,1e4,14000);
% [y2,v2] = conserve(@(y)-sin(y),@(y)-cos(y)+1,t,init);

% Comments: the energy, or Hamiltonian, H(y,v)=0.5v^2+P(y) is constant
% for y"=F(y), and this numerical method preserves this (up to round-off).
% The method is derived in "Conservative numerical methods for nonlinear 
% oscillators" by M. H. Holmes, American Journal of Physics 88, 60 (2020)
% https://doi.org/10.1119/10.0000295

% Possible way the code can fail: the method is implicit, and the equation
% being solved is eq (19) in the paper referenced above.  So, Newton's
% method is used at each time step. This requires a starting guess, and the
% one that is used is on line 31. If the code isn't working you might need
% to improve the guess (or, decrease the time step).  Also, you can modify 
% the stopping error for Newton, which is specified on line 26.

%  Versions:
%  version 1.0: August 16, 2021






















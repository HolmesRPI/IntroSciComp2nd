
Arrowhead
This program was written to place arrowheads in a plot

Cgm
Solves Ax=b using the conjugate gradient method.

Conserve
Using an energy conserving method, this code solves: y"=F(y), with y(0)=y0, y'(0)=v0, for 0<t<tmax.

Fits
Parameter Fitting: given a model function f(x,p), this program finds the minimizer of F(p) = norm(d,n)

Int
This program computes the integral of f(x) from x=a to x=b using an adaptive Simpson's rule

Lbvp
This code solves and then plots the solution of the linear BVP y'' + p(x)y' + q(x)y = f(x)

Nbvp
This code solves and then plots the solution of the nonlinear BVP y'' = f(x, y, y')

Nde
Solve, and then plot, the solution of the nonlinear diffusion equation u_t = Du_xx + f(x,t,u,u_x)

Sbvp
Solve and then plot the solution of the singularly perturbed nonlinear BVP  ep*y'' = f(x, y, y', ep)

Solve
Find a solution of f(x)=0

Spline
Nonuniform cubic spline interpolation 

Tridiag
Implementation of the Thomas algorithm for solving a tridiagonal matrix equation














function examples2

% function file examples 
% this uses the same equations as in examples.m
% reports function evaluations

global count

%%% f=x^5-x^4-16 => x=2
fprintf('\n [\b Example 1 ]\b \n\n')
a=-5; b=5; exact=2;
count=0;
tic; v=solve(@f1,a,b); toc
solve_count=count
count=0;
tic; matv=fzero(@f1,a); toc
fzero_count=count
count=0;
pause

%%% f=exp(-3x)+5exp(-2x)-28 => x=-ln(2)
fprintf('\n [\b Example 2 ]\b \n\n')
a=-5; b=5; exact=-log(2);
count=0;
tic; v=solve(@f2,a,b); toc
solve_count=count
count=0;
tic; matv=fzero(@f2,a); toc
fzero_count=count
count=0;
pause

%%% f=tanh((x-1)*10)*(1+0.99*cos(20*pi*x)) => x=1
fprintf('\n [\b Example 3 ]\b \n\n')
a=-5; b=5; exact=1;
count=0;
tic; v=solve(@f3,a,b); toc
solve_count=count
count=0;
tic; matv=fzero(@f3,a); toc
fzero_count=count
count=0;
pause

%%% f=exp(x^4-5x-6)-1 => x=-1,2
fprintf('\n [\b Example 4 ]\b \n\n')
a=0; b=10; exact=2; exactt=-1;
count=0;
tic; v=solve(@f4,a,b); toc
solve_count=count
count=0;
tic; matv=fzero(@f4,a); toc
fzero_count=count
count=0;
pause

%%%%% example requiring curvature reduction
%%% f=x^3+1e-8 => x=-10^(-8/3)
fprintf('\n [\b Example 5 ]\b \n\n')
count=0;
tic; v=solve(@f5,-0.1,pi); toc
solve_count=count
count=0;
tic; matv=fzero(@f5,-0.1); toc
fzero_count=count
count=0;
pause

%%%%% example with many solutions
%%% f=sin(40x+0.1)
fprintf('\n [\b Example 6 ]\b \n\n')
a=0; b=5;
count=0;
tic; v=solve(@f6,a,b); toc
solve_count=count
count=0;
tic; matv=fzero(@f6,a); toc
fzero_count=count
count=0;
pause

%%%%% examples when fzero fails but solve works
%%% f=sqrt(x)-4 => x=16
fprintf('\n [\b Example 7 ]\b \n\n')
a=1; b=20;
count=0;
tic; v=solve(@f7,a,b); toc
solve_count=count
count=0;
tic; matv=fzero(@f7,a); toc
fzero_count=count
count=0;
pause

%%% f=x+ep*sech((x-1)/ep) => x=-2*ep*exp(-1/ep)-4*ep^4*exp(-2/ep)+...
fprintf('\n [\b Example 8 ]\b \n\n')
a=-1; b=1;  ep=0.01; exact=-7.4401519520416719259e-46;
count=0;
tic; v=solve(@f8,a,b); toc
solve_count=count
count=0;
tic; matv=fzero(@f8,a); toc
fzero_count=count

%%% f=(x^2-alpha^2)*exp(-3*x^2) => x=+/-alpha
fprintf('\n [\b Example 9 ]\b \n\n')
a=-1; b=5;
count=0;
tic; v=solve(@f9,a,b); toc
solve_count=count
count=0;
tic; matv=fzero(@f9,a); toc
fzero_count=count


%%% no solution
% fprintf('\n Example 10 \n\n')
% a=-1; b=1;
% count=0;
% tic; v=solve(@f10,a,b); toc
% solve_count=count
% count=0;
% tic; matv=fzero(@f10,a); toc
% fzero_count=count


%%%%%%%%%% The functions

function y=f1(x)
global count
y=x^5-x^4-16;
count=count+1;

function y=f2(x)
global count
y=exp(-3*x)+5*exp(-2*x)-28;
count=count+1;

function y=f3(x)
global count
y=tanh((x-1)*10)*(1+0.99*cos(20*pi*x));
count=count+1;

function y=f4(x)
global count
y=exp(x^4-5*x-6)-1;
count=count+1;

function y=f5(x)
global count
y=x^3+1e-8;
count=count+1;

function y=f6(x)
global count
y=sin(40*x+0.1);
count=count+1;

function y=f7(x)
global count
y=sqrt(x)-4;
count=count+1;

function y=f8(x)
global count
y=x+0.01*sech((x-1)/0.01);
count=count+1;

function y=f9(x)
global count
alpha=0.0001;
y=(x^2-alpha^2)*exp(-3*x^2);
count=count+1;

function y=f10(x)
global count
y=x^8+1;
count=count+1;





















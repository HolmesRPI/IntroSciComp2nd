function examples

% this file was used for testing and to compare with fzero
% uses anonymous function (function file version yields similar results)
% it reports error and computing time (rather than solution)

%%% f=x^5-x^4-16 => x=2
fprintf('\n [\b Example 1 ]\b \n\n')
a=-5; b=5; exact=2;
tic; v=solve(@(x)x^5-x^4-16,a,b); toc
solve_error=(exact-v)/exact
tic; matv=fzero(@(x)x.^5-x.^4-16,a); toc
fzero_error=(exact-matv)/exact
pause

%%% f=exp(-3x)+5exp(-2x)-28 => x=-ln(2)
fprintf('\n [\b Example 2 ]\b \n\n')
a=-5; b=5; exact=-log(2);
tic; v=solve(@(x)exp(-3*x)+5*exp(-2*x)-28,a,b); toc
solve_error=(exact-v)/exact
tic; matv=fzero(@(x)exp(-3*x)+5*exp(-2*x)-28,a); toc
fzero_error=(exact-matv)/exact
pause

%%% f=tanh((x-1)*10)*(1+0.99*cos(20*pi*x)) => x=1
fprintf('\n [\b Example 3 ]\b \n\n')
a=-5; b=5; exact=1;
tic; v=solve(@(x)tanh((x-1)*10)*(1+0.99*cos(20*pi*x)),a,b); toc
solve_error=(exact-v)/exact
tic; matv=fzero(@(x)tanh((x-1)*10)*(1+0.99*cos(20*pi*x)),a); toc
fzero_error=(exact-matv)/exact
pause

%%% f=exp(x^4-5x-6)-1 => x=-1,2
fprintf('\n [\b Example 4 ]\b \n\n')
a=0; b=10; exact1=2; exact2=-1;
tic; v=solve(@(x)exp(x^4-5*x-6)-1,a,b);
toc
solve_error1=(exact1-v)/exact1
tic; matv=fzero(@(x)exp(x.^4-5*x-6)-1,a); toc
fzero_error1=(exact1-matv)/exact1
fzero_error2=(exact2-matv)/exact2
pause

%%%%% example requiring curvature reduction
%%% f=x^3+1e-8 => x=-10^(-8/3)
fprintf('\n [\b Example 5 ]\b \n\n')
exact=-10^(-8/3);
tic; v=solve(@(x)x^3+1e-8,-0.1,pi);
toc
solve_error=(exact-v)/exact
tic; matv=fzero(@(x)x.^3+1e-8,-0.1); toc
fzero_error=(exact-matv)/exact
pause

%%%%% example with many solutions
%%% f=sin(40x+0.1)
fprintf('\n [\b Example 6 ]\b \n\n')
a=0; b=5;
tic; v=solve(@(x)sin(40*x+0.1),a,b);
toc
solve_residual=sin(40*v+0.1)
tic; matv=fzero(@(x)sin(40*x+0.1),a);
toc
fzero_residual=sin(40*matv+0.1)


%%%%% examples when fzero fails but solve works

%%% f=sqrt(x)-4 => x=16
fprintf('\n [\b Example 7 ]\b \n\n')
a=1; b=20; exact=16;
tic; v=solve(@(x)sqrt(x)-4,a,b); toc
solve_error=(exact-v)/exact
tic; matv=fzero(@(x)sqrt(x)-4,a); toc
fzero_error=(exact-matv)/exact
pause

%%% f=x+ep*sech((x-1)/ep) => x=-2*ep*exp(-1/ep)-4*ep^4*exp(-2/ep)+...
fprintf('\n [\b Example 8 ]\b \n\n')
a=-1; b=1; ep=0.01; exact=-7.4401519520416719259e-46;
tic; v=solve(@(x)x+0.01*sech((x-1)/0.01),a,b); toc
solve_error=(exact-v)/exact
tic; matv=fzero(@(x)x+0.01*sech((x-1)/0.01),a); toc
fzero_error=(exact-matv)/exact

%%% f=(x^2-alpha^2)*exp(-3*x^2) => x=+/-alpha
fprintf('\n [\b Example 9 ]\b \n\n')
a=-1; b=6;
alpha=0.0001;
exact1=alpha; exact2=-alpha;
tic; v=solve(@(x)(x^2-alpha^2)*exp(-3*x^2),a,b); toc
solve_error1=(exact1-v)/exact1
solve_error2=(exact2-v)/exact2
tic; matv=fzero(@(x)(x.^2-alpha^2)*exp(-3*x.^2),a); toc
fzero_error1=(exact1-matv)/exact1
fzero_error2=(exact2-matv)/exact2




























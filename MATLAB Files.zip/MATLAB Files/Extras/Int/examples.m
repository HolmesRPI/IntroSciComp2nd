function examples

%%% int(f)=sin(x) => f=cos(x)
a=-7; b=8; exact=sin(b)-sin(a);
tic; v=int(@(x)cos(x),a,b); toc
error=(exact-v)/exact
tic; matv=integral(@(x)cos(x),a,b); toc
error2=(exact-matv)/exact
pause

%%% int(f)=x^9-3*x+2 => f=9*x^8-3
a=1; b=17; exact=(b^9-3*b+2)-(a^9-3*a+2);
tic; v=int(@(x)9*x^8-3,a,b); toc
error=(exact-v)/exact
tic; matv=integral(@(x)9*x.^8-3,a,b); toc
error2=(exact-matv)/exact
pause

%%% int(f)=exp(x^2) => f=2*x*exp(x^2)
a=1; b=17; exact=(exp(b^2))-(exp(a^2));
tic; v=int(@(x)2*x*exp(x^2),a,b); toc
error=(exact-v)/exact
tic; matv=integral(@(x)2*x.*exp(x.^2),a,b); toc
error2=(exact-matv)/exact
pause

%%%  f=(3*x^2-7)*cos(x^3-7*x)  int(f)=sin(x^3-7*x)
a=-7; b=8; exact=sin(b^3-7*b) - sin(a^3-7*a);
tic; v=int(@(x)(3*x^2-7)*cos(x^3-7*x),a,b); toc
error=(exact-v)/exact
tic; matv=integral(@(x)(3*x.^2-7).*cos(x.^3-7*x),a,b); toc
error2=(exact-matv)/exact
pause

%%%  f=-60*x^2*sin(x^3)*cos(x^3)^19  int(f)=cos(x^3)^20
a=0; b=9.1; exact=cos(b^3)^20-cos(a^3)^20;
tic; v=int(@(x)-60*x^2*sin(x^3)*cos(x^3)^19,0,9.1); toc
error=(exact-v)/exact
tic; matv=integral(@(x)-60*x.^2.*sin(x.^3).*cos(x.^3).^19,a,b); toc
error2=(exact-matv)/exact

% nc=500;
% error=zeros(nc,1);
% for ic=1:nc
% %%% int(f)=sin(x) => f=cos(x)
% a=-7; b=8; exact=sin(b)-sin(a);
% v=int2(@(x)cos(x),a,b); 
% error(ic)=(exact-v)/exact;
% end
% qq=sortrows(abs(error));
% qq(1:5)
% qq(end-5:end)


% nc=500;
% error=zeros(nc,1);
% for ic=1:nc
% %%% int(f)=sin(x) => f=cos(x)
% a=0; b=9.1; exact=cos(b^3)^20-cos(a^3)^20;
% v=int2(@(x)-60*x^2*sin(x^3)*cos(x^3)^19,0,9.1); 
% error(ic)=(exact-v)/exact;
% end
% qq=sortrows(abs(error));
% qq(1:5)
% qq(end-5:end)
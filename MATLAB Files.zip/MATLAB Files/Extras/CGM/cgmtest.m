function cgmtestS

% various examples used to test algorithm

%%% Example 1: laplace eq matrix
% N=40;
% M=N;
% n=N*M;
% lambda2=1;
% D=2*(1+lambda2)*eye(n,n);
% SD1=diag(-lambda2*ones(n-1,1),-1);
% for i=N+1:N:n-1
%     SD1(i,i-1)=0;
% end
% SDM=diag(-ones(n-M,1),-M);
% A=D+SD1+SD1'+SDM+SDM';

%%% Example 2: arrowhead matrix
% n=10000;                   
% A=diag(2*ones(n,1));
% A(2:n,1)=1; A(1,2:n)=1; A(1,1)=n+1;

%%% Example 3: random (full) matrix
% n=10000;
% A1=rand(n,n);           
% A=A1'+A1+diag(2*n*ones(n,1));

% %%% Example 4: random sparse matrix
% n=5000;
% A1=zeros(n,n);
% for i=1:n
%     A1(i,i)=2+randi(8);
%     A1(randi(n),randi(n))=1;
% end
% A=A1'*A1;
% 
% 
% xe=2*(1-0.5*rand(n,1));     
% b=A*xe;
% 
% tic
% x=cgm(A,b);
% cgm_time=toc
% error=norm(x-xe,inf)/norm(xe,inf)  
% 
% AA=sparse(A);
% tic
% x=cgm(AA,b);
% cgmS_time=toc
% 
% tic
% xx=A\b;                   
% LU_time=toc
% error=norm(x-xx,inf)/norm(xx,inf)



% n=1000;
% A1=rand(n,n);             %% generate A
% A=A1'+A1+diag(2*n*ones(n,1));
% xe=2*(1-0.5*rand(n,1));     %% pick solution
% b=A*xe;
% x=cgm(A,b);
% error=norm(x-xe,inf)/norm(xe,inf)  %% check accuracy


n=5000;                   %% generate A
A=diag(2*ones(n,1));
A(2:n,1)=1; A(1,2:n)=1; A(1,1)=n+1;
xe=2*(1-0.5*rand(n,1));     %% pick solution
b=A*xe;
x=cgm(A,b);
error=norm(x-xe,inf)/norm(xe,inf)  %% check accuracy














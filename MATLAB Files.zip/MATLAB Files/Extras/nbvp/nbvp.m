function nbvp

% code to solve, and then plot, the solution of the 2nd order nonlinear BVP
%        y'' = f(x, y, y')     for xL < x < xR
% where
%   a0*y(xL) + b0*y'(xL) = c0   and  a1*y(xR) + b1*y'(xR) = c1

% it is required that a0 and b0 are not both zero (and same for a1 and b1)
% an explanation of how to use this code is given at the end of this file

% set boundary conditions
xL=0; a0=1; b0=0; c0=0;
xR=1; a1=1/tanh(1); b1=-1/(sech(1))^2; c1=-1;

% parameters for calculation
nx = 100;
error = 1e-8;

% try to start with a linear function that satisfies the BCs
x=linspace(xL,xR,nx);
A=[[a0*xL+b0 a0];[a1*xR+b1 a1]];
if cond(A)<1e12
    s=A\[c0; c1];
    y=s(2) + s(1)*x';
else
    y=zeros(nx,1);
end

% the code begins
dx=x(2)-x(1);
dxx = dx*dx;
err=1;

% Newton iteration
counter=0;
while err > error
    % calculate Jacobian
    a=zeros(1,nx); b=zeros(1,nx); c=zeros(1,nx); v=zeros(1,nx);
    if b0==0
        a(1)=1;
        v(1)=y(1)-c0/a0;
    else
        zz=c0/b0-a0*y(1)/b0;
        a(1)=2*(-1+dx*a0/b0)-dxx*fy(x(1),y(1),zz)+dxx*(a0/b0)*fz(x(1),y(1),zz);
        c(1)=2;
        v(1)=2*y(2)+2*(-1+dx*a0/b0)*y(1)-2*dx*c0/b0-dxx*f(x(1),y(1),zz);
    end
    for j = 2:nx-1
        zz = (y(j+1) - y(j-1))/(2*dx);
        a(j) = -2 - dxx*fy(x(j), y(j), zz);
        c(j) = 1 - 0.5*dx*fz(x(j), y(j), zz);
        b(j) = 1 + 0.5*dx*fz(x(j), y(j), zz);
        v(j) = - 2*y(j) + y(j+1) + y(j-1) - dxx*f(x(j), y(j), zz);
    end
    if b1==0
        a(nx)=1;
        v(nx)=y(nx)-c1/a1;
    else
        zz=c1/b1-a1*y(nx)/b1;
        a(nx)=-2*(1+dx*a1/b1)-dxx*fy(x(nx),y(nx),zz)+dxx*(a1/b1)*fz(x(nx),y(nx),zz);
        b(nx)=2;
        v(nx)=2*y(nx-1)-2*(1+dx*a1/b1)*y(nx)+2*dx*c1/b1-dxx*f(x(nx),y(nx),zz);
    end
    % solve Jz=-F
    z = tridiag( a, b, c, -v );
    err = norm(z,inf)/norm(y,inf);
    y=y+z;
    counter=counter+1;
end

newton_iterations=counter


% plot computed solution
clf
set(gcf,'Position', [25 1115 658 230])
plot(x,y,'b')
grid on
box on
xlabel('x-axis')
ylabel('Solution')
hold on
set(gca,'FontSize',14,'FontWeight','bold')


function y = tridiag( a, b, c, f )
n = length(f);
v = zeros(n,1);
y = v;
w = a(1);
y(1) = f(1)/w;
for i=2:n
    v(i-1) = c(i-1)/w;
    w = a(i) - b(i)*v(i-1);
    y(i) = ( f(i) - b(i)*y(i-1) )/w;
end
for j=n-1:-1:1
    y(j) = y(j) - v(j)*y(j+1);
end


%  right hand side of differential equation
function g=f(x,y,z)
g = 2-2*y^2-4*x*y*z;

%  fy(x,y,z) = diff(f,y)
function g=fy(x,y,z)
g = -4*y-4*x*z;

%  fz(x,y,z) = diff(f,z)
function g=fz(x,y,z)
g =-4*x*y;


%  This code is run by simply entering the command  nbvp  in MATLAB (making
%  sure that this file is in the path for MATLAB).  The user needs to first
%  enter certain information about the problem into this file before running it.

%  Needed Input From User

%  Boundary conditions (BCs): xL, a0, b0, c0, xR, a1, b1, c1 (see lines 12-13)
%  Number of grid points:  nx (line 16)
%
%  f(x,y,z):  this is the right hand side of the differential equation
%             with z acting as the place holder for y' (line 107)
%  fy(x,y,z):  this is the derivative of f with respect to y (line 111)
%  fz(x,y,z):  this is the derivative of f with respect to z (line 115)

%  Example:   y'' = 2 - 2y^2 - 4xyy'  for 0 < x < 1
%  with y(0) = 0 and y(1)/tanh(1) - y'(1)/(sech(1))^2 = -1
%    nx = 100
%    xL=0; a0=1; b0=0; c0=0;
%    xR=1; a1=1/tanh(1); b1=-1/(sech(1))^2; c1=-1;
%    f(x,y,z) = 2 - 2y^2 - 4xyz
%    fy(x,y,z) = - 4y - 4xz
%    fz(x,y,z) = - 4xy
% note: the exact solution for this example is y=tanh(x^2)

% What to do if it doesn't work (aside from checking on input errors)
%  1.  Use a different start-off guess for y (lines 21-27).
%  2.  If the problem has a boundary or interior layer you should consider
%      increasing  nx  (don't be shy about making nx very large).
%  3.  The error value on line 17 is used by Newton's method.  Feel free to
%      change this if you think it will help.
%  4.  Check to see if the problem has a solution (which is unique).

%  Background
%  This is a simple code that solves nonlinear 2nd order BVPs. It does not
%  use adaptive methods, but instead uses 2nd order centered differences on
%  a uniform grid, with Newton's method to solve the resulting nonlinear system.
%  The specific algorithm is described in the book Intro to Numerical Methods
%  for Differential Equations (Holmes, 2007) on pages 59-62.  It is very robust,
%  and was used to solve all of the nonlinear BVPs in Intro to Perturbation
%  Methods (Holmes, 1995).  It is also relatively fast, and as an illustration
%  it solves the above example in about 0.005 sec on an iMac (and it takes only
%  0.02 sec when nx=20000).

%  It has been tested on MATLAB, version R2017b
%  Version history:
%    1.0: April 7, 2010 (for BCs: y(xL) = yL, y(xR) = yR)
%    2.0: December 19, 2017 (this version)






























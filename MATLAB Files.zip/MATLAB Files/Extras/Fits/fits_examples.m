function fits_examples

%%% Examples

% % Example 1: least squares with cubic model function
%
% xd=rand(100,1);  yd=(5+20*(xd-0.5).^3).*(1-0.1*(rand(100,1)-0.5));
% p0 = [1 1 1 1];
% [pm,Fm] = fits(@(x,p) p(1)+p(2)*x+p(3)*x^2+p(4)*x^3,xd,yd,p0)

% % Example 2: 1-norm with Michaelis-Menten model function
%
% xd = [0.1 0.5 1 2 5 10]; yd = [0.5 1.8 3.4 6.1 8.7 11.1];
% p0 = [10 5];
% [pm,Fm] = fits(@(x,p) p(1)*x/(p(2)+x),xd,yd,p0,1)

% % Example 3: Inf-norm and relative error with power law model function
%
% xd = [0.1 0.5 1 2 5 10]; yd = [0.5 1.8 3.4 6.1 8.7 11.1];
% p0 = [1 1];
% [pm,Fm] = fits(@(x,p) p(1)*x^p(2),xd,yd,p0,Inf,1)

% % Example 4: least squares with piecewise linear model function
%               uses function procedure and plots results
%
x0=0.25; a=1; b=4; B=-2; A=a+(b-B)*x0;
xd=rand(100,1);
yd=(a+b*xd).*(x0>xd)+(a+(b-B)*x0+B*xd).*(x0<=xd);
yd=yd.*(1-0.2*(rand(100,1)-0.5));
p0 = [1 1 0.1 -1];
[pm, Fm] = fits(@f,xd,yd,p0)
hold on
box on
plot(xd,yd,'ob','LineWidth',2,'MarkerSize',8)
x=linspace(0,1,100);
y=(pm(1)+pm(2)*x).*(0.5*(tanh(pm(3))+1)>x);
y=y+(pm(1)+(pm(2)-pm(4))*0.5*(tanh(pm(3))+1)+pm(4)*x).*(0.5*(tanh(pm(3))+1)<=x);
plot(x,y,'r','LineWidth',2)

    function y=f(x,p)
        y1 = (p(1)+p(2)*x)*(0.5*(tanh(p(3))+1)>x);
        y2 = (p(1)+(p(2)-p(4))*0.5*(tanh(p(3))+1)+p(4)*x)*(0.5*(tanh(p(3))+1)<=x);
        y = y1+y2;
    end













end
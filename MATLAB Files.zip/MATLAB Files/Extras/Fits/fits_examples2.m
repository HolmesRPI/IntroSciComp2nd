function fits_examples2


%%% Examples

% % Example 1: least squares with cubic model function
%
% m=1; n=1;
% rng('default')
% xd=rand(100,1);  yd=(5+20*(xd-0.5).^3).*(1-0.2*(rand(100,1)-0.5));
% p0 = [1 1 1 1];
% [pm, Fm] = fits(@(x,p) p(1)+p(2)*x+p(3)*x^2+p(4)*x^3,xd,yd,p0,n,m)
% 
% p0 = [5/2 15 20 20];
% [pm, Fm] = fits(@(x,p) p(1)+p(2)*x+p(3)*x^2+p(4)*x^3,xd,yd,p0,n,m)
% 
% p0 = [-6 1 1 -8];
% [pm, Fm]  = fits(@(x,p) p(1)+p(2)*x+p(3)*x^2+p(4)*x^3,xd,yd,p0,n,m)
% 
% 
% clf
% co = [0 0 1;
%     0 0.5 0;
%     1 0 0;
%     0 0.75 0.75;
%     0.75 0 0.75;
%     0.75 0.75 0;
%     0.25 0.25 0.25];
% set(groot,'defaultAxesColorOrder',co)
% % get(gcf)
% set(gcf,'Position', [25 967 521 378])
% subaxis(1,1,1,1,'MT',0.003,'MB',0.09,'MR',0.001,'ML',0.04,'P',0.04)
% hold on
% box on
% plot(xd,yd,'ob','LineWidth',2,'MarkerSize',8)
% x=linspace(0,1,100);
% for ix=1:100
%     y(ix)=pm(1)+pm(2)*x(ix)+pm(3)*x(ix)^2+pm(4)*x(ix)^3;
% end
% plot(x,y,'r','LineWidth',2)
% ylabel('x-axis')
% xlabel('y-axis')
% set(gca,'FontSize',16,'FontWeight','bold')

% % Example 2: 1-norm with Michaelis-Menten model function
%
% xd = [0.1 0.5 1 2 5 10]; yd = [0.5 1.8 3.4 6.1 8.7 11.1];
% p0 = [10 5];
% pm = fits(@(x,p) p(1)*x/(p(2)+x),xd,yd,p0,1)

% % Example 3: Inf-norm and relative error with power law model function
%
% xd = [0.1 0.5 1 2 5 10]; yd = [0.5 1.8 3.4 6.1 8.7 11.1];
% p0 = [1 1];
% pm = fits(@(x,p) p(1)*x^p(2),xd,yd,p0,Inf,1)

% % Example 4: Example 2 but uses function procedure
%
% xd = [0.1 0.5 1 2 5 10]; yd = [0.5 1.8 3.4 6.1 8.7 11.1];
% p0 = [10 5];
% pm = fits(@f,xd,yd,p0,1)
%
% function y=f(x,p)
% y=p(1)*x/(p(2)+x);
% end

% % Example 5: derived from MATLAB's fitnlm example
% %            least squares with Metcherlich model function
%
% nd=100; xd=10*rand(nd,1); yd=(1+3*exp(-2*xd)).*(1-0.4*(rand(nd,1)-0.5));
% p0 = [2 2 2];
% pm = fits(@(x,p) p(1)+p(2)*exp(-p(3)*x),xd,yd,p0)


% % Example piecewise linear
%
%rng('default')
% x0=0.25; a=1; b=4; B=-2; A=a+(b-B)*x0;
% xd=rand(100,1);
% yd=(a+b*xd).*(x0>xd)+(a+(b-B)*x0+B*xd).*(x0<=xd);
% %yd=yd.*(1-0.2*(rand(100,1)-0.5));
% yd=yd+0.32*(rand(100,1)-0.5);
% p0 = [1 1 0.1 -1];
% [pm, Fm] = fits(@f,xd,yd,p0)
% 
% clf
% co = [0 0 1;
%     0 0.5 0;
%     1 0 0;
%     0 0.75 0.75;
%     0.75 0 0.75;
%     0.75 0.75 0;
%     0.25 0.25 0.25];
% set(groot,'defaultAxesColorOrder',co)
% % get(gcf)
% set(gcf,'Position', [25 967 521 378])
% subaxis(1,1,1,1,'MT',0.003,'MB',0.1,'MR',0.001,'ML',0.07,'P',0.04)
% hold on
% box on
% plot(xd,yd,'ob','LineWidth',2,'MarkerSize',8)
% x=linspace(0,1,100);
% y=(pm(1)+pm(2)*x).*(0.5*(tanh(pm(3))+1)>x);
% y=y+(pm(1)+(pm(2)-pm(4))*0.5*(tanh(pm(3))+1)+pm(4)*x).*(0.5*(tanh(pm(3))+1)<=x);
% plot(x,y,'r','LineWidth',2)
% ylabel('x-axis')
% xlabel('y-axis')
% set(gca,'FontSize',18,'FontWeight','bold')
% 
%     function y=f(x,p)
%         y1 = (p(1)+p(2)*x)*(0.5*(tanh(p(3))+1)>x);
%         y2 = (p(1)+(p(2)-p(4))*0.5*(tanh(p(3))+1)+p(4)*x)*(0.5*(tanh(p(3))+1)<=x);
%         y = y1+y2;
%     end

end





















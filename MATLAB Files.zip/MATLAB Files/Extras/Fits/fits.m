function [pm, Fm] = fits(f,xd,yd,p0,n,m)

% Parameter Fitting:  given a model function f(x,p), this program 
% finds the minimizer of F(p) = norm(d,n), where d = error vector 

% Usage (examples at end of file)
% Least squares [default]
%     fits(@(x,p)f(x,p),xd,yd,p0)
% Minimum n-norm with relative (m=1) or non-relative error (m=0)
%     fits(@(x,p)f(x,p),xd,yd,p0,n,m)

% Output: pm = fitted parameters for model function f(x,p)
%         Fm = F(pm)

% Required arguments:
%   f(x,p): the model function (see examples at the end of file)
%   xd, yd: data vectors
%   p0: starting point for minimizer 

% Optional arguments
%   n: number used for n-norm (including Inf)
%   m: if m = 0 then d(i) = f(xd(i),p) - yd(i))  [default choice]
%      if m = 1 then d(i) = (f(xd(i),p) - yd(i)))/yd(i)


%%% the code begins

% check for errors
nx=length(xd); ny=length(yd); np=length(p0);
if nx ~= ny
    error('xd and yd must have the same length')
end
if nx <= np
    error('not enough data')
end
if nargin == 6 && (m ~= 0 & m ~=1)
    error('you must have m=0 or m=1')
end

% set the defaults
if nargin == 4
    n=2;
    m=0;
elseif nargin == 5 
    m=0;
end

options = optimset('MaxFunEvals',1000*np,'MaxIter',1000*np,'TolX',1e-8);
pm = fminsearch(@(p)F(p,xd,yd),p0,options);
Fm = F(pm,xd,yd);

    function y=F(p,xd,yd)
        d=yd;
        for i=1:nx
            d(i)=d(i)-f(xd(i),p);
        end
        if m==1
            d=d./yd;
        end
        y=norm(d,n);
    end

end


%%% Examples

% % Example 1: least squares with cubic model function
%  
% xd=rand(100,1);  yd=(5+20*(xd-0.5).^3).*(1-0.1*(rand(100,1)-0.5));
% p0 = [1 1 1 1];
% [pm,Fm] = fits(@(x,p) p(1)+p(2)*x+p(3)*x^2+p(4)*x^3,xd,yd,p0)

% % Example 2: 1-norm with Michaelis-Menten model function
%
% xd = [0.1 0.5 1 2 5 10]; yd = [0.5 1.8 3.4 6.1 8.7 11.1];
% p0 = [10 5];
% [pm,Fm] = fits(@(x,p) p(1)*x/(p(2)+x),xd,yd,p0,1)

% % Example 3: Inf-norm and relative error with power law model function
%
% xd = [0.1 0.5 1 2 5 10]; yd = [0.5 1.8 3.4 6.1 8.7 11.1];
% p0 = [1 1];
% [pm,Fm] = fits(@(x,p) p(1)*x^p(2),xd,yd,p0,Inf,1)

% % Example 4: least squares with piecewise linear model function
%               uses function procedure and plots results
%
% x0=0.25; a=1; b=4; B=-2; A=a+(b-B)*x0;
% xd=rand(100,1);
% yd=(a+b*xd).*(x0>xd)+(a+(b-B)*x0+B*xd).*(x0<=xd);
% yd=yd.*(1-0.2*(rand(100,1)-0.5));
% p0 = [1 1 0.1 -1];
% [pm, Fm] = fits(@f,xd,yd,p0)
% hold on
% box on
% plot(xd,yd,'ob','LineWidth',2,'MarkerSize',8)
% x=linspace(0,1,100);
% y=(pm(1)+pm(2)*x).*(0.5*(tanh(pm(3))+1)>x);
% y=y+(pm(1)+(pm(2)-pm(4))*0.5*(tanh(pm(3))+1)+pm(4)*x).*(0.5*(tanh(pm(3))+1)<=x);
% plot(x,y,'r','LineWidth',2)
% 
%     function y=f(x,p)
%         y1 = (p(1)+p(2)*x)*(0.5*(tanh(p(3))+1)>x);
%         y2 = (p(1)+(p(2)-p(4))*0.5*(tanh(p(3))+1)+p(4)*x)*(0.5*(tanh(p(3))+1)<=x);
%         y = y1+y2;
%     end


% Warning: This is nonlinear regression, so all sorts of things can go
% wrong.  Some possibilities:
% 1) poor choice for p0
% 2) poor choice of model function for given data
% 3) difficult objective function (e.g., ill-conditoned, non-convex, etc)

%  Background
%  The algorithm is described in the text
%  "Introduction to Scientific Computing and Data Analysis" (Holmes, 2016).

%  Versions:
%  version 1.0: July 10, 2019













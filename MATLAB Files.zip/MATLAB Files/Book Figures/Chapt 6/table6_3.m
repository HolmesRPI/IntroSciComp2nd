function table6_3

%  Integrate  f(x)  over  [a, b]  using simpson's rule
%
%  Inputs:
%        a = left endpoint of interval
%        b = right endpoint of interval
%        n = number of subintervals
%

a=0; b=1;
exact=(exp(3)-1)/3;

%  interv = number of subinternals
interv=[10 20 40 80 160 320];
nk=length(interv);
for k=1:nk
    n=interv(k);
    S(k)=simp(a,b,n);
    err(k)=abs(exact-S(k));
end

fprintf('\n RIE = relative iterative error \n\n')
fprintf(' k \t  n  \t\t I_S \t \t Error \t\t RIE \n')
fprintf(' %i \t %i\t %19.15f \t %5.1e  \n',1,interv(1),S(1),err(1))
%fprintf('\\, %i \\, & \\, %i \\, & \\,\\, %19.15f \\,\\, & \\,\\, %5.1e  \\,\\, & \\,\\,  \\\\ \n',1,interv(1),S(1),err(1))
for k=2:nk
    fprintf(' %i \t %i \t %19.15f \t %5.1e  \t %5.1e   \n',k,interv(k),S(k),err(k),abs((S(k)-S(k-1))/S(k)))
    %fprintf('\\, %i \\, & \\, %i \\, & \\,\\, %19.15f \\,\\, & \\,\\, %5.1e  \\,\\, & \\,\\, %5.1e  \\\\ \n',k,interv(k),S(k),err(k),abs((S(k)-S(k-1))/S(k)))
end
fprintf('\n')


function y=f(x)
y=exp(3*x);

%%% composite simpson: n = number of subintervals
function s=simp(a,b,n)
xd=linspace(a,b,n+1);
h=xd(2)-xd(1);
s=f(xd(1));
for j=2:2:n
    ff2=f(xd(j+1));
    s=s+4*f(xd(j))+2*ff2;
end
s=h*(s-ff2)/3;













function fig6_7

a=0; b=1;

% f(x)
nxe=100;
xe=linspace(a,b,nxe);
for ix=1:nxe
    ye(ix)=f(xe(ix));
end

% interpolation points
xd = [ 0 0.25 0.5 0.75 1];
yd = [f(0) f(0.25) f(0.5) f(0.75) f(1)];
x1=a; x2=0.25*(a+b); x3=0.5*(a+b);
y1=f(x1);  y2=f(x2);  y3=f(x3);

% p_2(x)
nx=50;
x=linspace(x1,x3,nx);
for ix=1:nx
    s(ix)=p2(x(ix),x1,x2,x3,y1,y2,y3);
end
x1=0.5*(a+b); x2=0.75*(a+b); x3=a+b;
y1=f(x1);  y2=f(x2);  y3=f(x3);
nx=50;
xx=linspace(x1,x3,nx);
for ix=1:nx
    ss(ix)=p2(xx(ix),x1,x2,x3,y1,y2,y3);
end

clf
% get(gcf)
set(gcf,'Position', [25 1115 658 230])
subaxis(1,1,1,1,'MT',0.01,'MB',0.18,'MR',-0.02,'ML',0.045,'P',0.04)
co = [0 0 1;
    0 0.5 0;
    1 0 0;
    0 0.75 0.75;
    0.75 0 0.75;
    0.75 0.75 0;
    0.25 0.25 0.25];
set(groot,'defaultAxesColorOrder',co)

plot(x,s,'r','LineWidth',1.5)
hold on
plot(xe,ye,'--b','LineWidth',1.5)
plot(xd,yd,'ob','MarkerSize',9,'LineWidth',2)
plot(xx,ss,'r','LineWidth',1.8)
grid on
xlabel('x-axis')
ylabel('y-axis')

legend({' p_2(x)',' f(x)'},'Location','SouthWest','FontSize',16,'FontWeight','bold')

axis([0 1 -1 1.1])
set(gca,'xtick',[0 0.25 0.5 0.75 1])
%set(gca,'YMinorGrid','off');
set(gca,'FontSize',16,'FontWeight','bold')

%exportgraphics(gca,'/Users/mark/Desktop/simp0.eps')


function y=p2(x,x1,x2,x3,y1,y2,y3)
l1=(x-x2)*(x-x3)/( (x1-x2)*(x1-x3) );
l2=(x-x1)*(x-x3)/( (x2-x1)*(x2-x3) );
l3=(x-x1)*(x-x2)/( (x3-x1)*(x3-x2) );
y=y1*l1+y2*l2+y3*l3;

function y=f(x)
%y=cos(2*pi*x);
%y=exp(x);
y=cos(4*x^2);












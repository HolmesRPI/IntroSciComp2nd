function fig2_10

a=-1;
b=8;
nx=100;
x=linspace(a,b,nx);

x0=2;
m=(1-x0^2)/(1+x0^2)^2;
x1=x0-f(x0)/m
for ix=1:nx
    y(ix)=f(x(ix));
    yy(ix)=f(x0)+m*(x(ix)-x0);
end

clf
% get(gcf)
set(gcf,'Position', [25 1115 658 230])
subaxis(1,1,1,1,'MT',0.01,'MB',0.18,'MR',-0.02,'ML',0.06,'P',0.04)
co = [0 0 1;
    0 0.5 0;
    1 0 0;
    0 0.75 0.75;
    0.75 0 0.75;
    0.75 0.75 0;
    0.25 0.25 0.25];
set(groot,'defaultAxesColorOrder',co)

hold on
plot(x,y,'LineWidth',1.6)
plot(x,yy,'r','LineWidth',1.6)
plot([a b],[0 0],'k','LineWidth',0.8)

plot([x0],[0],'|k','LineWidth',2,'MarkerSize',12)
text(1.9,-0.13,'$x_0$','Interpreter','latex','FontSize',20)

plot([x1],[0],'+k','LineWidth',1.4,'MarkerSize',12)
xx1=0.97*x1;
text(xx1,-0.13,'$x_1$','Interpreter','latex','FontSize',20)

axis([a b -0.5 0.6])

xlabel('x-axis')
ylabel('y-axis')
grid on
box on
set(gca,'FontSize',16,'FontWeight','bold')

%exportgraphics(gca,'/Users/mark/Desktop/fail.eps')

function g=f(x)
%g=2*x*exp(-x^2)+0.5;
g=x/(1+x^2);






function fig2_9

%  Plot solution obtained using newton as function of starting value.
%  The function f(x) used here is a cubic spline (reason: it is easier to
%  control what it looks like than a regular polynomial)

%  Input:
%	xa = starting point
%	tol = tolerance for stopping
%	f(x) and df(x) These are at end of file

tol=10^(-6);

% evaluate function f(x) for plotting
a=-3;
b=6;
np=200;
x=linspace(a,b,np);
for ix=1:np
    F(ix)=f(x(ix));
end

%  run Newton's method for different starting values
nx=85;
xI=linspace(-3,6,nx);
for ix=1:nx
    xa=xI(ix);
    fa=f(xa);
    err=1;
    it=0;
    while err>tol
        xb=xa-f(xa)/df(xa);
        err=abs(xb-xa);
        xa=xb;
    end
    xS(ix)=xb;
end

clf
% get(gcf)
set(gcf,'Position', [9 959 745 386])
co = [0 0 1;
    0 0.5 0;
    1 0 0;
    0 0.75 0.75;
    0.75 0 0.75;
    0.75 0.75 0;
    0.25 0.25 0.25];
set(groot,'defaultAxesColorOrder',co)

subaxis(2,1,1,1,'MT',0.014,'MB',0.075,'MR',-0.02,'ML',0.02,'P',0.04)
plot(xI,xS,'or','MarkerSize',6,'LineWidth',2)
axis([-3 6 -3 6])
ylabel('Solution')
grid on
box on
set(gca,'FontSize',16,'FontWeight','bold')

subaxis(2,1,1,2)
plot(x,F,'b','LineWidth',1.8)
hold on
plot([a b],[0 0],'k','LineWidth',0.5)
plot([-2 0 3 105/20],[0],'.r','MarkerSize',35)
xlabel('x-axis')
ylabel('f(x)')
set(gca,'YTick',[0])
axis([-3 6 -35 40])
grid on
box on
set(gca,'FontSize',16,'FontWeight','bold')

%exportgraphics(gcf,'/Users/mark/Desktop/new2.eps')


function g=f(x)
g=x^4 - 25/4*x^3 - 3/4*x^2 + 63/2*x;

function g=df(x)
g=4*x^3 - 75/4*x^2 - 3/2*x + 63/2;




































function fig10_19

% random generation of A values
% m=10;   % number of vertices (must be even)
% A(1:m/2,1:m/2)=10+randi(20,m/2);
% A(1+m/2:m,1+m/2:m)=10+randi(20,m/2);
% A(1+m/2,1)=1;
% A=A./sum(A);

% book example
m=4; A=zeros(m,m);
d=1/20;
A(1,1)=1/4-d; A(2,1)=3/4-d; A(3,1)=2*d;
A(1,2)=1/3; A(2,2)=2/3;
A(3,3)=1/4; A(4,3)=3/4;
A(3,4)=1/3; A(4,4)=2/3;

% sum(A)
A
eigens=eig(A)
sings=svd(A)

T=40;
k=0;
for im=m+1:T
    %for im=4:T
    k=k+1;
    N(k)=im;  % number of time steps
    y=zeros(N(k),m);
    y(1,1)=100;
    %y(1,:)=ones(1,m);
    for i=2:N(k)
        z=A*y(i-1,:)';
        y(i,:)=z';
    end
    q=0.1*(2*rand(1,m)-1);
    %q=0;
    yd=(1+q).*y;
    XD=yd(1:N(k)-1,:);
    YD=yd(2:N(k),:);
    n=N(k)-1;

    % use the pseudo-inverse
    %     X=XD;
    %     Y=YD;
    %     G=X'*X;
    %     GI=inv(G);
    %     kappa(k)=cond(G,inf)
    %     P=Y'*X*GI;

    % use the SVD
    [U,S,V]=svd(XD);
    SS=zeros(n,m);
    for i=1:m
        SS(i,i)=1/S(i,i);
    end
    P=YD'*U*SS*V';

    Ac=P;
    error(k)=norm(A-Ac,inf)/norm(A,inf);

    if N(k)==5

        fprintf('\n %8.2f \\,\\,&\\,\\, %8.2f \\,\\,&\\,\\, %8.2f \\,\\,&\\,\\, %8.2f \\\\[0.2em]',A(1,:))
        fprintf('\n %8.2f \\,\\,&\\,\\, %8.2f \\,\\,&\\,\\, %8.2f \\,\\,&\\,\\, %8.2f \\\\[0.2em]',A(2,:))
        fprintf('\n %8.2f \\,\\,&\\,\\, %8.2f \\,\\,&\\,\\, %8.2f \\,\\,&\\,\\, %8.2f \\\\[0.2em]',A(3,:))
        fprintf('\n %8.2f \\,\\,&\\,\\, %8.2f \\,\\,&\\,\\, %8.2f \\,\\,&\\,\\, %8.2f \\\\',A(4,:))
        fprintf('\n\n')

        fprintf('\n %8.2f \\,\\,&\\,\\, %8.2f \\,\\,&\\,\\, %8.2f \\,\\,&\\,\\, %8.2f \\\\[0.2em]',Ac(1,:))
        fprintf('\n %8.2f \\,\\,&\\,\\, %8.2f \\,\\,&\\,\\, %8.2f \\,\\,&\\,\\, %8.2f \\\\[0.2em]',Ac(2,:))
        fprintf('\n %8.2f \\,\\,&\\,\\, %8.2f \\,\\,&\\,\\, %8.2f \\,\\,&\\,\\, %8.2f \\\\[0.2em]',Ac(3,:))
        fprintf('\n %8.2f \\,\\,&\\,\\, %8.2f \\,\\,&\\,\\, %8.2f \\,\\,&\\,\\, %8.2f \\\\',Ac(4,:))
        fprintf('\n\n')

    end
end

max(error)


figure(1)
clf
% get(gcf)
set(gcf,'Position', [25 1115 658 230])
subaxis(1,1,1,1,'MT',0.01,'MB',0.18,'MR',-0.02,'ML',0.05,'P',0.04)
co = [0 0 1;
    0 0.5 0;
    1 0 0;
    0 0.75 0.75;
    0.75 0 0.75;
    0.75 0.75 0;
    0.25 0.25 0.25];
set(groot,'defaultAxesColorOrder',co)
plot(N,error,'--r','lineWidth',0.8)
hold on
plot(N,error,'or','lineWidth',1.5,'MarkerSize',8)
box on
grid on
% axis([a b -2.5 4])
set(gca,'ytick',[0 0.05 0.1])
xlabel('n-axis')
ylabel('Relative Error')
set(gca,'FontSize',16,'FontWeight','bold')

%exportgraphics(gca,'/Users/mark/Desktop/carserror.eps')

% plot y values at location m
figure(2)
clf
% get(gcf)
set(gcf,'Position', [27 797 658 230])
subaxis(1,1,1,1,'MT',0.01,'MB',0.18,'MR',-0.02,'ML',0.06,'P',0.04)
co = [0 0 1;
    0 0.5 0;
    1 0 0;
    0 0.75 0.75;
    0.75 0 0.75;
    0.75 0.75 0;
    0.25 0.25 0.25];
set(groot,'defaultAxesColorOrder',co)
plot(1:N(k)-1,YD(:,m),'--ob')










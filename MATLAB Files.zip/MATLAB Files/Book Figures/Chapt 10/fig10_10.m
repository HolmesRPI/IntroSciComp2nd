function fig10_10

%%%%  data plots in s and y planes

% generate data
m=400;
t=linspace(0,10,m);
w1=pi;
w2=1.7*pi;
x=zeros(m,2);
% mixing coefficients A=[M11 M12; M21 M22]
M11=1; M12=2;
M21=1; M22=-2;
for it=1:m
    %     S(it,1) = sin(w1*t(it));
    %     S(it,2) = sin(w2*t(it)-5);
    S(it,1) = sin(w1*t(it));
    S(it,2) = (1/5)*(2.5*sin(w2*t(it)-1)+0.3*t(it)*(10-t(it)));
end

%%%% center S
sM=sum(S)/m;
S=S-sM;

%%% whiten S
[UR,SR,VR]=svd(S);
D=[sqrt(m)/SR(1,1) 0;0 sqrt(m)/SR(2,2)];
Fac=D*VR';
for it=1:m
    W1(it)=Fac(1,1)*S(it,1)+Fac(1,2)*S(it,2);
    W2(it)=Fac(2,1)*S(it,1)+Fac(2,2)*S(it,2);
end

for it=1:m
    X(it,1)=M11*W1(it) + M12*W2(it);
    X(it,2)=M21*W1(it) + M22*W2(it);
end

% for it=1:m
%     X(it,1)=M11*S(it,1) + M12*S(it,2);
%     X(it,2)=M21*S(it,1) + M22*S(it,2);
% end

xM=sum(X)/m;
X=X-xM;

XX=X'*X/m;
[UX,SX,VX]=svd(XX);
D5=[1/sqrt(SX(1,1)) 0; 0 1/sqrt(SX(2,2))];
% [DQ DR]=qr(XX);
% dDQ=det(DQ)

y=zeros(m,2);
for it=1:m
    y(it,:)=D5*VX'*X(it,:)';
end

figure(1)
clf
%get(gcf);
set(gcf,'Position', [17 1132 385 205])

co = [0 0 1;
    0 0.5 0;
    1 0 0;
    0 0.75 0.75;
    0.75 0 0.75;
    0.75 0.75 0;
    0.25 0.25 0.25];
set(groot,'defaultAxesColorOrder',co)

subaxis(1,2,1,'MT',0.04,'MB',0.25,'MR',-0.03,'ML',0.06,'P',0.03)
plot(W1,W2,'.b','MarkerSize',9)
%plot(S(:,1),S(:,2),'.b','MarkerSize',10)
hold on
%axis([-2.02 2.02 -2.02 2.02])
axis square
xlabel('s_1^* -axis')
ylabel('s_2^* -axis')
grid on
box on
set(gca,'FontSize',12,'FontWeight','bold')

subaxis(1,2,2)
plot(y(:,1),y(:,2),'.b','MarkerSize',9)
%plot(y(:,2),y(:,1),'.b','MarkerSize',10)
hold on
axis square
%axis([-2 2 -2 2]);
xlabel('y_1^* -axis')
ylabel('y_2^* -axis')
grid on
box on
set(gca,'FontSize',12,'FontWeight','bold')

%exportgraphics(gcf,'/Users/mark/Desktop/rot.eps')
















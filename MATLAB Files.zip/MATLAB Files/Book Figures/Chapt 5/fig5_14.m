function fig5_14

% piecewise linear interpolation
% note that this uses the fact that MATLAB draws straight lines betwen data
% points when plotting

a=0; b=1;
nx=6
xd=linspace(a,b,nx);

% data
for iy=1:nx
    yd(iy)=cos(2*pi*xd(iy));
end

% exact
n=400;
xp=linspace(a,b,n);
for i=1:n
    y(i)=cos(2*pi*xp(i));
end

clf
% get(gcf)
set(gcf,'Position', [25 1115 658 230])
subaxis(1,1,1,1,'MT',0.01,'MB',0.16,'MR',-0.03,'ML',0.042,'P',0.04)
co = [0 0 1;
    0 0.5 0;
    1 0 0;
    0 0.75 0.75;
    0.75 0 0.75;
    0.75 0.75 0;
    0.25 0.25 0.25];
set(groot,'defaultAxesColorOrder',co)

hold on
box on
plot(xp,y,'--r','LineWidth',1.8)
plot(xd,yd,'-b','LineWidth',1.6)
plot(xd,yd,'or','MarkerSize',7,'LineWidth',2)
grid on
xlabel('x-axis')
ylabel('y-axis')
legend({' Exact',' P-Linear'},'Location','North','FontSize',16,'FontWeight','bold')
set(gca,'FontSize',16,'FontWeight','bold')

%exportgraphics(gcf,'/Users/mark/Desktop/pcos.eps')











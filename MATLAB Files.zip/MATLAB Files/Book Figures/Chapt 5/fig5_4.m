function fig5_4

% global poly interpolation

a=-1; b=1;
nx=12
xd=linspace(a,b,nx);


% 5th degree poly
for iy=1:nx
    yd4(iy)=(xd(iy)+0.9)*(xd(iy)+0.1)^2*(xd(iy)-0.2)*(xd(iy)-0.8);
end

% jump function
for iy=1:nx
    yd1(iy)=(-1)^iy*0.02;
end
yd1(5)=1; yd1(6)=1; yd1(7)=1; yd1(8)=1;

% oscillatory function
for iy=1:nx
    yd2(iy)=(-1)^iy;
end

% circle function
for iy=1:nx
    yd3(iy)=sqrt(1-xd(iy)^2);
end

n=400;
xp=linspace(a,b,n);
cond(vander(xd),inf)

clf
% get(gcf)
set(gcf,'Position', [27 978 666 367])
co = [0 0 1;
    0 0.5 0;
    1 0 0;
    0 0.75 0.75;
    0.75 0 0.75;
    0.75 0.75 0;
    0.25 0.25 0.25];
set(groot,'defaultAxesColorOrder',co)

%subplot(2,2,1)
subaxis(2,2,2,2,'MT',0.005,'MB',0.1,'MR',0.01,'ML',0.06,'P',0.01)
% global poly
aa=inv(vander(xd))*yd1';
for ii=1:n
    yl1(ii)=aa(nx);
    for ip=2:nx
        yl1(ii)=yl1(ii)+aa(nx-ip+1)*xp(ii)^(ip-1);
    end
end

hold on
box on
plot(xd,yd1,'or','MarkerSize',7,'LineWidth',2)
plot(xp,yl1,'-b','LineWidth',1.4)
axis([-1.1 1.1 -3 1.2])
grid on
xlabel('x-axis')
set(gca,'FontSize',14,'FontWeight','bold')


subaxis(2,2,1,2)
%subplot(2,2,2)
% global poly
aa=inv(vander(xd))*yd2';
for ii=1:n
    yl2(ii)=aa(nx);
    for ip=2:nx
        yl2(ii)=yl2(ii)+aa(nx-ip+1)*xp(ii)^(ip-1);
    end
end

hold on
box on
plot(xd,yd2,'or','MarkerSize',7,'LineWidth',2)
plot(xp,yl2,'-b','LineWidth',1.4)
axis([-1.1 1.1 -3 3])
grid on
xlabel('x-axis')
ylabel('y-axis')
set(gca,'FontSize',14,'FontWeight','bold')


subaxis(2,2,2,1)
%subplot(2,2,3)
% global poly
aa=inv(vander(xd))*yd3';
for ii=1:n
    yl3(ii)=aa(nx);
    for ip=2:nx
        yl3(ii)=yl3(ii)+aa(nx-ip+1)*xp(ii)^(ip-1);
    end
end

hold on
box on
plot(xd,yd3,'or','MarkerSize',7,'LineWidth',2)
plot(xp,yl3,'-b','LineWidth',1.4)
axis([-1.1 1.1 -0.1 1.1])
set(gca,'YTick',[0 0.5 1])
grid on
set(gca,'FontSize',14,'FontWeight','bold')


subaxis(2,2,1,1)
%subplot(2,2,4)
% global poly
aa=inv(vander(xd))*yd4';
for ii=1:n
    yl4(ii)=aa(nx);
    for ip=2:nx
        yl4(ii)=yl4(ii)+aa(nx-ip+1)*xp(ii)^(ip-1);
    end
end

hold on
box on
plot(xd,yd4,'or','MarkerSize',7,'LineWidth',2)
plot(xp,yl4,'-b','LineWidth',1.4)
axis([-1.1 1.1 -0.2 0.4])
set(gca,'YTick',[-0.2 0 0.2 0.4])
grid on
ylabel('y-axis')
set(gca,'FontSize',14,'FontWeight','bold')






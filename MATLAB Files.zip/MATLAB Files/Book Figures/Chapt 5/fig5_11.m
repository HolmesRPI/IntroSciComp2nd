function fig5_11

%  plots the B-spline function

x0 = -3.0;
x1 = 3.0;
nx=201;
x=linspace(x0,x1,nx);

for ix=1:nx
    exact(ix)=bspline(x(ix));
end

clf
% get(gcf)
set(gcf,'Position', [25 1115 658 230])
subaxis(1,1,1,1,'MT',0.01,'MB',0.13,'MR',-0.01,'ML',0.01,'P',0.04)
co = [0 0 1;
    0 0.5 0;
    1 0 0;
    0 0.75 0.75;
    0.75 0 0.75;
    0.75 0.75 0;
    0.25 0.25 0.25];
set(groot,'defaultAxesColorOrder',co)

plot(x,exact,'b','LineWidth',2)
hold on
plot([-1 -1],[0 bspline(-1)],'--b','LineWidth',2)
plot([0 0],[0 bspline(0)],'--b','LineWidth',2)
plot([1 1],[0 bspline(1)],'--b','LineWidth',2)
axis([x0 x1 0 0.8])

plot([-2 -2],[0 0.02],'k','LineWidth',1)
plot([2 2],[0 0.02],'k','LineWidth',1)
set(gca,'XTickLabel',{' ';' ';' ';' ';' ';' ';' '})

set(gca,'YTick',[-10])
%set(gca,'YTickLabel',{'0';'1/3';'2/3'})
set(gca,'FontSize',16,'FontWeight','bold')


% Calculate the value of a cubic B-spline at point x
function y=bspline(x)
x=abs(x) ;
if x>2,
    y=0 ;
else
    if x>1,
        y=(2-x)^3/6 ;
    else
        y=2/3-x^2*(1-x/2) ;
    end
end




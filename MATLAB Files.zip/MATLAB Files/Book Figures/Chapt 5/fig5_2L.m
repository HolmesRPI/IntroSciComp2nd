function fig5_2L

%  the requires the files: hand_nodes.txt  and  splineA.m

%  the hand data is due to John Burkardt and from:
%  https://people.sc.fsu.edu/~jburkardt/m_src/hand_data_test/hand_data_test.html

hn = load ( 'hand_nodes.txt' );

hand = [ [ hn ] ; [ hn(1,:)]];
[ m, n ] = size ( hand )
p=1:m;
t=linspace(1,m,500);

% use not-a-knot
% u = spline( p, hand(:,1), t );
% v = spline( p, hand(:,2), t );

% use a natural spline fit
u = splineA( p, hand(:,1), t );
v = splineA( p, hand(:,2), t );

clf
% get(gcf)
set(gcf,'Position', [50 925 560 420])

co = [0 0 1;
    0 0.5 0;
    1 0 0;
    0 0.75 0.75;
    0.75 0 0.75;
    0.75 0.75 0;
    0.25 0.25 0.25];
set(groot,'defaultAxesColorOrder',co)

plot (u,v,'Color','r','LineWidth',2)
hold on
plot (hand(:,1),hand(:,2),'.b','MarkerSize',26)

set(gca,'XTick',[0.2 0.3 0.4 0.5 0.6 0.7])
set(gca,'YTick',[0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9])
axis([0.2 0.7 0.2 0.9])
%  axis equal
grid on
hold off
xlabel('x-axis')
ylabel('y-axis')
set(gca,'FontSize',26,'FontWeight','bold')













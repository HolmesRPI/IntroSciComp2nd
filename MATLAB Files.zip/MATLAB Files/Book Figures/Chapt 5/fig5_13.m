function fig5_13

% fit cubic splines to the four data sets

%%% and it requires the file splineA.m

%%%%%  generate the data sets
a=-1; b=1;
nx=12;
xd=linspace(a,b,nx);


% 5th degree poly
for iy=1:nx
    yd4(iy)=(xd(iy)+0.9)*(xd(iy)+0.1)^2*(xd(iy)-0.2)*(xd(iy)-0.8);
end

% jump function
for iy=1:nx
    yd1(iy)=(-1)^iy*0.02;
end
yd1(5)=1; yd1(6)=1; yd1(7)=1; yd1(8)=1;

% oscillatory function
for iy=1:nx
    yd2(iy)=(-1)^iy;
end

% oscillatory function
for iy=1:nx
    yd3(iy)=sqrt(1-xd(iy)^2);
end


%%%% evaluate and then pot spline function

%  ysM = MATLAB spline function
%  ys = natural spline (requires splineA.m file)

n=400;
xp=linspace(a,b,n);

clf
% get(gcf)
set(gcf,'Position', [27 978 666 367])
co = [0 0 1;
    0 0.5 0;
    1 0 0;
    0 0.75 0.75;
    0.75 0 0.75;
    0.75 0.75 0;
    0.25 0.25 0.25];
set(groot,'defaultAxesColorOrder',co)

%subplot(2,2,1)
subaxis(2,2,2,2,'MT',0.005,'MB',0.1,'MR',0.01,'ML',0.06,'P',0.01)

ys = splineA(xd,yd1,xp);
ysM = spline(xd,yd1,xp);
hold on
box on
plot(xd,yd1,'or','MarkerSize',7,'LineWidth',2)
plot(xp,ys,'b','LineWidth',1.4)
plot(xp,ysM,'--k','LineWidth',1.4)
axis([-1.1 1.1 -0.2 1.2])
set(gca,'YTick',[0 0.5 1])
grid on
xlabel('x-axis')
set(gca,'FontSize',14,'FontWeight','bold')


subaxis(2,2,1,2)
%subplot(2,2,2)

ys2 = splineA(xd,yd2,xp);
ysM2 = spline(xd,yd2,xp);
hold on
box on
plot(xd,yd2,'or','MarkerSize',7,'LineWidth',2)
plot(xp,ys2,'b','LineWidth',1.4)
plot(xp,ysM2,'--k','LineWidth',1.4)
axis([-1.1 1.1 -1.5 1.5])
set(gca,'YTick',[-1 0 1])
grid on
xlabel('x-axis')
ylabel('y-axis')
set(gca,'FontSize',14,'FontWeight','bold')


subaxis(2,2,2,1)
%subplot(2,2,3)

ys3 = splineA(xd,yd3,xp);
ysM3 = spline(xd,yd3,xp);
hold on
box on
plot(xd,yd3,'or','MarkerSize',7,'LineWidth',2)
plot(xp,ys3,'b','LineWidth',1.4)
plot(xp,ysM3,'--k','LineWidth',1.4)
axis([-1.1 1.1 -0.1 1.1])
set(gca,'YTick',[0 0.5 1])
grid on
set(gca,'FontSize',14,'FontWeight','bold')


subaxis(2,2,1,1)
%subplot(2,2,4)

ys4 = splineA(xd,yd4,xp);
ysM4 = spline(xd,yd4,xp);
hold on
box on
plot(xd,yd4,'or','MarkerSize',7,'LineWidth',2)
plot(xp,ys4,'b','LineWidth',1.4)
plot(xp,ysM4,'--k','LineWidth',1.4)
axis([-1.1 1.1 -0.2 0.4])
set(gca,'YTick',[-0.2 0 0.2 0.4])
grid on
ylabel('y-axis')
set(gca,'FontSize',14,'FontWeight','bold')






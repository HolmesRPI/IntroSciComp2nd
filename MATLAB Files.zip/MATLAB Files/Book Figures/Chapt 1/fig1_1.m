function fig1_1

%%% this requires the subaxis.m and parseArgs.m files

clf
% get(gcf)
set(gcf,'Position', [25 930 660 420])
co = [0 0 1;
    0 0.5 0;
    1 0 0;
    0 0.75 0.75;
    0.75 0 0.75;
    0.75 0.75 0;
    0.25 0.25 0.25];
set(groot,'defaultAxesColorOrder',co)

%  generate and then plot upper graph
subaxis(2,1,1,1,'MT',0.01,'MB',0.06,'MR',-0.02,'ML',0.02,'P',0.05)
d=0.1;
nx=1000;
x=linspace(1-d,1+d,nx);
for i=1:nx
    y(i)=x(i)^8-8*x(i)^7+28*x(i)^6-56*x(i)^5+70*x(i)^4-56*x(i)^3+28*x(i)^2-8*x(i)+1;
    yy(i)=(x(i)-1)^8;
end
plot(x,yy, '--b','LineWidth',2)
hold on
plot(x,y, 'r','LineWidth',1.2)
hold on
grid on
box on
axis([1-d 1+d -1e-9 1e-8])
set(gca,'xtick',[0.9 0.95 1 1.05 1.1])
%xlabel('x-axis')
ylabel('y-axis')
set(gca,'FontSize',16,'FontWeight','bold')
legend({' Using (1.3)',' Using (1.4)'},'Location','North','FontSize',16,'FontWeight','bold')

%  generate and then plot lower graph
subaxis(2,1,1,2)
d=0.02;
x=linspace(1-d,1+d,nx);
for i=1:nx
    y(i)=x(i)^8-8*x(i)^7+28*x(i)^6-56*x(i)^5+70*x(i)^4-56*x(i)^3+28*x(i)^2-8*x(i)+1;
    yy(i)=(x(i)-1)^8;
end
plot(x,y, 'r','LineWidth',1)
hold on
plot(x,yy, '--b','LineWidth',2.5)
hold on
grid on
box on
axis([1-d 1+d -2e-14 4e-14])
set(gca,'xtick',[0.98 0.99 1 1.01 1.02])
xlabel('x-axis')
ylabel('y-axis')
set(gca,'FontSize',16,'FontWeight','bold')

%exportgraphics(gcf,'/Users/mark/Desktop/power.eps')














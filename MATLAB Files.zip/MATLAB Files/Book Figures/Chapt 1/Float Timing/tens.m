function g=tens(n)

% To use this program, enter the command: tens(1000000);
pi*10+sqrt(7)+exp(2)+3*sin(5)/7+log(11)+pi^5;

add=1.0688;

TOC=0;
maxz=0;
for j=1:n
    x=1+randi(11)*eps;
    tic
    z=x^10;
    z=z^10;
    z=z^10;
    z=z^10;
    z=z^10;
    z=z^10;
    z=z^10;
    z=z^10;
    z=z^10;
    z=z^10;
    z=z^10;
    z=z^10;
    z=z^10;
    z=z^10;
    z=z^10;
    z=z^10;
    TOC=TOC+toc;
    if maxz<z
        maxz=z;
    end
end
ten=(1000/16)*TOC/add
z
maxz
g=1;




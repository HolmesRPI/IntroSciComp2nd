#!/usr/bin/env python

import math 
import time
import random

def main():
    TOC=0
    add=1.03946e+10
    iterations = 1000000
    for i in range(iterations):
        ii=random.choice([-1,1])
        x=random.random()*(10**(ii*297))
        tic = time.perf_counter_ns() 
        y=math.sqrt(x) 
        y=math.sqrt(y) 
        y=math.sqrt(y) 
        y=math.sqrt(y) 
        y=math.sqrt(y) 
        y=math.sqrt(y) 
        y=math.sqrt(y) 
        y=math.sqrt(y) 
        y=math.sqrt(y) 
        y=math.sqrt(y) 
        y=math.sqrt(y) 
        y=math.sqrt(y) 
        y=math.sqrt(y) 
        y=math.sqrt(y) 
        y=math.sqrt(y) 
        y=math.sqrt(y) 
        y=math.sqrt(y) 
        y=math.sqrt(y) 
        y=math.sqrt(y) 
        y=math.sqrt(y) 
        TOC = TOC+time.perf_counter_ns()-tic
        
                
    print(f"\n roots = {(1000/20)*TOC/add:0.4f} \n")

if __name__ == "__main__":
        main()




















#!/usr/bin/env python

import math 
import time
import random

def main():
    TOC=0
    add=1.04088e+10
    iterations = 1000000
    for i in range(iterations):
        ii=random.choice([1,2,3,4,5,6,7,8,9,10])
        z=random.random()*(10**(ii-5))
        tic = time.perf_counter_ns() 
        z=math.sin(z) 
        z=math.sin(z) 
        z=math.sin(z) 
        z=math.sin(z) 
        z=math.sin(z) 
        z=math.sin(z) 
        z=math.sin(z) 
        z=math.sin(z) 
        z=math.sin(z) 
        z=math.sin(z) 
        z=math.sin(z) 
        z=math.sin(z) 
        z=math.sin(z) 
        z=math.sin(z) 
        z=math.sin(z) 
        z=math.sin(z) 
        z=math.sin(z) 
        z=math.sin(z) 
        z=math.sin(z) 
        z=math.sin(z) 
        z=math.sin(z) 
        z=math.sin(z) 
        z=math.sin(z) 
        z=math.sin(z) 
        z=math.sin(z) 
        z=math.sin(z) 
        z=math.sin(z) 
        z=math.sin(z) 
        z=math.sin(z) 
        z=math.sin(z) 
        z=math.sin(z) 
        z=math.sin(z) 
        z=math.sin(z) 
        z=math.sin(z) 
        z=math.sin(z) 
        z=math.sin(z) 
        z=math.sin(z) 
        z=math.sin(z) 
        z=math.sin(z) 
        z=math.sin(z) 
        z=math.sin(z) 
        z=math.sin(z) 
        z=math.sin(z) 
        z=math.sin(z) 
        z=math.sin(z) 
        z=math.sin(z) 
        z=math.sin(z) 
        z=math.sin(z) 
        z=math.sin(z) 
        z=math.sin(z) 
        z=math.sin(z) 
        z=math.sin(z) 
        z=math.sin(z) 
        z=math.sin(z) 
        z=math.sin(z) 
        z=math.sin(z) 
        z=math.sin(z) 
        z=math.sin(z) 
        z=math.sin(z) 
        z=math.sin(z) 
        TOC = TOC+time.perf_counter_ns()-tic
                
                                
    print(f"\n sine = {(1000/60)*TOC/add:0.4e} \n")

if __name__ == "__main__":
                main()




















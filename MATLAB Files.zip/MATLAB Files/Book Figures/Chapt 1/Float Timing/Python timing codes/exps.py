#!/usr/bin/env python

import math 
import time
import random

def main():
    TOC=0
    add=1.04088e+10
    iterations = 1000000
    for i in range(iterations):
        y=-random.random()*100
        tic = time.perf_counter_ns() 
        y=math.exp(y) 
        y=math.exp(y) 
        y=math.exp(y) 
        y=math.exp(-y) 
        y=math.exp(y) 
        y=math.exp(y) 
        y=math.exp(y) 
        y=math.exp(-y) 
        y=math.exp(y) 
        y=math.exp(y) 
        y=math.exp(y) 
        y=math.exp(-y) 
        y=math.exp(y) 
        y=math.exp(y) 
        y=math.exp(y) 
        y=math.exp(-y) 
        y=math.exp(y) 
        y=math.exp(y) 
        y=math.exp(y) 
        y=math.exp(-y) 
        y=math.exp(y) 
        y=math.exp(y) 
        y=math.exp(y) 
        y=math.exp(-y) 
        y=math.exp(y) 
        y=math.exp(y) 
        y=math.exp(y) 
        y=math.exp(-y) 
        y=math.exp(y) 
        y=math.exp(y) 
        y=math.exp(y) 
        y=math.exp(-y) 
        y=math.exp(y) 
        y=math.exp(y) 
        y=math.exp(y) 
        y=math.exp(-y) 
        y=math.exp(y) 
        y=math.exp(y) 
        y=math.exp(y) 
        y=math.exp(-y) 
        y=math.exp(y) 
        y=math.exp(y) 
        y=math.exp(y) 
        y=math.exp(-y) 
        y=math.exp(y) 
        y=math.exp(y) 
        y=math.exp(y) 
        y=math.exp(-y) 
        y=math.exp(y) 
        y=math.exp(y) 
        y=math.exp(y) 
        y=math.exp(-y) 
        y=math.exp(y) 
        y=math.exp(y) 
        y=math.exp(y) 
        y=math.exp(-y) 
        y=math.exp(y) 
        y=math.exp(y) 
        y=math.exp(y) 
        y=math.exp(-y) 
        y=math.exp(y) 
        y=math.exp(y) 
        y=math.exp(y) 
        y=math.exp(-y) 
        y=math.exp(y) 
        y=math.exp(y) 
        y=math.exp(y) 
        y=math.exp(-y) 
        y=math.exp(y) 
        y=math.exp(y) 
        y=math.exp(y) 
        y=math.exp(-y) 
        y=math.exp(y) 
        y=math.exp(y) 
        y=math.exp(y) 
        y=math.exp(-y) 
        y=math.exp(y) 
        y=math.exp(y) 
        y=math.exp(y) 
        y=math.exp(-y) 
        y=math.exp(y) 
        y=math.exp(y) 
        y=math.exp(y) 
        y=math.exp(-y) 
        y=math.exp(y) 
        y=math.exp(y) 
        y=math.exp(y) 
        y=math.exp(-y) 
        y=math.exp(y) 
        y=math.exp(y) 
        y=math.exp(y) 
        y=math.exp(-y) 
        y=math.exp(y) 
        y=math.exp(y) 
        y=math.exp(y) 
        y=math.exp(-y) 
        y=math.exp(y) 
        y=math.exp(y) 
        y=math.exp(y) 
        y=math.exp(-y) 
        TOC = TOC+time.perf_counter_ns()-tic
                
                                
    print(f"\n exps = {(1000/100)*TOC/add:0.4e} \n")

if __name__ == "__main__":
                main()




















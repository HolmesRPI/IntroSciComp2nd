#!/usr/bin/env python

import math 
import time
import random

def main():

    TOC=0
    add=1.03946e+10
    iterations = 1000000

    for i in range(iterations):
      ii=random.choice([1,2,3,4,5,6,7,8,9,10,11])
      x=1.0+ii*2e-16
      tic = time.perf_counter_ns()
      z=x**20 
      z=z**20 
      z=z**20 
      z=z**20 
      z=z**20 
      z=z**20 
      z=z**20 
      z=z**20 
      z=z**20 
      z=z**20 

      TOC = TOC+time.perf_counter_ns()-tic
                              
    print(f"\n twenties = {(1000/12)*TOC/add:0.4f} \n")

if __name__ == "__main__":
    main()


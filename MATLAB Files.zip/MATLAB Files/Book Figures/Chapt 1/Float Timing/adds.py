#!/usr/bin/env python

import math 
import time

def main():

    z=math.sqrt(3e-103)
    x1=math.sqrt(1+7e-7)
    iterations = 10000000
    tic = time.perf_counter()
    for i in range(iterations):
        z=z+x1
        z=z+x1
        z=z+x1
        z=z+x1
        z=z+x1
        z=z+x1
        z=z+x1
        z=z+x1
        z=z+x1
        z=z+x1
        z=z+x1
        z=z+x1
        z=z+x1
        z=z+x1
        z=z+x1
        z=z+x1
        z=z+x1
        z=z+x1
        z=z+x1
        z=z+x1
        z=z+x1
        z=z+x1
        z=z+x1
        z=z+x1
        z=z+x1
        z=z+x1
        z=z+x1
        z=z+x1
        z=z+x1
        z=z+x1
        z=z+x1
        z=z+x1
        z=z+x1
        z=z+x1
        z=z+x1
        z=z+x1
        z=z+x1
        z=z+x1
        z=z+x1
        z=z+x1
        z=z+x1
        z=z+x1
        z=z+x1
        z=z+x1
        z=z+x1
        z=z+x1
        z=z+x1
        z=z+x1
        z=z+x1
        z=z+x1
        z=z+x1
        z=z+x1
        z=z+x1
        z=z+x1
        z=z+x1
        z=z+x1
        z=z+x1
        z=z+x1
        z=z+x1
        z=z+x1

    toc = time.perf_counter()
    print(f"add = {toc - tic:0.4e} seconds")
    print(f"adds = {(toc - tic)/(60*iterations):0.3e} seconds")
    print(f"z = {z:0.8e}")

if __name__ == "__main__":
    main()


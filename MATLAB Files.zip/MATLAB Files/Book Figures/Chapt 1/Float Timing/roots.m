function g=roots(n)

% To use this program, enter the command:  roots(1000000);
pi*10+sqrt(7)+exp(2)+3*sin(5)/7+log(11)+pi^5;

add=1.0713;
TOC=0;
miny=Inf;
for j=1:n
    s=2*randi(2)-3;
    y=rand*10^(s*297);
    tic
    y=sqrt(y);
    y=sqrt(y);
    y=sqrt(y);
    y=sqrt(y);
    y=sqrt(y);
    y=sqrt(y);
    y=sqrt(y);
    y=sqrt(y);
    y=sqrt(y);
    y=sqrt(y);
    y=sqrt(y);
    y=sqrt(y);
    y=sqrt(y);
    y=sqrt(y);
    y=sqrt(y);
    y=sqrt(y);
    y=sqrt(y);
    y=sqrt(y);
    y=sqrt(y);
    y=sqrt(y);
    TOC=TOC+toc;
    if abs(y-1)<miny
        miny=abs(y-1);
    end
end
rootss=(1000/20)*TOC/add
miny
g=1;




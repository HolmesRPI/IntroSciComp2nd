function g=sine(n)

% To use this program, enter the command: sine(1000000);
pi*10+sqrt(7)+exp(2)+3*sin(5)/7+log(11)+pi^5;

add=1.0726;

TOC=0;
maxz=0;
minz=Inf;
for j=1:n
    z=rand*10^(randi(10)-5);
    tic
    z=sin(z);
    z=sin(z);
    z=sin(z);
    z=sin(z);
    z=sin(z);
    z=sin(z);
    z=sin(z);
    z=sin(z);
    z=sin(z);
    z=sin(z);
    z=sin(z);
    z=sin(z);
    z=sin(z);
    z=sin(z);
    z=sin(z);
    z=sin(z);
    z=sin(z);
    z=sin(z);
    z=sin(z);
    z=sin(z);
    z=sin(z);
    z=sin(z);
    z=sin(z);
    z=sin(z);
    z=sin(z);
    z=sin(z);
    z=sin(z);
    z=sin(z);
    z=sin(z);
    z=sin(z);
    z=sin(z);
    z=sin(z);
    z=sin(z);
    z=sin(z);
    z=sin(z);
    z=sin(z);
    z=sin(z);
    z=sin(z);
    z=sin(z);
    z=sin(z);
    z=sin(z);
    z=sin(z);
    z=sin(z);
    z=sin(z);
    z=sin(z);
    z=sin(z);
    z=sin(z);
    z=sin(z);
    z=sin(z);
    z=sin(z);
    z=sin(z);
    z=sin(z);
    z=sin(z);
    z=sin(z);
    z=sin(z);
    z=sin(z);
    z=sin(z);
    z=sin(z);
    z=sin(z);
    z=sin(z);
    if abs(z)>maxz
        maxz=abs(z);
    end
    if minz>abs(z)
        minz=abs(z);
    end
    TOC=TOC+toc;
end
sines=(1000/60)*TOC/add
maxz
minz
g=1;




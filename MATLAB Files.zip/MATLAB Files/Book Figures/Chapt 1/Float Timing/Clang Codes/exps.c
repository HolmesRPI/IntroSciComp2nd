//  clang exps.c   ./a.out

#include <stdio.h>
#include <time.h>
#include <stdlib.h>
#include <math.h>

int main() {
    double y, add, z, rr, TOC;
    int n=1000000;
    int i;
    
    add=2.508858;
    TOC=0;

    clock_t start;

    for (i = 0; i < n; i++) {
        srand (time(NULL));
        rr= rand();
        z=-rr*100;
        start = clock();
        y=exp(y);
        y=exp(y);
        y=exp(y);
        y=exp(-y);
        y=exp(y);
        y=exp(y);
        y=exp(y);
        y=exp(-y);
        y=exp(y);
        y=exp(y);
        y=exp(y);
        y=exp(-y);
        y=exp(y);
        y=exp(y);
        y=exp(y);
        y=exp(-y);
        y=exp(y);
        y=exp(y);
        y=exp(y);
        y=exp(-y);
        y=exp(y);
        y=exp(y);
        y=exp(y);
        y=exp(-y);
        y=exp(y);
        y=exp(y);
        y=exp(y);
        y=exp(-y);
        y=exp(y);
        y=exp(y);
        y=exp(y);
        y=exp(-y);
        y=exp(y);
        y=exp(y);
        y=exp(y);
        y=exp(-y);
        y=exp(y);
        y=exp(y);
        y=exp(y);
        y=exp(-y);
        y=exp(y);
        y=exp(y);
        y=exp(y);
        y=exp(-y);
        y=exp(y);
        y=exp(y);
        y=exp(y);
        y=exp(-y);
        y=exp(y);
        y=exp(y);
        y=exp(y);
        y=exp(-y);
        y=exp(y);
        y=exp(y);
        y=exp(y);
        y=exp(-y);
        y=exp(y);
        y=exp(y);
        y=exp(y);
        y=exp(-y);
        y=exp(y);
        y=exp(y);
        y=exp(y);
        y=exp(-y);
        y=exp(y);
        y=exp(y);
        y=exp(y);
        y=exp(-y);
        y=exp(y);
        y=exp(y);
        y=exp(y);
        y=exp(-y);
        y=exp(y);
        y=exp(y);
        y=exp(y);
        y=exp(-y);
        y=exp(y);
        y=exp(y);
        y=exp(y);
        y=exp(-y);
        y=exp(y);
        y=exp(y);
        y=exp(y);
        y=exp(-y);
        y=exp(y);
        y=exp(y);
        y=exp(y);
        y=exp(-y);
        y=exp(y);
        y=exp(y);
        y=exp(y);
        y=exp(-y);
        y=exp(y);
        y=exp(y);
        y=exp(y);
        y=exp(-y);
        y=exp(y);
        y=exp(y);
        y=exp(y);
        y=exp(-y);
        TOC=TOC+clock()-start;
    }
    printf("\n Exps: %lf \n\n",  (1000/100)*TOC/(add*CLOCKS_PER_SEC));
    return 0;
}

















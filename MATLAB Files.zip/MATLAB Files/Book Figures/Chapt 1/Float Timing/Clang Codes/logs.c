//  clang logs.c   ./a.out

#include <stdio.h>
#include <time.h>
#include <stdlib.h>
#include <math.h>

int main() {
    double y, y0, add, x1, rr, TOC;
    int n=1000000;
    int i;
    
    add=2.508858;
    TOC=0;
    y0=0;

    clock_t start;

    for (i = 0; i < n; i++) {
        srand (time(NULL));
        rr= rand();
        x1=rr*1e280;
        start = clock();
        y=log(x1);
        y=log(y);
        y=log(y);
        y=log(y);
        y=log(y);
        y=log(x1+y0*y);
        y=log(y);
        y=log(y);
        y=log(y);
        y=log(y);
        y=log(x1+y0*y);
        y=log(y);
        y=log(y);
        y=log(y);
        y=log(y);
        y=log(x1+y0*y);
        y=log(y);
        y=log(y);
        y=log(y);
        y=log(y);
        TOC=TOC+clock()-start;
    }
    printf("\n logs: %lf \n\n",  (1000/20)*TOC/(add*CLOCKS_PER_SEC));
    return 0;
}

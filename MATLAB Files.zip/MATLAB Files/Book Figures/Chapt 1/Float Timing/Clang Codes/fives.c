
//  clang fives.c   ./a.out

#include <stdio.h>
#include <time.h>
#include <stdlib.h>
#include <math.h>

int main() {
    double add, x, z, TOC;
    int n=1000000;
    int m=5;
    int i, ir;

    add=2.508858;
    TOC=0;
    clock_t start;
    
    for (i = 0; i < n; i++) {
        srand (time(NULL));
        ir= rand() % 12 + 1;
        ir=ir+1;
        x=1+ir*2e-16;
        start = clock();
        z=pow(x,m);
        z=pow(z,m);
        z=pow(z,m);
        z=pow(z,m);
        z=pow(z,m);
        z=pow(z,m);
        z=pow(z,m);
        z=pow(z,m);
        z=pow(z,m);
        z=pow(z,m);
        z=pow(z,m);
        z=pow(z,m);
        z=pow(z,m);
        z=pow(z,m);
        z=pow(z,m);
        z=pow(z,m);
        z=pow(z,m);
        z=pow(z,m);
        z=pow(z,m);
        z=pow(z,m);
        z=pow(z,m);
        z=pow(z,m);
        z=pow(z,m);
        z=pow(z,m);
        TOC=TOC+clock()-start;
        }
    printf("\n Fives: %lf \n\n",  (1000/24)*TOC/(add*CLOCKS_PER_SEC));
    return 0;
}

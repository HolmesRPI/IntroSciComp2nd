function fig7_10

%  RK4 for the system y' = f(t,y)  with   y(0) = y0
%  y=[y(1) y(2)]   f=[f1 f2]

M=400;

T=10;
t=linspace(0,T,M+1);
k=t(2)-t(1);

% solve using rk4
y0=[-1 -6];
[u,v]=rk4(t,y0,k,M+1);

% solve using rk4
y0=[3 2];
[u2,v2]=rk4(t,y0,k,M+1);

clf
% get(gcf)
set(gcf,'Position', [25 1115 658 230])
subaxis(1,1,1,1,'MT',0.01,'MB',0.18,'MR',-0.02,'ML',0.03,'P',0.04)
co = [0 0 1;
    0 0.5 0;
    1 0 0;
    0 0.75 0.75;
    0.75 0 0.75;
    0.75 0.75 0;
    0.25 0.25 0.25];
set(groot,'defaultAxesColorOrder',co)

plot(u,v,'-b','LineWidth',1.5)
hold on
plot(u(1),v(1),'b.','MarkerSize',40)
plot(u2,v2,'-r','LineWidth',1.5)
plot(u2(1),v2(1),'.r','MarkerSize',40)

ar=1;
ii=40; i=ii-1;
arrowhead([u(i) u(ii)],[v(i) v(ii)],'b',[1.2*ar 1.5*ar],3);

ar=1;
ii=30; i=ii-1;
arrowhead([u2(i) u2(ii)],[v2(i) v2(ii)],'r',[1.2*ar 1.5*ar],3);

% axis([-3 3 -6 3])
set(gca,'YTick',[-6 -3 0 3]);
% set(gca,'YTickLabel',{' ','0',' '})
box on
grid on
xlabel('u-axis')
ylabel('v-axis')
set(gca,'FontSize',16,'FontWeight','bold')
hold off

%exportgraphics(gca,'/Users/mark/Desktop/sys1.eps')


% right-hand side of DE
function z=f(t,y)
%  y=[y(1) y(2)]
z=[y(2)-0.5*y(1)  -0.5*y(2)+2*y(1)*(2-y(1)^2)];


% RK4 method
function [ypoints, vpoints] =rk4(t,y0,h,n)
y=y0;
ypoints=y0(1);
vpoints=y0(2);
for i=2:n
    k1=h*f(t(i-1),y);
    k2=h*f(t(i-1)+0.5*h,y+0.5*k1);
    k3=h*f(t(i-1)+0.5*h,y+0.5*k2);
    k4=h*f(t(i),y+k3);
    yy=y+(k1+2*k2+2*k3+k4)/6;
    ypoints=[ypoints, yy(1)];
    vpoints=[vpoints, yy(2)];
    y=yy;
end











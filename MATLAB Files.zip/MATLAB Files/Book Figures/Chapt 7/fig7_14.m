function fig7_14

%  comparison of imaginary and centered difference approximations for f'(x)

x0=1;
exact=0.5;

for k=1:16
    h(k)=1/10^(k-1);
    cd(k)=imag(f(x0+i*h(k)))/h(k);
    c(k)=(f(x0+h(k)) - f(x0-h(k)) )/(2*h(k));
    errc(k)=abs(exact-c(k));
    errcd(k)=abs(exact-cd(k));
end

clf
% get(gcf)
set(gcf,'Position', [25 1115 658 230])
subaxis(1,1,1,1,'MT',0.01,'MB',0.18,'MR',-0.02,'ML',0.06,'P',0.04)
co = [0 0 1;
    0 0.5 0;
    1 0 0;
    0 0.75 0.75;
    0.75 0 0.75;
    0.75 0.75 0;
    0.25 0.25 0.25];
set(groot,'defaultAxesColorOrder',co)

loglog(h,errc,'bo--','MarkerSize',8,'LineWidth',1.4)
hold on
loglog(h,errcd,'r*-','MarkerSize',8,'LineWidth',1.4)
legend({' Centered',' CTSE'},'Location','SouthWest','FontSize',14,'FontWeight','bold')
grid on
xlabel('Stepsize (k)')
ylabel('Error')
set(gca,'FontSize',16,'FontWeight','bold')
hold off

%exportgraphics(gcf,'/Users/mark/Desktop/ctse.eps')

function y=f(x)
y=sqrt(x);















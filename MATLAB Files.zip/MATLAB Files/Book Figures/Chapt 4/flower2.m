function flowers

% low rank approximations using SVD

%k=[5 10 20 40 80 160 320];
k=[10 25 50 100];

% read in image and display it
%x=imread('flower.jpg');
x=imread('butter.jpeg');
I = double(x);
% I =  im2double(x);  % requires image processing toolbox
% I =  im2uint8(x);  % requires image processing toolbox
size_of_image=size(I)
pause

tic
% separate color planes
m=length(I(:,1,1));
n=length(I(1,:,1));
IRed = I(:,:,1);
IGreen = I(:,:,2);
IBlue = I(:,:,3);
A=[ IRed ; IGreen; IBlue ];
size_A=size(A)
[U,S,V] = svd(A);
bigA=toc

pause
tic
% separate color planes
m=length(I(:,1,1));
n=length(I(1,:,1));
IRed = I(:,:,1);
IGreen = I(:,:,2);
IBlue = I(:,:,3);
[U1,S1,V1] = svd(IRed);
[U2,S2,V2] = svd(IGreen);
[U3,S3,V3] = svd(IBlue);
smallA=toc





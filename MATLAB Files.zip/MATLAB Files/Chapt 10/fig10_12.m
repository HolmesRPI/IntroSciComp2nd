function fig10_12

%%%%  ICA using s^4 on linear waves: K and the optimal solution

% generate data
m=6000;
t=linspace(0,10,m);
w1=pi;
w2=1.7*pi;
x=zeros(m,2);
% mixing coefficients
M11=1; M12=2;
M21=1; M22=-2;
for it=1:m
    %     S(it,1) = sin(w1*t(it));
    %     S(it,2) = sin(w2*t(it)-5);
    S(it,1) = sin(w1*t(it));
    S(it,2) = (1/5)*(2.5*sin(w2*t(it)-1)+0.3*t(it)*(10-t(it)));
end

%%%% center S
sM=sum(S)/m;
S=S-sM;

%%% SVD of S
[UR,SR,VR]=svd(S);
D=[sqrt(m)/SR(1,1) 0;0 sqrt(m)/SR(2,2)];
Fac=D*VR';
for it=1:m
    W1(it)=Fac(1,1)*S(it,1)+Fac(1,2)*S(it,2);
    W2(it)=Fac(2,1)*S(it,1)+Fac(2,2)*S(it,2);
end
% for it=1:m
%     X(it,1)=M11*W1(it) + M12*W2(it);
%     X(it,2)=M21*W1(it) + M22*W2(it);
% end

for it=1:m
    X(it,1)=M11*S(it,1) + M12*S(it,2);
    X(it,2)=M21*S(it,1) + M22*S(it,2);
end

xM=sum(X)/m;
X=X-xM;

XX=X'*X/m;
[UX,SX,VX]=svd(XX);
D5=[1/sqrt(SX(1,1)) 0; 0 1/sqrt(SX(2,2))];

y=zeros(m,2);
for it=1:m
    y(it,:)=D5*VX'*X(it,:)';
end

% compute (and then plot) K as function of theta
ntheta=1000;
theta=linspace(0,2*pi,ntheta);
for ia=1:ntheta
    V=[[ cos(theta(ia)) -sin(theta(ia))];[ sin(theta(ia)) cos(theta(ia))]];
    ssk=y*V';
    kks=ssk.^4/m ;
    suk=sum(kks);
    K(ia)=abs(suk(1)-3)+abs(suk(2)-3);
end

% find max's
iz=0;
for ia=2:ntheta-1
    if K(ia-1) < K(ia) && K(ia+1) < K(ia)
        iz=iz+1;
        thetaMM(iz)=theta(ia);
    end
end
thetaMM/pi
theta0=thetaMM(3)/pi

clf
% get(gcf)
set(gcf,'Position', [25 1115 658 230])
subaxis(1,1,1,1,'MT',0.01,'MB',0.18,'MR',-0.02,'ML',0.06,'P',0.04)
co = [0 0 1;
    0 0.5 0;
    1 0 0;
    0 0.75 0.75;
    0.75 0 0.75;
    0.75 0.75 0;
    0.25 0.25 0.25];
set(groot,'defaultAxesColorOrder',co)

plot(theta,K,'LineWidth',1.6)
axis([0 2*pi 1.5 2.3])
xlabel('\theta-axis')
ylabel('K -axis')

set(gca,'xtick',[0 pi/2 pi 3*pi/2 2*pi])
%set(gca,'ytick',[0 1 2 3]);
set(gca,'XTickLabel',{'0';'\pi/2';'\pi';'3\pi/2';'2\pi'})
%set(gca,'YTickLabel',{'0';' ';' ';' '})

grid on
box on
set(gca,'FontSize',16,'FontWeight','bold')

%exportgraphics(gcf,'/Users/mark/Desktop/kk.eps')








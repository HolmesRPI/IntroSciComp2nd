function fig10_11

%%%%  ICA solutions for various non-optimal theta values

% generate data
m=4000;
t=linspace(0,10,m);
w1=pi;
w2=1.7*pi;
x=zeros(m,2);
% mixing coefficients
M11=1; M12=2;
M21=1; M22=-2;
for it=1:m
    %     S(it,1) = sin(w1*t(it));
    %     S(it,2) = sin(w2*t(it)-5);
    S(it,1) = sin(w1*t(it));
    S(it,2) = (1/5)*(2.5*sin(w2*t(it)-1)+0.3*t(it)*(10-t(it)));
end

%%%% center S
sM=sum(S)/m;
S=S-sM;

% use whiten S
[UR,SR,VR]=svd(S);
D=[sqrt(m)/SR(1,1) 0;0 sqrt(m)/SR(2,2)];
Fac=D*VR';
for it=1:m
    W1(it)=Fac(1,1)*S(it,1)+Fac(1,2)*S(it,2);
    W2(it)=Fac(2,1)*S(it,1)+Fac(2,2)*S(it,2);
end
% for it=1:m
%     X(it,1)=M11*W1(it) + M12*W2(it);
%     X(it,2)=M21*W1(it) + M22*W2(it);
% end

% use original S
for it=1:m
    X(it,1)=M11*S(it,1) + M12*S(it,2);
    X(it,2)=M21*S(it,1) + M22*S(it,2);
end

xM=sum(X)/m;
X=X-xM;

XX=X'*X/m;
[UX,SX,VX]=svd(XX);
D5=[1/sqrt(SX(1,1)) 0; 0 1/sqrt(SX(2,2))];

y=zeros(m,2);
for it=1:m
    y(it,:)=D5*VX'*X(it,:)';
end

clf
%get(gcf);
set(gcf,'Position', [8 830 626 515])
co = [0 0 1;
    0 0.5 0;
    1 0 0;
    0 0.75 0.75;
    0.75 0 0.75;
    0.75 0.75 0;
    0.25 0.25 0.25];
set(groot,'defaultAxesColorOrder',co)

hold on

% 0.9758/pi (best) 1.9798 (worst)
theta(1)=pi/4;
theta(2)=pi/2;
theta(3)=7*pi/8;
theta(4)=1.5*pi;

%theta=linspace(0*pi,2*pi,100);

is=0;
for ia=1:4
    V=[[ cos(theta(ia)) -sin(theta(ia))];[ sin(theta(ia)) cos(theta(ia))]];
    for it=1:m
        s(it,1)=V(1,1)*y(it,1)+V(1,2)*y(it,2);
        s(it,2)=V(2,1)*y(it,1)+V(2,2)*y(it,2);
    end
    is=is+1;

    %subplot(4,2,is)
    subaxis(4,2,1,ia,'MT',0.04,'MB',0.07,'MR',-0.005,'ML',0.02,'P',0.02)

    plot(t,S(:,1),'--b','LineWidth',1.6)
    hold on
    plot(t,s(:,1),'r','LineWidth',1.6)
    axis([0 10 -2 2])

    if is==1
        say2=['s_1*'];
        text(4.5,3,say2,'FontSize',18,'FontWeight','bold')
    elseif is==7
        xlabel('t-axis')
    end

    grid on
    box on
    set(gca,'FontSize',14,'FontWeight','bold')

    is=is+1;

    %subplot(4,2,is);
    subaxis(4,2,2,ia)

    plot(t,S(:,2),'--b','LineWidth',1.6);
    hold on
    plot(t,s(:,2),'r','LineWidth',1.6)
    axis([0 10 -2 2])

    if is==2
        say2=['s_2*'];
        text(4.5,3,say2,'FontSize',18,'FontWeight','bold')
    elseif is==8
        xlabel('t-axis')
    end

    grid on
    box on
    set(gca,'FontSize',14,'FontWeight','bold')

end

%exportgraphics(gcf,'/Users/mark/Desktop/sss.eps')


















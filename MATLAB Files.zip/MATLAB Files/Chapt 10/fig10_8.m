function fig10_8

% this also has fig10_9

nt=1000;
t=linspace(0,10,nt);
w1=pi;
w2=2*pi;
w3=0.1*pi;
for it=1:nt
    S1(it) = sin(w1*t(it));
    %S2(it) = 2*sin(w2*t(it)-1)-4*exp(-0.1*t(it))*sin(t(it));
    S2(it) = (1/5)*(2.5*sin(w2*t(it)-1)+0.3*t(it)*(10-t(it)));
end

M11=1; M12=2;
M21=2; M22=-2;

figure(1)
clf
subaxis(2,1,1,1,'MT',0.04,'MB',0.13,'MR',0.001,'ML',0.055,'P',0.03)
co = [0 0 1;
    0 0.5 0;
    1 0 0;
    0 0.75 0.75;
    0.75 0 0.75;
    0.75 0.75 0;
    0.25 0.25 0.25];
set(groot,'defaultAxesColorOrder',co)

% get(gcf)
set(gcf,'Position', [7 1028 599 317])
plot(t,S1,'LineWidth',1.4)
ylabel('s_1 -axis','FontSize',14,'FontWeight','bold')
grid on
box on
set(gca,'FontSize',14,'FontWeight','bold')

subaxis(2,1,1,2)
plot(t,S2,'r','LineWidth',1.4)
xlabel('t-axis')
ylabel('s_2 -axis')
grid on
box on
set(gca,'FontSize',14,'FontWeight','bold')

%exportgraphics(gcf,'/Users/holmes/Desktop/wave1.eps')

figure(2)
x1 = M11*S1 + M12*S2;                  % mixing 1
x2 = M21*S1 + M22*S2;            % mixing 2

clf
% get(gcf)
set(gcf,'Position', [610 1029 598 316])
subaxis(2,1,1,1,'MT',0.04,'MB',0.13,'MR',0.001,'ML',0.053,'P',0.03)
plot(t,x1,'LineWidth',1.4)      % plot mixing 1
ylabel('x_1 -axis')
axis([0 10 -1 5])
grid on
box on
set(gca,'FontSize',14,'FontWeight','bold')

subaxis(2,1,1,2)
plot(t,x2, 'r','LineWidth',1.4)   % plot mixing 2
xlabel('t-axis')
ylabel('x_2 -axis')
axis([0 10 -6 1.5])
yticks([-6 -3 0])
grid on
box on
set(gca,'FontSize',14,'FontWeight','bold')

%exportgraphics(gcf,'/Users/holmes/Desktop/wave2.eps')



























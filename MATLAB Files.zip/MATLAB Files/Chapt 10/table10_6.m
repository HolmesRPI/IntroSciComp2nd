function table10_6

% comparions with persistence model (P=I) and P^d model

% y=Ax(t)  where y approximates x(t+d)

% measure dt in days

% https://usafacts.org/visualizations/coronavirus-covid-19-spread-map/
% open Download Data Known Cases and save as a text file covid_data

%NY=importdata('covid_data.txt');

% T = readtable('covid_data.txt');
% [Nd,Md]=size(T)
% 
% % NY rows 1865 to 1926
% % April 1, 2020 = column 75
% 
% % T(1865:1926,75:80)
% %
% % pause
% 
% NY=table2array(T(1865:1926,75:Md))';
% 
% 
% NY=NY';
% [N M]=size(NY);

T = readtable('covid_data.txt');
[Nd,Md]=size(T)
NY=table2array(T(1865:1926,75:Md))';
[N M]=size(NY)

for it=1:7
    dt=it;

    % XD = new cases; YD = new cases at t+dt
    XD=NY(2:N-dt,:)-NY(1:N-dt-1,:);
    YD=NY(dt+2:N,:)-NY(dt+1:N-1,:);
    [n m]=size(XD);

    meansX=mean(XD);
    meansY=mean(YD);
    X=XD-meansX;
    Y=YD-meansY;
    for j=1:m
        XM(j)=norm(X(:,j),inf);
        YM(j)=norm(Y(:,j),inf);
        X(:,j)=X(:,j)/XM(j);
        Y(:,j)=Y(:,j)/YM(j);
    end

    % use the pseudo-inverse
%     G=X'*X;
%     GI=inv(G);
%     P=Y'*X*GI;

    % use the SVD
    [Uq,Sq,Vq]=svd(X);
    SS=zeros(n,m);
    for i=1:m
        SS(i,i)=1/Sq(i,i);
    end
    P=Y'*Uq*SS*Vq';

    SSx=diag(1./XM);
    Sy=diag(YM);
    A=Sy*P*SSx;
    b=meansY'-A*meansX';

    if it==1
        P1=P;
        Sx1=SSx; Sy1=Sy;
    end

    %%% Albany = 1
    %%% Erie = 15
    %%% Rensselaer = 42
    %%% ulster = 56
    %%% saratoga=46, king=24, westchester=60

    % check error for county r
        r=15;
        PP=P1^it;
        yp=zeros(n,1);
        ypp=yp;
        for i=1:n
            yp(i)=dot(P(r,:),X(i,:));
            ypp(i)=dot(PP(r,:),X(i,:));
        end
    
        err1=norm(yp-Y(:,r),inf);
        % error in y=Px model
        err2=norm(yp-Y(:,r),2)/n;
        % error in P=I model
        err3=norm(Y(:,r)-X(:,r),2)/n;
        % error in P=P1^d model
        err4=norm(ypp-Y(:,r),2)/n;

    % use entire state
%     PP=P1^it;
%     err2=norm(Y'-P*X','fro')/n;
%     err3=norm(Y-X,'fro')/n;
%     err4=norm(Y'-PP*X','fro')/n;

    if it==1
        fprintf(' \n  d Err = ||y-x(t+d)||     Err2 = ||y-x||/Err    Err3 = ||(P^d)x -x(t+d)||/Err \n ')
    end
    fprintf(' \\, %2i \\,\\, &   %6.1e  &   %6.1f  &   %6.1f \\\\\\hline \n ',dt,err2,err3/err2,err4/err2)



end
fprintf('\n\n')

























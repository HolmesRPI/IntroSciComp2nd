function fig4_9

% read in image and calculate svd
x=imread('p17.jpg');
A = double(x);
[U,S,V] = svd(A);
ss=size(S)

% determine singular values
rs=min(ss(1),ss(2))
for i=1:rs
    id(i)=i;
    sigmas(i)=S(i,i);
    E(i)=sigmas(i)/sigmas(1);
end

for i=1:ss(2)
    id(i)=i;
    err(i)=sigmas(i)/sigmas(1);
end

clf
% get(gcf)
set(gcf,'Position', [25 1115 658 230])
subaxis(1,1,1,1,'MT',0.01,'MB',0.18,'MR',-0.014,'ML',0.06,'P',0.04)
co = [0 0 1;
    0 0.5 0;
    1 0 0;
    0 0.75 0.75;
    0.75 0 0.75;
    0.75 0.75 0;
    0.25 0.25 0.25];
set(groot,'defaultAxesColorOrder',co)

semilogy(id,err,'r','Linewidth',1.5)
hold on
set(gca,'ytick',[1e-5 1e-4 1e-3 1e-2 1e-1 1])
xlabel('k-axis')
ylabel('Error')
grid on
set(gca,'YMinorGrid','off')
box on
set(gca,'FontSize',16,'FontWeight','bold')

%exportgraphics(gcf,'/Users/mark/Desktop/svde.eps')



















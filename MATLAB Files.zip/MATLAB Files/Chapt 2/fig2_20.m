function fig2_20

xa=1.5;
tol=10^(-18);

e0=1e-1;
e1(1)=e0; e2(1)=e0; e3(1)=e0; e4(1)=e0; e5(1)=e0;
iter(1)=1;
for i=2:20
    iter(i)=i;
    e1(i)=e1(i-1)/2;
    e2(i)=e2(i-1)/5;
    e3(i)=e3(i-1)^1.5;
    e4(i)=e4(i-1)^2;
    e5(i)=e5(i-1)^2.5;
end

clf
% get(gcf)
set(gcf,'Position', [25 1115 658 230])
subaxis(1,1,1,1,'MT',0.01,'MB',0.18,'MR',-0.02,'ML',0.06,'P',0.04)
co = [0 0 1;
    0 0.5 0;
    1 0 0;
    0 0.75 0.75;
    0.75 0 0.75;
    0.75 0.75 0;
    0.25 0.25 0.25];
set(groot,'defaultAxesColorOrder',co)

% plot error
semilogy(iter,e1,'om','MarkerSize',8,'LineWidth',2)
hold on
semilogy(iter,e1,'--m','MarkerSize',8,'LineWidth',1.2)
semilogy(iter,e2,'+','color',[0 0.5 0],'MarkerSize',8,'LineWidth',2)
semilogy(iter,e2,'--','color',[0 0.5 0],'MarkerSize',8,'LineWidth',1.2)
semilogy(iter,e3,'--r','MarkerSize',8,'LineWidth',1.2)
semilogy(iter,e3,'*r','MarkerSize',8,'LineWidth',2)
semilogy(iter,e4,'--b','MarkerSize',8,'LineWidth',1.2)
semilogy(iter,e4,'>b','MarkerSize',8,'LineWidth',2)
semilogy(iter,e5,'--k','MarkerSize',8,'LineWidth',1.2)
semilogy(iter,e5,'sk','MarkerSize',8,'LineWidth',2)

%set(gca,'YMinorGrid','on')
axis([1 10  1e-16 1e-1])
set(gca,'ytick',[1e-16 1e-13 1e-10 1e-7 1e-4 1e-1])

% add in axes
xlabel('Iteration Step')
ylabel('Error')
grid on
box on
set(gca,'FontSize',16,'FontWeight','bold')

%exportgraphics(gcf,'/Users/mark/Desktop/exer4.eps')




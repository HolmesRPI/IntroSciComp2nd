function newton

%  Solve  f(x) = 0  using Newton's method

%  Input:
%	x = starting point
%	tol = tolerance for stopping
%	f(x) and f'(x) are at end of file

x=3/2;
tol=10^(-10);

k=0;
err=10*tol;
fprintf('\n RIE = relative iterative error \n\n')
fprintf(' k  \t   x_k \t\t\t  RIE \n')
while err>tol
    k=k+1;
    z=f(x)/df(x);
    x=x-f(x)/df(x);
    err=abs(z/x);
    fprintf(' %i \t  %19.12e \t  %5.1e  \n',k,x,err)
end
fprintf('\n')


function g=f(x)
g=2*x^3-3*x^2+3;
%g=exp(-x)-2-x;

function g=df(x)
g=6*x^2-6*x;
%g=-exp(-x)-1;



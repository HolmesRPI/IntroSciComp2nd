function secant

%  Solve  f(x) = 0  using secant method

%  Input:
%	x = starting point
%	tol = tolerance for stopping
%	f(x) is at end of file

x=0;
X=-2;
tol=10^(-10);

k=0;
err=10*tol;
fprintf('\n RIE = relative iterative error \n\n')
fprintf(' k  \t   x_k \t\t\t  RIE \n')
while err>tol
    k=k+1;
    z=f(x)*(x-X)/(f(x)-f(X));
    X=x;
	x=x-z;
	err=abs(z/x); 
    fprintf(' %i \t  %19.12e \t  %5.1e  \n',k,x,err)
end
fprintf('\n\n')


function g=f(x)
%g=x^3+2*x+2;
g=exp(-x)-(2+x);


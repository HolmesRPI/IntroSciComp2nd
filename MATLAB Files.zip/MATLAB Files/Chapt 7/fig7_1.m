function fig7_1

%  comparison of forward and centered difference approximations for f'(x)

x0=1;
exact=0.5

np=2000;
p=linspace(-18,0,np);
for k=1:np
    h(k)=10^p(k);
    F(k)=(f(x0+h(k)) - f(x0))/h(k);
    C(k)=(f(x0+h(k)) - f(x0-h(k)) )/(2*h(k));
    errF(k)=abs(exact-F(k));
    errC(k)=abs(exact-C(k));
end

clf
% get(gcf)
set(gcf,'Position', [25 1115 658 230])
subaxis(1,1,1,1,'MT',0.01,'MB',0.2,'MR',-0.02,'ML',0.06,'P',0.04)
co = [0 0 1;
    0 0.5 0;
    1 0 0;
    0 0.75 0.75;
    0.75 0 0.75;
    0.75 0.75 0;
    0.25 0.25 0.25];
set(groot,'defaultAxesColorOrder',co)

loglog(h,errF,'b','MarkerSize',7,'LineWidth',1.2)
hold on
loglog(h,errC,'r','MarkerSize',7,'LineWidth',1.2)
legend({' Forward',' Centered'},'Location','SouthWest','FontSize',16,'FontWeight','bold','AutoUpdate','off')
loglog(h,errF,'b','MarkerSize',7,'LineWidth',1.2)

grid on
xlabel('Stepsize (k)')
axis([1e-18 1 1e-12 1])
set(gca,'XTick',[1e-18 1e-15 1e-12 1e-9 1e-6 1e-3 1])
set(gca,'YTick',[1e-12 1e-8 1e-4 1])
ylabel('Error')
set(gca,'FontSize',16,'FontWeight','bold')
hold off

%exportgraphics(gca,'/Users/mark/Desktop/deriv.eps')


function y=f(x)
y=sqrt(x);












